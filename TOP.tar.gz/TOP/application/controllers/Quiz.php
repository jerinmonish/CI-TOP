<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Quiz extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */

	/**
     * Constructor
     * To load library,language,model,ETC files
     * */
	function __construct(){
		parent::__construct();
		$this->authendication->authendicate_user();
		$this->template->set_layout('backend-theme');
		$this->lang->load('messages_lang');
		$this->load->model('quiz_model');
		$this->load->helper('flexigrid');
		$this->load->library('flexigrid');
	}

	/**
	* This method handles to Port list
	**/
	public function index(){
		//die('in');
		$this->template->title($this->lang->line('quiz'));

		$colModel['question'] 		= array($this->lang->line('question'),200,TRUE,'left',1);
		$colModel['answer'] 		= array($this->lang->line('answer'),100,TRUE,'left',0);
		$colModel['created_on'] 	= array($this->lang->line('created_on'),100,TRUE,'left',0);
		$colModel['actions'] 		= array($this->lang->line('action'),80, FALSE, 'center',0);	

		$gridParams = [
			'width' => 'auto',
			'height' =>'auto',
			//'rp' =>ADMIN_PER_PAGE,
			'rpOptions' => '[50,100,150,200,500]',
			'pagestat' => 'Displaying: {from} to {to} of {total} items.',
			'blockOpacity' => 0.5,
			'title' => '',
			'showTableToggleBtn' => false
		];

		$buttons[] = array('Add Quiz','add','grid_action');

		$grid_js = build_grid_js('flex1',site_url("/quiz/quiz_ajax"),$colModel,'id','desc',$gridParams,$buttons);
		//print_r($grid_js);exit;
		$data['js_grid'] = $grid_js;

		$this->template->build('quiz/list',$data);
	}

	/**
	* This method handles to build GRID
	**/
	public function quiz_ajax(){
		//die("inajax");
		$valid_fields = array('id','question','answer','created_on');
		$this->flexigrid->validate_post('id','answer', $valid_fields);

		$records = $this->quiz_model->get_all_quiz();

		$i = 1;
		foreach ($records['records']->result() as $row){
			$grid_item[] = [
				//$i,
				$i,
				$row->question,
				$row->answer,
				custom_date($row->created_on),
				'<a href=\''.base_url().$this->lang->line('url_quiz_view').$row->id.'\' title="View"><i class="fa fa-eye text-primary text-semibold"></i></a>&nbsp;
				<a href="'.base_url().$this->lang->line('url_quiz_edit').$row->id.'" title="Update"><i class="fa fa-edit text-warning text-semibold font-size-20"></i></a>&nbsp;
				<a href=\''.base_url().$this->lang->line('url_quiz_delete').$row->id.'\' title="Delete" OnClick=\'Javascript:if(confirm("Are you sure to delete?")) return true; else return false;\' ><i class="fa fa-times text-danger text-semibold font-size-20"></i></a>'
			];
			$i++;
		}
		
      if (isset($grid_item)){
         $this->output->set_output($this->flexigrid->json_build($records['record_count'],$grid_item));
      }
      else{
         $this->output->set_output('{"page":"1","total":"0","rows":[]}');
      }
	}

	public function add()
	{
		//print_r($_POST);exit;
		$this->form_validation->set_rules('question',$this->lang->line('question'),
										  'trim|required',
										  ['required'=> sprintf($this->lang->line('required'),$this->lang->line('question'))]);

		$this->form_validation->set_rules('answer',$this->lang->line('answer'),
										  'trim|required',
										  ['required'=> sprintf($this->lang->line('required'),$this->lang->line('answer'))]);

		$this->form_validation->set_rules('option1',$this->lang->line('option1'),
										  'trim|required',
										  ['required'=> sprintf($this->lang->line('required'),$this->lang->line('option1'))]);

		$this->form_validation->set_rules('option2',$this->lang->line('option2'),
										  'trim|required',
										  ['required'=> sprintf($this->lang->line('required'),$this->lang->line('option2'))]);

		$this->form_validation->set_rules('option3',$this->lang->line('option3'),
										  'trim|required',
										  ['required'=> sprintf($this->lang->line('required'),$this->lang->line('option3'))]);

		$this->form_validation->set_rules('option4',$this->lang->line('option4'),
										  'trim|required',
										  ['required'=> sprintf($this->lang->line('required'),$this->lang->line('option4'))]);

		$this->form_validation->set_rules('course_id',$this->lang->line('course_id'),
										  'trim|required',
										  ['required'=> sprintf($this->lang->line('required'),$this->lang->line('course_id'))]);

		$this->form_validation->set_rules('topic_id',$this->lang->line('topic_id'),
										  'trim|required',
										  ['required'=> sprintf($this->lang->line('required'),$this->lang->line('topic_id'))]);

		if($this->input->post('save')){
			//die('in');
			if($this->form_validation->run() == TRUE)
			{
				$quiz['question'] 		= $this->input->post('question');
				$quiz['answer'] 		= $this->input->post('answer');
				$quiz['option1'] 		= $this->input->post('option1');
				$quiz['option2'] 		= $this->input->post('option2');
				$quiz['option3'] 		= $this->input->post('option3');
				$quiz['option4'] 		= $this->input->post('option4');
				$quiz['course_id'] 		= $this->input->post('course_id');
				$quiz['topic_id'] 		= $this->input->post('topic_id');

                $result = $this->quiz_model->insert_quiz($quiz);
                if($result){
                	$this->session->set_flashdata('success', $this->lang->line('quiz_success_add'));
                	$this->template->title($this->lang->line('add_quiz'));
					$this->template->build('quiz/add');
                } else {
                	$this->session->set_flashdata('error', $this->lang->line('quiz_fail_add'));
                	$this->template->title($this->lang->line('add_quiz'));
					$this->template->build('quiz/add');
                }
			} else {
				$this->template->title($this->lang->line('add_quiz'));
				$this->template->build('quiz/add');
			}
		}  else {
			$this->template->title($this->lang->line('add_quiz'));
			$this->template->build('quiz/add');
		}
	}

	/**
	* This method handles to view port detail
	**/
	public function view($id){
		$data 						= [];
		$result 					= $this->quiz_model->get_quiz_by_id($id);
		if($result){
			$result 					= $result[0];
			$data['id'] 				= $result->id; 
			$data['question'] 			= $result->question; 
			$data['answer'] 			= $result->answer;
			$data['option1'] 			= $result->option1;
			$data['option2'] 			= $result->option2;
			$data['option3'] 			= $result->option3;
			$data['option4'] 			= $result->option4;
			$data['course_id'] 			= $result->course_id;
			$data['topic_id'] 			= $result->topic_id;
			$data['created_on'] 		= custom_date($result->created_on);
		}
		$this->template->title($this->lang->line('quiz_view'));
		$this->template->build('quiz/view', $data);
	}

	/**
	* This method handles delete a port manager by id
	**/
	public function delete($id){
			$result = $this->quiz_model->delete_quiz_id($id);
			if($result){
				$message 	= $this->lang->line('delete_success_quiz');
				$class 		= 'success';
			}else{
				$message 	= $this->lang->line('delete_fail_quiz');
				$class 		= 'error';
			}

		$this->session->set_flashdata($class, $message);
		redirect('quiz/');
	}

	public function edit($id){
		$this->template->title($this->lang->line('edit_course'));
		$data 					= [];
		$result 				= $this->quiz_model->get_quiz_by_id($id);
		$this->form_validation->set_rules('question',$this->lang->line('question'),
										  'trim|required',
										  ['required'=> sprintf($this->lang->line('required'),$this->lang->line('question'))]);

		$this->form_validation->set_rules('answer',$this->lang->line('answer'),
										  'trim|required',
										  ['required'=> sprintf($this->lang->line('required'),$this->lang->line('answer'))]);

		$this->form_validation->set_rules('option1',$this->lang->line('option1'),
										  'trim|required',
										  ['required'=> sprintf($this->lang->line('required'),$this->lang->line('option1'))]);

		$this->form_validation->set_rules('option2',$this->lang->line('option2'),
										  'trim|required',
										  ['required'=> sprintf($this->lang->line('required'),$this->lang->line('option2'))]);

		$this->form_validation->set_rules('option3',$this->lang->line('option3'),
										  'trim|required',
										  ['required'=> sprintf($this->lang->line('required'),$this->lang->line('option3'))]);

		$this->form_validation->set_rules('option4',$this->lang->line('option4'),
										  'trim|required',
										  ['required'=> sprintf($this->lang->line('required'),$this->lang->line('option4'))]);

		$this->form_validation->set_rules('course_id',$this->lang->line('course_id'),
										  'trim|required',
										  ['required'=> sprintf($this->lang->line('required'),$this->lang->line('course_id'))]);

		$this->form_validation->set_rules('topic_id',$this->lang->line('topic_id'),
										  'trim|required',
										  ['required'=> sprintf($this->lang->line('required'),$this->lang->line('topic_id'))]);

		if($this->input->post()){
			if ($this->form_validation->run() == TRUE){
				$user['question']			= $this->input->post('question');
				$user['answer']				= $this->input->post('answer');
				$user['option1']			= $this->input->post('option1');
				$user['option2']			= $this->input->post('option2');
				$user['option3']			= $this->input->post('option3');
				$user['option4']			= $this->input->post('option4');
				$user['course_id']			= $this->input->post('course_id');
				$user['topic_id']			= $this->input->post('topic_id');

				$resul = $this->quiz_model->update_quiz_by_id($id, $user);
				if($resul){
					$this->session->set_flashdata('success', $this->lang->line('quiz_update_success'));
					redirect('quiz/');
					//$this->view($result[0]->id);
				}else{
					$this->session->set_flashdata('error', $this->lang->line('quiz_update_failed'));
					redirect('quiz/');
				}
			}			
		}
		if($result){
			$result 					= $result[0];
			$data['id'] 				= $result->id; 
			$data['question'] 			= $result->question;
			$data['answer'] 			= $result->answer;
			$data['option1'] 			= $result->option1;
			$data['option2'] 			= $result->option2;
			$data['option3'] 			= $result->option3;
			$data['option4'] 			= $result->option4;
			$data['course_id'] 			= $result->course_id;
			$data['topic_id'] 			= $result->topic_id;
		}

		$this->template->build('quiz/edit', $data);
	}

	/**
	* This method handles to Port list
	**/
	public function quote(){
		//die('in');
		$this->template->title($this->lang->line('quiz'));

		$colModel['content'] 		= array($this->lang->line('content'),200,TRUE,'left',1);
		$colModel['i_color'] 		= array($this->lang->line('i_color'),100,TRUE,'left',0);
		$colModel['i_class'] 		= array($this->lang->line('i_class'),100,TRUE,'left',0);
		$colModel['created_on'] 	= array($this->lang->line('created_on'),100,TRUE,'left',0);
		$colModel['actions'] 		= array($this->lang->line('action'),80, FALSE, 'center',0);	

		$gridParams = [
			'width' => 'auto',
			'height' =>'auto',
			//'rp' =>ADMIN_PER_PAGE,
			'rpOptions' => '[50,100,150,200,500]',
			'pagestat' => 'Displaying: {from} to {to} of {total} items.',
			'blockOpacity' => 0.5,
			'title' => '',
			'showTableToggleBtn' => false
		];

		$buttons[] = array('Add Quote','add','grid_action');

		$grid_js = build_grid_js('flex1',site_url("/quiz/quote_ajax"),$colModel,'id','desc',$gridParams,$buttons);
		//print_r($grid_js);exit;
		$data['js_grid'] = $grid_js;

		$this->template->build('quotes/list',$data);
	}

	/**
	* This method handles to build GRID
	**/
	public function quote_ajax(){
		//die("inajax");
		$valid_fields = array('id','i_color','created_on');
		$this->flexigrid->validate_post('id','i_color', $valid_fields);

		$records = $this->quiz_model->get_all_quote_flex();

		$i = 1;
		foreach ($records['records']->result() as $row){
			$grid_item[] = [
				//$i,
				$i,
				$row->content,
				$row->i_color,
				$row->i_class,
				custom_date($row->created_on),
				'<a href=\''.base_url().$this->lang->line('url_quote_view').$row->id.'\' title="View"><i class="fa fa-eye text-primary text-semibold"></i></a>&nbsp;
				<a href="'.base_url().$this->lang->line('url_quote_edit').$row->id.'" title="Update"><i class="fa fa-edit text-warning text-semibold font-size-20"></i></a>&nbsp;
				<a href=\''.base_url().$this->lang->line('url_quote_delete').$row->id.'\' title="Delete" OnClick=\'Javascript:if(confirm("Are you sure to delete?")) return true; else return false;\' ><i class="fa fa-times text-danger text-semibold font-size-20"></i></a>'
			];
			$i++;
		}
		
      if (isset($grid_item)){
         $this->output->set_output($this->flexigrid->json_build($records['record_count'],$grid_item));
      }
      else{
         $this->output->set_output('{"page":"1","total":"0","rows":[]}');
      }
	}


	public function add_quotes(){
		//print_r($_POST);exit;
		$this->form_validation->set_rules('content',$this->lang->line('content'),
										  'trim|required',
										  ['required'=> sprintf($this->lang->line('required'),$this->lang->line('content'))]);

		$this->form_validation->set_rules('i_class',$this->lang->line('i_class'),
										  'trim|required',
										  ['required'=> sprintf($this->lang->line('required'),$this->lang->line('i_class'))]);

		$this->form_validation->set_rules('i_color',$this->lang->line('i_color'),
										  'trim|required',
										  ['required'=> sprintf($this->lang->line('required'),$this->lang->line('i_color'))]);


		if($this->input->post('save')){
			//die('in');
			if($this->form_validation->run() == TRUE)
			{
				$quotes['content'] 		= $this->input->post('content');
				$quotes['i_class'] 		= $this->input->post('i_class');
				$quotes['i_color'] 		= $this->input->post('i_color');

                $result = $this->quiz_model->insert_quotes($quotes);
                if($result){
                	$this->session->set_flashdata('success', $this->lang->line('quote_add_success'));
                	$this->template->title($this->lang->line('add_quotes'));
					$this->template->build('quotes/add_quotes');
                } else {
                	$this->session->set_flashdata('error', $this->lang->line('quote_add_failed'));
                	$this->template->title($this->lang->line('add_quotes'));
					$this->template->build('quotes/add_quotes');
                }
			} else {
				$this->template->title($this->lang->line('add_quotes'));
				$this->template->build('quotes/add_quotes');
			}
		}  else {
			$this->template->title($this->lang->line('add_quotes'));
			$this->template->build('quotes/add_quotes');
		}
	}

	/**
	* This method handles delete a port manager by id
	**/
	public function delete_quotes($id){
			$result = $this->quiz_model->delete_quote_id($id);
			if($result){
				$message 	= $this->lang->line('quote_delete_success');
				$class 		= 'success';
			}else{
				$message 	= $this->lang->line('quote_delete_failed');
				$class 		= 'error';
			}

		$this->session->set_flashdata($class, $message);
		redirect('quiz/quote');
	}

	/**
	* This method handles to view port detail
	**/
	public function view_quotes($id){
		$data 						= [];
		$result 					= $this->quiz_model->get_quote_by_id($id);
		if($result){
			$result 					= $result[0];
			$data['id'] 				= $result->id; 
			$data['content'] 			= $result->content; 
			$data['i_class'] 			= $result->i_class;
			$data['i_color'] 			= $result->i_color;
			$data['created_on'] 		= custom_date($result->created_on);
		}
		$this->template->title($this->lang->line('quotes_view'));
		$this->template->build('quotes/view', $data);
	}

	public function edit_quotes($id){
		$this->template->title($this->lang->line('quotes_edit'));
		$data 					= [];
		$result 				= $this->quiz_model->get_quote_by_id($id);
		$this->form_validation->set_rules('content',$this->lang->line('content'),
										  'trim|required',
										  ['required'=> sprintf($this->lang->line('required'),$this->lang->line('content'))]);

		$this->form_validation->set_rules('i_class',$this->lang->line('i_class'),
										  'trim|required',
										  ['required'=> sprintf($this->lang->line('required'),$this->lang->line('i_class'))]);

		$this->form_validation->set_rules('i_color',$this->lang->line('i_color'),
										  'trim|required',
										  ['required'=> sprintf($this->lang->line('required'),$this->lang->line('i_color'))]);

		if($this->input->post()){
			if ($this->form_validation->run() == TRUE){
				$quote['content'] 		= $this->input->post('content');
				$quote['i_class'] 		= $this->input->post('i_class');
				$quote['i_color'] 		= $this->input->post('i_color');

				$resul = $this->quiz_model->update_quote_by_id($id, $quote);
				if($resul){
					$this->session->set_flashdata('success', $this->lang->line('quote_update_success'));
					redirect('quiz/quote');
					//$this->view($result[0]->id);
				}else{
					$this->session->set_flashdata('error', $this->lang->line('quote_update_failed'));
					redirect('quiz/quote');
				}
			}			
		}
		if($result){
			$result 					= $result[0];
			$data['id'] 				= $result->id; 
			$data['content'] 			= $result->content; 
			$data['i_class'] 			= $result->i_class;
			$data['i_color'] 			= $result->i_color;
			$data['created_on'] 		= custom_date($result->created_on);
		}

		$this->template->build('quotes/edit', $data);
	}
}