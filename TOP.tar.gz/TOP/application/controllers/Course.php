<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Course extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */

	/**
     * Constructor
     * To load library,language,model,ETC files
     * */
	function __construct(){
		parent::__construct();
		$this->authendication->authendicate_user();
		$this->template->set_layout('backend-theme');
		$this->lang->load('messages_lang');
		$this->load->model('course_model');
		$this->load->helper('flexigrid');
		$this->load->library('flexigrid');
	}

	/**
	* This method handles to Port list
	**/
	public function index(){
		//die('in');
		$this->template->title($this->lang->line('course'));

		$colModel['course_name'] 		= array($this->lang->line('course_name'),200,TRUE,'left',1);
		$colModel['course_short_name'] 	= array($this->lang->line('course_short_name'),100,TRUE,'left',0);
		$colModel['status'] 	= array($this->lang->line('status'),100,TRUE,'left',0);
		$colModel['created_on'] 	= array($this->lang->line('created_on'),100,TRUE,'left',0);
		$colModel['actions'] 		= array($this->lang->line('action'),80, FALSE, 'center',0);	

		$gridParams = [
			'width' => 'auto',
			'height' =>'auto',
			//'rp' =>ADMIN_PER_PAGE,
			'rpOptions' => '[50,100,150,200,500]',
			'pagestat' => 'Displaying: {from} to {to} of {total} items.',
			'blockOpacity' => 0.5,
			'title' => '',
			'showTableToggleBtn' => false
		];

		$buttons[] = array('Add Course','add','grid_action');

		$grid_js = build_grid_js('flex1',site_url("/course/course_ajax"),$colModel,'id','desc',$gridParams,$buttons);
		//print_r($grid_js);exit;
		$data['js_grid'] = $grid_js;

		$this->template->build('course/list',$data);
	}

	/**
	* This method handles to build GRID
	**/
	public function course_ajax(){
		//die("inajax");
		$valid_fields = array('id','course_name','course_short_name','created_on');
		$this->flexigrid->validate_post('id','course_short_name', $valid_fields);

		$records = $this->course_model->get_all();

		$i = 1;
		foreach ($records['records']->result() as $row){
			$grid_item[] = [
				//$i,
				$i,
				$row->course_name,
				$row->course_short_name,
				$row->status,
				custom_date($row->created_on),
				'<a href=\''.base_url().$this->lang->line('url_course_view').$row->id.'\' title="View"><i class="fa fa-eye text-primary text-semibold"></i></a>&nbsp;
				<a href="'.base_url().$this->lang->line('url_course_edit').$row->id.'" title="Update"><i class="fa fa-edit text-warning text-semibold font-size-20"></i></a>&nbsp;
				<a href=\''.base_url().$this->lang->line('url_course_delete').$row->id.'\' title="Delete" OnClick=\'Javascript:if(confirm("Are you sure to delete?")) return true; else return false;\' ><i class="fa fa-times text-danger text-semibold font-size-20"></i></a>'
			];
			$i++;
		}
		
      if (isset($grid_item)){
         $this->output->set_output($this->flexigrid->json_build($records['record_count'],$grid_item));
      }
      else{
         $this->output->set_output('{"page":"1","total":"0","rows":[]}');
      }
	}

	public function add()
	{
		//print_r(FCPATH);exit;
		$this->form_validation->set_rules('course_name',$this->lang->line('course_name'),
										  'trim|required',
										  ['required'=> sprintf($this->lang->line('required'),$this->lang->line('course_name'))]);
		$this->form_validation->set_rules('course_short_name',$this->lang->line('course_short_name'),
										  'trim|required',
										  ['required'=> sprintf($this->lang->line('required'),$this->lang->line('course_short_name'))]);
		$this->form_validation->set_rules('course_description',$this->lang->line('course_description'),
										  'trim|required',
										  ['required'=> sprintf($this->lang->line('required'),$this->lang->line('course_description'))]);
		$this->form_validation->set_rules('status',$this->lang->line('status'),
										  'trim|required',
										  ['required'=> sprintf($this->lang->line('required'),$this->lang->line('status'))]);
		if($this->input->post('save')){
			//die('in');
			if($this->form_validation->run() == TRUE)
			{
				$course['course_name'] 			= $this->input->post('course_name');
				$course['course_short_name'] 	= $this->input->post('course_short_name');
				$course['status'] 				= $this->input->post('status');
				$course['course_name'] 			= $this->input->post('course_name');
				$course['course_description'] 	= $this->input->post('course_description');
				if ($_FILES['course_image']['name']) {
                	//print_r($_FILES);exit;
                    $config['upload_path'] = $this->lang->line('set_course_img');
                    $config['allowed_types'] = 'jpg|png|jpeg';
                    //print_r($config);exit;
                    $this->load->library('upload', $config);
                    $this->upload->initialize($config);
                    if ($this->upload->do_upload('course_image')) {
                    	//print_r('in');exit;
                        $file_data = $this->upload->data();
                        $img_name = $file_data['file_name'];
                        $course['course_image'] = $img_name;
                    } else {
                    	print_r($this->upload->display_errors());exit;
                        $course['course_image'] = $_FILES['course_image']['name'];//$this->input->post('image');
                        //print_r($user);exit;
                    }
                }
                $result = $this->course_model->insert_course($course);
                if($result){
                	$this->session->set_flashdata('success', $this->lang->line('course_added'));
                	$this->template->title($this->lang->line('add_course'));
					$this->template->build('course/add_course');
                } else {
                	$this->session->set_flashdata('error', $this->lang->line('course_unable_to_add'));
                	$this->template->title($this->lang->line('add_course'));
					$this->template->build('course/add_course');
                }
			} else {
				$this->template->title($this->lang->line('add_course'));
				$this->template->build('course/add_course');
			}
		}  else {
			$this->template->title($this->lang->line('add_course'));
			$this->template->build('course/add_course');
		}
	}

	/**
	* This method handles to view port detail
	**/
	public function view($id){
		$data 						= [];
		$result 					= $this->course_model->get_course_by_id($id);
		if($result){
			$result 					= $result[0];
			$data['id'] 				= $result->id; 
			$data['course_name'] 		= $result->course_name; 
			$data['course_short_name'] 	= $result->course_short_name;
			$data['course_image'] 			= $result->course_image;
			$data['status'] 			= $result->status;
			$data['created_on'] 		= custom_date($result->created_on);
		}
		$this->template->title($this->lang->line('course_view'));
		$this->template->build('course/view', $data);
	}

	public function edit($course_id){
		$this->template->title($this->lang->line('edit_course'));
		$data 					= [];
		$result 				= $this->course_model->get_course_by_id($course_id);
		$this->form_validation->set_rules('course_name',$this->lang->line('course_name'),
										  'trim|required',
										  ['required'=> sprintf($this->lang->line('required'),$this->lang->line('course_name'))]);
		$this->form_validation->set_rules('course_short_name',$this->lang->line('course_short_name'),
										  'trim|required',
										  ['required'=> sprintf($this->lang->line('required'),$this->lang->line('course_short_name'))]);
		$this->form_validation->set_rules('course_description',$this->lang->line('course_description'),
										  'trim|required',
										  ['required'=> sprintf($this->lang->line('required'),$this->lang->line('course_description'))]);
		$this->form_validation->set_rules('status',$this->lang->line('status'),
										  'trim|required',
										  ['required'=> sprintf($this->lang->line('required'),$this->lang->line('status'))]);

		if($this->input->post()){
			if ($this->form_validation->run() == TRUE){
				$user['course_name']			= $this->input->post('course_name');
				$user['course_short_name']		= $this->input->post('course_short_name');
				$user['course_description']		= $this->input->post('course_description');
				$user['status']					= $this->input->post('status');

				$existing_image = $result[0]->course_image;
                if ($_FILES['course_image']['name']) {
                	//print_r($_FILES);exit;$this->lang->line('set_course_imgs');
                    $config['upload_path'] = $this->lang->line('set_course_img');
                    $config['allowed_types'] = 'jpg|png|jpeg';
                    //print_r($config);exit;
                    $this->load->library('upload', $config);
                    $this->upload->initialize($config);
                    if ($this->upload->do_upload('course_image')) {
                    	//print_r('in');exit;
                        $delete_existing_file = delete_file($this->lang->line('set_course_img'),$existing_image);//delete the old file
                        $file_data = $this->upload->data();
                        $img_name = $file_data['file_name'];
                        $user['course_image'] = $img_name;
                    } else {
                    	print_r($this->upload->display_errors());exit;
                        $user['course_image'] = $_FILES['course_image']['name'];//$this->input->post('image');
                        //print_r($user);exit;
                    }
                } else {
                    $user['course_image'] = $existing_image;
                }

				$resul = $this->course_model->update_course_by_id($course_id, $user);
				if($resul){
					$this->session->set_flashdata('success', $this->lang->line('course_update'));
					//redirect($this->lang->line('url_port_manager'));
					$this->view($result[0]->id);
				}else{
					$this->session->set_flashdata('error', $this->lang->line('course_update_failed'));
					$this->view($result[0]->id);
				}
			}			
		}
		if($result){
			$result 					= $result[0];
			$data['id'] 				= $result->id; 
			$data['course_name'] 		= $result->course_name;
			$data['course_short_name'] 	= $result->course_short_name;
			$data['course_description'] = $result->course_description;
			$data['course_image'] 		= $result->course_image;
			$data['status'] 			= $result->status;
		}

		$this->template->build('course/edit', $data);
	}

	/**
	* This method handles delete a port manager by id
	**/
	public function delete($id){
			$result = $this->course_model->delete_course_id($id);
			if($result){
				$message 	= $this->lang->line('delete_success_course');
				$class 		= 'success';
			}else{
				$message 	= $this->lang->line('delete_fail_course');
				$class 		= 'error';
			}

		$this->session->set_flashdata($class, $message);
		redirect('course/');
	}

	/**
	* This method handles to Port list
	**/
	public function sub_course(){
		//die('in');
		$this->template->title($this->lang->line('sub_course'));

		$colModel['topic_name'] 		= array($this->lang->line('topic_name'),200,TRUE,'left',1);
		$colModel['topic_short_name'] 	= array($this->lang->line('topic_short_name'),100,TRUE,'left',0);
		$colModel['status'] 			= array($this->lang->line('status'),100,TRUE,'left',0);
		$colModel['created_on'] 		= array($this->lang->line('created_on'),100,TRUE,'left',0);
		$colModel['actions'] 			= array($this->lang->line('action'),80, FALSE, 'center',0);	

		$gridParams = [
			'width' => 'auto',
			'height' =>'auto',
			//'rp' =>ADMIN_PER_PAGE,
			'rpOptions' => '[50,100,150,200,500]',
			'pagestat' => 'Displaying: {from} to {to} of {total} items.',
			'blockOpacity' => 0.5,
			'title' => '',
			'showTableToggleBtn' => false
		];

		$buttons[] = array('Add Sub Topic','add','grid_action');

		$grid_js = build_grid_js('flex1',site_url("/course/sub_course_ajax"),$colModel,'id','desc',$gridParams,$buttons);
		//print_r($grid_js);exit;
		$data['js_grid'] = $grid_js;

		$this->template->build('sub_course/list',$data);
	}


	/**
	* This method handles to build GRID
	**/
	public function sub_course_ajax(){
		//die("inajax");
		$valid_fields = array('id','topic_name','topic_short_name','created_on');
		$this->flexigrid->validate_post('id','topic_short_name', $valid_fields);

		$records = $this->course_model->get_all_topic();

		$i = 1;
		foreach ($records['records']->result() as $row){
			$grid_item[] = [
				//$i,
				$i,
				$row->topic_name,
				$row->topic_short_name,
				$row->status,
				custom_date($row->created_on),
				'<a href=\''.base_url().$this->lang->line('url_sub_course_view').$row->course_id.'\' title="View"><i class="fa fa-eye text-primary text-semibold"></i></a>&nbsp;
				<a href="'.base_url().$this->lang->line('url_sub_course_edit').$row->id.'" title="Update"><i class="fa fa-edit text-warning text-semibold font-size-20"></i></a>&nbsp;
				<a href=\''.base_url().$this->lang->line('url_sub_course_delete').$row->id.'\' title="Delete" OnClick=\'Javascript:if(confirm("Are you sure to delete?")) return true; else return false;\' ><i class="fa fa-times text-danger text-semibold font-size-20"></i></a>'
			];
			$i++;
		}
		
      if (isset($grid_item)){
         $this->output->set_output($this->flexigrid->json_build($records['record_count'],$grid_item));
      }
      else{
         $this->output->set_output('{"page":"1","total":"0","rows":[]}');
      }
	}

	public function add_sub_course()
	{
			//print_r($_POST);exit;
		$this->form_validation->set_rules('course_id',$this->lang->line('course_id'),
										  'trim|required',
										  ['required'=> sprintf($this->lang->line('required'),$this->lang->line('course_id'))]);
		$this->form_validation->set_rules('topic_name',$this->lang->line('topic_name'),
										  'trim|required',
										  ['required'=> sprintf($this->lang->line('required'),$this->lang->line('topic_name'))]);
		$this->form_validation->set_rules('topic_short_name',$this->lang->line('topic_short_name'),
										  'trim|required',
										  ['required'=> sprintf($this->lang->line('required'),$this->lang->line('topic_short_name'))]);
		$this->form_validation->set_rules('status',$this->lang->line('status'),
										  'trim|required',
										  ['required'=> sprintf($this->lang->line('required'),$this->lang->line('status'))]);
		if($this->input->post('save')){
			//die('in');
			if($this->form_validation->run() == TRUE)
			{
				$sub_course['course_id'] 		= $this->input->post('course_id');
				$sub_course['topic_name'] 		= $this->input->post('topic_name');
				$sub_course['topic_short_name'] = $this->input->post('topic_short_name');
				$sub_course['status'] 			= $this->input->post('status');
				$sub_course['created_on'] 		= date('y-m-d h:i:s');

				if ($_FILES['topic_img']['name']) {
                	//print_r($_FILES);exit;
                    $config['upload_path'] = FCPATH.'assets/sub_course/icons/';
                    $config['allowed_types'] = 'jpg|png|jpeg|svg';
                    //print_r($config);exit;
                    $this->load->library('upload', $config);
                    $this->upload->initialize($config);
                    if ($this->upload->do_upload('topic_img')) {
                    	//print_r('in');exit;
                        $file_data = $this->upload->data();
                        $img_name = $file_data['file_name'];
                        $sub_course['topic_img'] = $img_name;
                    } else {
                    	print_r($this->upload->display_errors());exit;
                        $sub_course['topic_img'] = $_FILES['topic_img']['name'];//$this->input->post('image');
                        //print_r($user);exit;
                    }
                }

                if ($_FILES['topic_pdf']['name']) {
                	//print_r($_FILES);exit;
                    $config['upload_path'] = FCPATH.'assets/sub_course/pdf/';
                    $config['allowed_types'] = 'pdf';
                    //print_r($config);exit;
                    $this->load->library('upload', $config);
                    $this->upload->initialize($config);
                    if ($this->upload->do_upload('topic_pdf')) {
                    	//print_r('in');exit;
                        $file_data = $this->upload->data();
                        $img_name = $file_data['file_name'];
                        $sub_course['topic_pdf'] = $img_name;
                    } else {
                    	print_r($this->upload->display_errors());exit;
                        $sub_course['topic_pdf'] = $_FILES['topic_pdf']['name'];//$this->input->post('image');
                        //print_r($user);exit;
                    }
                }
				
                $result = $this->course_model->insert_sub_course($sub_course);
                if($result){
                	$this->session->set_flashdata('success', $this->lang->line('course_added'));
                	$this->template->title($this->lang->line('add_sub_course'));
					$this->template->build('sub_course/add_course');
                } else {
                	$this->session->set_flashdata('error', $this->lang->line('course_unable_to_add'));
                	$this->template->title($this->lang->line('add_sub_course'));
					$this->template->build('sub_course/add_course');
                }
			} else {
				$this->template->title($this->lang->line('add_sub_course'));
				$this->template->build('sub_course/add_course');
			}
		}  else {
			$this->template->title($this->lang->line('add_sub_course'));
			$this->template->build('sub_course/add_course');
		}
	}

	/**
	* This method handles to view port detail
	**/
	public function view_sub_course($id){
		$data 						= [];
		$result 					= $this->course_model->get_sub_course_id($id);
		if($result){
			$result 					= $result[0];
			$data['id'] 				= $result->id; 
			$data['topic_name'] 		= $result->topic_name;
			$data['course_id'] 			= $result->course_id;
			$data['topic_short_name'] 	= $result->topic_short_name;
			$data['topic_img'] 			= $result->topic_img;
			$data['status'] 			= $result->status;
			$data['topic_pdf']			= $result->topic_pdf;
			$data['created_on'] 		= custom_date($result->created_on);
		}
		$this->template->title($this->lang->line('topic_view'));
		$this->template->build('sub_course/view', $data);
	}

	public function edit_sub_course($topic_id){
		//print_r($_POST);exit;
		$this->template->title($this->lang->line('edit_topic'));
		$data 					= [];
		$result 				= $this->course_model->get_topic_course_id($topic_id);

		$this->form_validation->set_rules('course_id',$this->lang->line('course_id'),
										  'trim|required',
										  ['required'=> sprintf($this->lang->line('required'),$this->lang->line('course_id'))]);
		$this->form_validation->set_rules('topic_name',$this->lang->line('topic_name'),
										  'trim|required',
										  ['required'=> sprintf($this->lang->line('required'),$this->lang->line('topic_name'))]);
		$this->form_validation->set_rules('topic_short_name',$this->lang->line('topic_short_name'),
										  'trim|required',
										  ['required'=> sprintf($this->lang->line('required'),$this->lang->line('topic_short_name'))]);
		$this->form_validation->set_rules('status',$this->lang->line('status'),
										  'trim|required',
										  ['required'=> sprintf($this->lang->line('required'),$this->lang->line('status'))]);

		if($this->input->post()){
			if ($this->form_validation->run() == TRUE){
				$sub_course_edit['course_id'] 			= $this->input->post('course_id');
				$sub_course_edit['topic_name'] 			= $this->input->post('topic_name');
				$sub_course_edit['topic_short_name'] 	= $this->input->post('topic_short_name');
				$sub_course_edit['status'] 				= $this->input->post('status');

				$existing_image = $result[0]->topic_img;
                if ($_FILES['topic_img']['name']) {
                	//print_r($_FILES);exit;$this->lang->line('set_course_imgs');
                    $config['upload_path'] = FCPATH.'assets/sub_course/icons/';
                    //$config['allowed_types'] = 'jpg|png|jpeg|svg';
                    //print_r($config);exit;
                    $this->load->library('upload', $config);
                    $this->upload->initialize($config);
                    if ($this->upload->do_upload('topic_img')) {
                    	//print_r('in');exit;
                        $delete_existing_file = delete_file(FCPATH.'assets/sub_course/icons/',$existing_image);//delete the old file
                        $file_data = $this->upload->data();
                        $img_name = $file_data['file_name'];
                        $sub_course_edit['topic_img'] = $img_name;
                    } else {
                    	print_r($this->upload->display_errors());exit;
                        $sub_course_edit['topic_img'] = $_FILES['topic_img']['name'];//$this->input->post('image');
                        //print_r($user);exit;
                    }
                } else {
                    $sub_course_edit['topic_img'] = $existing_image;
                }

                $existing_pdf = $result[0]->topic_pdf;
                if ($_FILES['topic_pdf']['name']) {
                	//print_r($_FILES);exit;$this->lang->line('set_course_imgs');
                    $config['upload_path'] = FCPATH.'assets/sub_course/pdf/';
                    $config['allowed_types'] = 'pdf';
                    //print_r($config);exit;
                    $this->load->library('upload', $config);
                    $this->upload->initialize($config);
                    if ($this->upload->do_upload('topic_pdf')) {
                    	//print_r('in');exit;
                        $delete_existing_file = delete_file(FCPATH.'assets/sub_course/pdf/',$existing_pdf);//delete the old file
                        $file_data = $this->upload->data();
                        $img_name = $file_data['file_name'];
                        $sub_course_edit['topic_pdf'] = $img_name;
                    } else {
                    	print_r($this->upload->display_errors());exit;
                        $sub_course_edit['topic_pdf'] = $_FILES['topic_pdf']['name'];//$this->input->post('image');
                        //print_r($user);exit;
                    }
                } else {
                    $sub_course_edit['topic_pdf'] = $existing_pdf;
                }

				$resul = $this->course_model->update_sub_course_by_id($topic_id, $sub_course_edit);
				if($resul){
					$this->session->set_flashdata('success', $this->lang->line('sub_course_update'));
					$this->view_sub_course($result[0]->id);
				}else{
					$this->session->set_flashdata('error', $this->lang->line('sub_course_update_failed'));
					$this->view_sub_course($result[0]->id);
				}
			}			
		}
		if($result){
			$result 					= $result[0];
			$data['id'] 				= $result->id; 
			$data['course_id'] 			= $result->course_id;
			$data['topic_name'] 		= $result->topic_name;
			$data['topic_short_name'] 	= $result->topic_short_name;
			$data['topic_img'] 			= $result->topic_img;
			$data['topic_pdf'] 			= $result->topic_pdf;
			$data['status'] 			= $result->status;
		}

		$this->template->build('sub_course/edit', $data);
	}

	/**
	* This method handles delete a port manager by id
	**/
	public function delete_sub_course($id){
			$result = $this->course_model->delete_sub_course_id($id);
			if($result){
				$message 	= $this->lang->line('delete_success');
				$class 		= 'success';
			}else{
				$message 	= $this->lang->line('delete_fail');
				$class 		= 'error';
			}

		$this->session->set_flashdata($class, $message);
		redirect('course/sub_course/');
	}

	public function view_course_frontend(){
		$get_course['all_course'] = $this->course_model->get_all_course();
		if($get_course){
			$this->template->title($this->lang->line('all_course'));
			$this->template->build('course/frontend_course',$get_course);
		} else {
			$this->template->title($this->lang->line('all_course'));
			$this->template->build('course/frontend_course');
		}
	}

	public function get_sub_course($id){
		$get_sub_course['sub_course'] = $this->course_model->get_sub_course_id($id);
		//print_r($get_sub_course);exit;
		if($get_sub_course){
			$this->template->title($this->lang->line('topics'));
			$this->template->build('sub_course/frontend_sub_course',$get_sub_course);
		} else {
			$this->template->title($this->lang->line('topics'));
			$this->template->build('sub_course/frontend_sub_course');
		}
	}

	public function get_sub_course_quiz(){
		$id 	=	$this->input->post('course_id');
		$get_sub_course = $this->course_model->get_sub_course_id($id);
		//print_r($get_sub_course);exit;
		if($get_sub_course){
			echo json_encode($get_sub_course);
		} else {
			return false;
		}
	}

	public function quiz($topic_id,$course_id){
		$get_quiz['quiz'] = $this->course_model->get_quiz_topic_course($topic_id,$course_id);
		//print_r($get_quiz);exit;
		if(!empty($get_quiz)){
			$this->session->set_flashdata('success', $this->lang->line('quiz_present'));
			$this->template->title($this->lang->line('attend_quiz'));
			$this->template->build('quiz/attend_quiz',$get_quiz);
		} else {
			$this->session->set_flashdata('error', $this->lang->line('quiz_not_present'));
			$this->template->title($this->lang->line('attend_quiz'));
			$this->template->build('quiz/attend_quiz');
		}
	}

	public function get_quiz_answer(){
		$all_questions = 1; 
		$sum = 0;
		foreach ($this->input->post('question') as $key => $value) {
			$get_course_id 	= $this->input->post('course_id');
			$get_topic_id 	= $this->input->post('topic_id');
			$set_all 		= $this->course_model->check_answers($value,$key,$get_course_id,$get_topic_id);
			$question 		= $all_questions++;
			$sum+= $set_all;
			//echo '<pre>';print_r($sum);
		}
		//echo '<pre>';print_r($question.'/'.$sum);exit;
		//$mark = (int) $question%$sum;
		//print_r($sum);exit;
		//$set_mark = round($mark);
		//print_r($mark);exit;
		$data['user_id']	=	$this->session->userdata('id');
		$data['course_id']	=	$this->input->post('course_id');
		$data['topic_id']	=	$this->input->post('topic_id');
		$data['stu_mark']	=	$sum;
		$data['sub_mark']	=	$question;
		$data['pass_mark']	=	4;
		if($data['stu_mark'] >= $data['pass_mark']){
			$stu_status = 'Pass';
			$stu_topic = COMPLETED;
		} else {
			$stu_status	= 'Fail';
			$stu_topic = INCOMPLETE;
		}
		$data['stu_status']		=	$stu_status;
		$data['topic_status']	=	$stu_topic;
		$set_student_detail	=	$this->course_model->set_course_topic_details($data);
		//print_r($set_student_detail);exit;
		if($set_student_detail){
			$this->session->set_flashdata('success', $this->lang->line('certificate_generated'));
			$this->template->title($this->lang->line('attended_quiz_success'));
			$this->get_sub_course($data['course_id']);
		} else {
			$this->session->set_flashdata('success', $this->lang->line('certificate_generated'));
			$this->template->title($this->lang->line('attended_quiz_fail'));
			$this->get_sub_course($data['course_id']);
		}
	}

	public function get_certificate($topic_id,$course_id){
		$get_certificate_details = $this->course_model->get_certificate_details($topic_id,$course_id);
		if($get_certificate_details){
			$certificate = $get_certificate_details[0];
			$certi['user_id']		=	isset($certificate->user_id) ? $certificate->user_id : 'sample';
			$certi['course_id'] 	=	isset($certificate->course_id) ? $certificate->course_id : '1';
			$certi['topic_id']		=	isset($certificate->topic_id) ? $certificate->topic_id : '1';
			$certi['stu_mark'] 		=	isset($certificate->stu_mark) ? $certificate->stu_mark : '0';
			$certi['sub_mark'] 		=	isset($certificate->sub_mark) ? $certificate->sub_mark : '0';
			$certi['stu_status']	=	isset($certificate->stu_status) ? $certificate->stu_status : FAIL;
			$certi['topic_status'] 	=	isset($certificate->topic_status) ? $certificate->topic_status : INCOMPLETE;
			//$this->session->set_flashdata('success', $this->lang->line('certificate_generated'));
			$this->template->title($this->lang->line('get_certificate'));
			$this->template->build('quiz/certificate_page',$certi);
		} else {
			//$this->session->set_flashdata('error', $this->lang->line('certificate_failed'));
			$this->template->title($this->lang->line('get_certificate'));
			$this->template->build('quiz/certificate_page');
		}
	}

	public function search_course(){
		$text = $_REQUEST['search'];
		//print_r($text);exit;
		$get_course_details = $this->course_model->get_course_search($text);
		print_r($get_course_details);exit;
	}
}