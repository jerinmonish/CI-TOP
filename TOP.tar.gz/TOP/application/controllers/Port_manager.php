<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/***
	File Name 		: Port_manager.php
	Description 	: This Controller is to Provide the Port Manager Details and its operation
	Author 			: Loganathan N, A.C Jerin Monish <jerinmonish007@gmail.com>
	**/

class Port_manager extends CI_Controller {
	/**
	* constructor
	**/
	function __construct(){
		parent::__construct();
		$this->load->model('Port_model');
		$this->template->set_layout('admin');
		$this->load->helper('flexigrid');
		$this->load->library('flexigrid');
		$this->authendication->authendicate_admin();
	}

	/**
	* This method handles to Port list
	**/
	public function index(){
		$this->template->title($this->lang->line('port_manager'));

		//$colModel['id'] 			= array($this->lang->line('sno'),20,FALSE,'center',0);
		$colModel['port_name'] 		= array($this->lang->line('port_name'),300,TRUE,'left',1);
		$colModel['created_on'] 	= array($this->lang->line('port_created_on'),100,TRUE,'left',0);
		$colModel['modified_on'] 	= array($this->lang->line('last_updated'),100,TRUE,'left',0);
		$colModel['actions'] 		= array($this->lang->line('action'),80, FALSE, 'center',0);	

		$gridParams = [
			'width' => 'auto',
			'height' =>'auto',
			'rp' =>ADMIN_PER_PAGE,
			'rpOptions' => '[50,100,150,200,500]',
			'pagestat' => 'Displaying: {from} to {to} of {total} items.',
			'blockOpacity' => 0.5,
			'title' => '',
			'showTableToggleBtn' => false
		];

		$buttons[] = array('Add Port','add','grid_action');

		$grid_js = build_grid_js('flex1',site_url("/port_manager/port_ajax"),$colModel,'id','desc',$gridParams,$buttons);

		$data['js_grid'] = $grid_js;

		$this->template->build('port_manager/list',$data);
	}

	/**
	* This method handles to build GRID
	**/
	public function port_ajax(){
		$valid_fields = array('id','port_name','created_on','modified_on');
		$this->flexigrid->validate_post('id','description', $valid_fields);

		$records = $this->Port_model->get_all();

		$i = 1;
		foreach ($records['records']->result() as $row){
			$grid_item[] = [
				//$i,
				$i,
				$row->port_name,
				custom_date($row->created_on),
				custom_date($row->modified_on),
				//'<a href=\''.base_url().$this->lang->line('url_port_manager_view').$row->id.'\' title="View"><i class="fa fa-eye text-primary text-semibold"></i></a>&nbsp;
				'<a href="'.base_url().$this->lang->line('url_port_manager_update').$row->id.'" title="Update"><i class="fa fa-edit text-warning text-semibold font-size-20"></i></a>&nbsp;
				<a href=\''.base_url().$this->lang->line('url_port_manager_delete').$row->id.'\' title="Delete" OnClick=\'Javascript:if(confirm("Are you sure to delete?")) return true; else return false;\' ><i class="fa fa-times text-danger text-semibold font-size-20"></i></a>'
			];
			$i++;
		}
		
      if (isset($grid_item)){
         $this->output->set_output($this->flexigrid->json_build($records['record_count'],$grid_item));
      }
      else{
         $this->output->set_output('{"page":"1","total":"0","rows":[]}');
      }
	}

	/**
	* This method handles to view port detail
	**/
	public function view($id){
		$this->template->title($this->lang->line('port_manager_view'));
		$data 						= [];
		$result 					= $this->Port_model->get_port_by_id($id);
		if($result){
			$result 				= $result[0];
			$data['id'] 			= $result->id; 
			$data['port_name'] 		= $result->port_name; 
			$data['created_on'] 	= custom_date($result->created_on);
			$data['modified_on'] 	= ($result->modified_on) ? custom_date($result->modified_on) : '';
		}
		$this->template->build('port_manager/view', $data);
	}

	/**
	* This method handles to add new port manager
	**/
	public function add(){ 
		$this->template->title($this->lang->line('port_manager_add'));
		// form validation rule
		$this->form_validation->set_rules('port_name', $this->lang->line('port_name'), 'trim|required|is_unique[port.port_name]|max_length[246]', ['required'=> sprintf($this->lang->line('required'),$this->lang->line('port_name')),'is_unique'=> sprintf($this->lang->line('is_unique'),$this->lang->line('port_name'), $this->lang->line('port_name'))]);
		
		if($this->input->post()){
			if ($this->form_validation->run() == TRUE){
				$data['port_name'] 		= $this->input->post('port_name'); 
				$data['created_on'] 	= mysql_date_time();
				$data['modified_on'] 	= mysql_date_time();

				$result = $this->Port_model->add_port($data);
				if($result){
					$this->session->set_flashdata('success', $this->lang->line('port_manager_add_success'));
					redirect($this->lang->line('url_port_manager'));
				}else{
					$this->session->set_flashdata('error', $this->lang->line('port_manager_add_error'));
				}
			}
		}
		$this->template->build('port_manager/add');
	}

	/**
	* This method handles to update port detail
	**/
	public function update($id){
		$this->template->title($this->lang->line('port_manager_update'));
		$data 					= [];
		$result 				= $this->Port_model->get_port_by_id($id);

		$this->form_validation->set_rules('port_name', $this->lang->line('port_name'), 'trim|required|max_length[246]', ['required'=> sprintf($this->lang->line('required'),$this->lang->line('port_name')),'is_unique'=> sprintf($this->lang->line('is_unique'),$this->lang->line('port_name'), $this->lang->line('port_name'))]);


		if($this->input->post()){
			if ($this->form_validation->run() == TRUE){
				$data['port_name'] 	= $this->input->post('port_name'); 
				$data['modified_on'] = mysql_date_time();
				$result = $this->Port_model->update_port_by_id($id, $data);
				if($result){
					$this->session->set_flashdata('success', $this->lang->line('port_manager_update_success'));
					redirect($this->lang->line('url_port_manager'));
				}else{
					$this->session->set_flashdata('error', $this->lang->line('port_manager_update_error'));
				}
			}			
		}
		if($result){
			$result 			= $result[0];
			$data['id'] 		= $result->id; 
			$data['port_name'] 	= $result->port_name; 
		}
		
		$this->template->build('port_manager/update', $data);
	}

	/**
	* This method handles delete a port manager by id
	**/
	public function delete($id){
		// port is related with store
		$this->load->model('store_model');
		$check_relation = $this->store_model->get_store_detail_by_port_id($id);
		if($check_relation){
			$message 	= sprintf($this->lang->line('delete_related'), 'Port', 'Store');
			$class 		= 'error';
		}else{
			$result = $this->Port_model->delete_port_by_id($id);
			if($result){
				$message 	= $this->lang->line('delete_success');
				$class 		= 'success';
			}else{
				$message 	= $this->lang->line('delete_success');
				$class 		= 'error';
			}
		}

		$this->session->set_flashdata($class, $message);
		redirect($this->lang->line('url_port_manager'));
	}
	
}
