<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * PHP version 5 and Codeigniter version 3.0.6
 *
 * @package         Controller
 * @Purpose         To maintain the login details
 * @File   	  		Login.php
 * @Author    		A.C Jerin Monish
 * @Created Date	06-09-2016
 */

class Login extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */

	/**
     * Constructor
     * To load library,language,model,ETC files
     * */
	function __construct(){
		parent::__construct();
		$this->template->set_layout('login');
		$this->lang->load('messages_lang');
		$this->load->model('login_model');
		$this->load->helper('flexigrid');
		$this->load->library('flexigrid');
	}

	/**
     * This method is used to load login page
     * @access public
     * @return void
     * */
	public function index()
	{
		$this->template->set_layout('login');
		$this->template->title($this->lang->line('login'));
		$this->template->build('layouts/login');
	}

	/**
     * This method is used to check user login
     * @access public
     * @return void
     * */
	public function login_process(){

		$this->form_validation->set_rules('email',$this->lang->line('e_mail'),
										  'trim|required|valid_email',
										  ['required'=> sprintf($this->lang->line('required'),$this->lang->line('e_mail'))]);
		$this->form_validation->set_rules('password',$this->lang->line('password'),
										  'trim|required',
										  ['required'=> sprintf($this->lang->line('required'),$this->lang->line('password'))]);
		if($this->input->post('login')){
				if($this->form_validation->run() == TRUE)
				{
					$user['email']			=	$this->input->post('email');
					$user['password']		=	md5($this->input->post('password'));
					$user['ip'] 			= 	$this->input->ip_address();
					$get_valid_user			=	$this->login_model->check_user_login($user);
					if(!empty($get_valid_user)){
						$valid_user 					=	$get_valid_user[0];
						$session_data['id'] 			=	$valid_user->id;
						$session_data['email'] 			=	$valid_user->email;
						$session_data['first_name'] 	=	$valid_user->first_name;
						$session_data['last_name'] 		=	$valid_user->last_name;
						$session_data['image'] 			=	($valid_user->image) ? $valid_user->image:'no-image.png';
						$session_data['last_logged_on'] =	$valid_user->last_logged_on;
						$session_data['user_type'] 		=	$valid_user->user_type;
						$set_session 	=	 $this->session->set_userdata($session_data);
						//print_r($set_session);exit;
						redirect('login/dashboard',$get_valid_user);
					} else {
						$this->session->set_flashdata('error', $this->lang->line('login_invalid'));
						$this->index();
					}
				} else {
					$this->index();
				}
		}  else {
			$this->index();
		}
	}

	/**
     * This method is used to redirect user to dashboard
     * @access public
     * @return void
     * */
	public function dashboard(){
		$this->authendication->authendicate_user();
		$this->template->set_layout('backend-theme');
		$this->template->title($this->lang->line('dashboard'));
		$this->template->build('admin_dashboard');
	}

	/**
     * This method is used to logout user and make his status inactive
     * @access public
     * @return void
     * */
	public function logout(){
		$user_id = $this->session->userdata('id');
		$update_status = $this->login_model->update_inactive_status($user_id);
		if($update_status){
			$first_name = $this->session->userdata('first_name');
			$this->sess_expiration = 0;
			$this->session->unset_userdata('email');
			$this->session->unset_userdata('image');
			$this->session->unset_userdata('last_logged_on');
			$this->session->unset_userdata('first_name');
			$this->session->unset_userdata('last_name');
			$this->session->unset_userdata('id');
			$this->session->sess_destroy();	
			if($first_name){
				//print_r($first_name);exit;
				$this->session->set_flashdata('success',$this->lang->line('logout_success'));
				$this->index();
			} else {
				$this->session->set_flashdata('success',$this->lang->line('logout_success'));
				$this->index();
			}
		} else {
			$this->template->set_layout('backend-theme');
			$this->template->title($this->lang->line('dashboard'));
			$this->template->build('admin_dashboard');
		}
	}

	/**
     * This method is used to check password correct or not
     * @access public
     * @return void
     * */
	public function check_password(){
		$this->authendication->authendicate_user();
		$currpass['password'] = md5($this->input->post('current_pass'));
		$currpass['id'] 	  = $this->input->post('id');
		$get_user_password    = $this->login_model->get_password($currpass);
		if($get_user_password){
			echo '1';
		} else {
			echo '0';
		}
	}

	/**
     * This method is used check password and change if the old password is correct
     * @access public
     * @return void
     * */
	public function change_password(){
		$this->authendication->authendicate_user();
		$this->form_validation->set_rules('curr_pass',$this->lang->line('curr_pass'),
										  'trim|required',
										  ['required'=>sprintf($this->lang->line('required'),$this->lang->line('curr_pass'))]);

		$this->form_validation->set_rules('new_pass',$this->lang->line('new_pass'),
										  'trim|required',
										  ['required'=>sprintf($this->lang->line('required'),$this->lang->line('new_pass'))]);
		if($this->input->post()){
			if($this->form_validation->run() == TRUE){
				$id 	   = $this->session->userdata('id');
				$old_pass  = md5($this->input->post('curr_pass'));
				$new_pass  = md5($this->input->post('new_pass'));
				//print_r($old_pass.'->'.$new_pass);exit;
				$get_result = $this->login_model->change_user_password($id,$old_pass,$new_pass);
				if($get_result){
					$this->session->set_flashdata('success',$this->lang->line('password_changed'));
					redirect('login/change_password');
				} else {
					$this->session->set_flashdata('error',$this->lang->line('password_notchanged'));
					redirect('login/change_password');
				}
			}
		} 
		$this->template->set_layout('backend-theme');
		$this->template->title($this->lang->line('change-pass'));
		$this->template->build('profile_edit/change_password');
	}

	/**
     * This method is used to update user profile
     * @access public
     * @return void
     * */
	public function update_profile($user_id){
		//echo '<pre>';print_r($_POST);exit;
		$this->form_validation->set_rules('first_name',$this->lang->line('first_name'),
										  'trim|required',
										  ['required'=>sprintf($this->lang->line('required'),$this->lang->line('first_name'))]);
		$this->form_validation->set_rules('last_name',$this->lang->line('last_name'),
										  'trim|required',
										  ['required'=>sprintf($this->lang->line('required'),$this->lang->line('last_name'))]);
		$this->form_validation->set_rules('dob',$this->lang->line('dob'),
										  'trim|required',
										  ['required'=>sprintf($this->lang->line('required'),$this->lang->line('dob'))]);
		$this->form_validation->set_rules('gender',$this->lang->line('gender'),
										  'trim|required',
										  ['required'=>sprintf($this->lang->line('required'),$this->lang->line('gender'))]);
		$this->form_validation->set_rules('e_mail',$this->lang->line('e_mail'),
										  'trim|valid_email|required',
										  ['required'=>sprintf($this->lang->line('required'),$this->lang->line('e_mail'))]);
		$this->form_validation->set_rules('address',$this->lang->line('address'),
										  'trim|required',
										  ['required'=>sprintf($this->lang->line('required'),$this->lang->line('address'))]);
		$this->form_validation->set_rules('mobile_no',$this->lang->line('mobile_no'),
										  'trim|numeric|required',
										  ['required'=>sprintf($this->lang->line('required'),$this->lang->line('mobile_no'))]);
		$this->form_validation->set_rules('country',$this->lang->line('country'),
										  'trim|required',
										  ['required'=>sprintf($this->lang->line('required'),$this->lang->line('country'))]);
		$this->form_validation->set_rules('state',$this->lang->line('state'),
										  'trim|required',
										  ['required'=>sprintf($this->lang->line('required'),$this->lang->line('state'))]);
		$this->form_validation->set_rules('city',$this->lang->line('city'),
										  'trim|required',
										  ['required'=>sprintf($this->lang->line('required'),$this->lang->line('city'))]);
		$this->form_validation->set_rules('zip',$this->lang->line('zip'),
										  'trim|numeric|required',
										  ['required'=>sprintf($this->lang->line('required'),$this->lang->line('zip'))]);
		$get_profile_details = $this->login_model->update_user_profile($user_id);
		$get_edit_details 				   = $get_profile_details[0];

		if($this->input->post()){
			//echo 'post';exit;
			if($this->form_validation->run() == TRUE){
				//echo 'true';exit;
				$user['first_name']	= $this->input->post('first_name');
				$user['last_name']	= $this->input->post('last_name');
				$user['dob']		= mysql_custom_date($this->input->post('dob'));
				$user['gender']		= $this->input->post('gender');
				$user['address']	= $this->input->post('address');
				$user['mobile_no']	= $this->input->post('mobile_no');
				$user['country']	= $this->input->post('country');
				$user['state']		= $this->input->post('state');
				$user['city']		= $this->input->post('city');
				$user['zip']		= $this->input->post('zip');
				//$user['dp_status']	= $this->input->post('dp_status');
				//echo '<pre>';print_r($user);exit;
				$existing_image = $get_edit_details->image;
                if ($_FILES['image']['name']) {
                	//print_r($_FILES);exit;
                    $config['upload_path'] = FCPATH.'/assets/profile_image/';//$this->lang->line('set_profile_path');
                    $config['allowed_types'] = 'jpg|png|jpeg';
                    //print_r($config);exit;
                    $this->load->library('upload', $config);
                    $this->upload->initialize($config);
                    if ($this->upload->do_upload('image')) {
                    	//print_r('in');exit;
                        $delete_existing_file = delete_file($this->lang->line('set_profile_path'),$existing_image);//delete the old file
                        $file_data = $this->upload->data();
                        $img_name = $file_data['file_name'];
                        $user['image'] = $img_name;
                    } else {
                    	print_r($this->upload->display_errors());exit;
                        $user['image'] = $_FILES['image']['name'];//$this->input->post('image');
                        //print_r($user);exit;
                    }
                } else {
                    $user['image'] = $existing_image;
                }
                $result = $this->login_model->update_user_by_id($user_id,$user);
                if($result){
                	$this->session->unset_userdata('image');
                	//print_r($user['image']);exit;
                	$this->session->set_userdata('image',$user['image']);
                	$this->session->set_userdata('first_name',$user['first_name']);
                	$this->session->set_userdata('last_name',$user['last_name']);
                	$this->session->set_flashdata('success', $this->lang->line('profile_updated'));
                	redirect('login/update_profile/'.$user_id);
                } else {
                	$this->session->set_flashdata('error', $this->lang->line('profile_notupdated'));
                	redirect('login/update_profile/'.$user_id);
                }
			} //echo 'out';exit;
		}

		//echo '<pre>';print_r($get_edit_details);exit;
		$user_update_details['id']		   = $get_edit_details->id;
		$user_update_details['first_name'] = $get_edit_details->first_name;
		$user_update_details['last_name']  = $get_edit_details->last_name;
		$user_update_details['email']      = $get_edit_details->email;
		$user_update_details['gender']     = $get_edit_details->gender;
		$user_update_details['dob'] 	   = $get_edit_details->dob;
		$user_update_details['image'] 	   = $get_edit_details->image;
		$user_update_details['dp_status']  = NULL;
		$user_update_details['address']    = $get_edit_details->address;
		$user_update_details['mobile_no']  = $get_edit_details->mobile_no;
		$user_update_details['country']    = $get_edit_details->country;
		$user_update_details['state']  	   = $get_edit_details->state;
		$user_update_details['city'] 	   = $get_edit_details->city;
		$user_update_details['zip']  	   = $get_edit_details->zip;
		if($user_update_details){
			$this->template->set_layout('backend-theme');
			$this->template->title($this->lang->line('update_profile'));
			$this->template->build('profile_edit/edit_user_profile',$user_update_details);
		} else {
			redirect('login/dashboard');
		}
	}

	/**
     * This method is used to get state by country
     * @access public
     * @return void
     * */
	public function get_state_by_id(){
		$get_id = $this->input->post('country');
		$get_state = $this->login_model->get_state_based_country($get_id);
		if($get_state){
			echo '<option value="">Select</option>';
        foreach ($get_state as $row) {  
            echo "<option value='" . $row->id . "'>" . $row->name . "</option>";
        }
		} else {
			return false;
		}
	}

	/**
     * This method is used to get city by state
     * @access public
     * @return void
     * */
	public function get_city_by_id(){
		$get_id = $this->input->post('state');
		$get_city = $this->login_model->get_city_based_state($get_id);
		if($get_city){
			echo '<option value="">Select</option>';
        foreach ($get_city as $row) {  
            echo "<option value='" . $row->id . "'>" . $row->name . "</option>";
        }
		} else {
			return false;
		}
	}


	/**
	* This method handles to Port list
	**/
	public function user(){
		//die('in');
		$this->authendication->authendicate_user();
		$this->template->title($this->lang->line('course'));

		$colModel['email'] 				= array($this->lang->line('email'),200,TRUE,'left',1);
		$colModel['user_type'] 			= array($this->lang->line('user_type'),100,TRUE,'left',0);
		$colModel['status'] 			= array($this->lang->line('status'),100,TRUE,'left',0);
		$colModel['login_status'] 		= array($this->lang->line('login_status'),100,TRUE,'left',0);
		$colModel['ip_address'] 		= array($this->lang->line('ip_address'),100,TRUE,'left',0);
		$colModel['last_logged_on'] 	= array($this->lang->line('last_logged_on'),100,TRUE,'left',0);
		$colModel['registered_on'] 		= array($this->lang->line('registered_on'),100,TRUE,'left',0);
		$colModel['actions'] 			= array($this->lang->line('action'),80, FALSE, 'center',0);	

		$gridParams = [
			'width' => 'auto',
			'height' =>'auto',
			//'rp' =>ADMIN_PER_PAGE,
			'rpOptions' => '[50,100,150,200,500]',
			'pagestat' => 'Displaying: {from} to {to} of {total} items.',
			'blockOpacity' => 0.5,
			'title' => '',
			'showTableToggleBtn' => false
		];

		$buttons[] = array('Add User','add','grid_action');

		$grid_js = build_grid_js('flex1',site_url("/login/user_ajax"),$colModel,'id','desc',$gridParams,$buttons);
		//print_r($grid_js);exit;
		$data['js_grid'] = $grid_js;
		$this->template->set_layout('backend-theme');
		$this->template->build('profile_edit/list',$data);
	}

	/**
	* This method handles to build GRID
	**/
	public function user_ajax(){
		//die("inajax");
		$valid_fields = array('id','email','user_type','status');
		$this->flexigrid->validate_post('id','email','user_type', $valid_fields);

		$records = $this->login_model->get_all_users();

		$i = 1;
		foreach ($records['records']->result() as $row){
			$grid_item[] = [
				//$i,
				$i,
				$row->email,
				$row->user_type,
				$row->status,  
				$row->login_status,
				$row->ip_address,
				custom_date($row->last_logged_on),
				custom_date($row->registered_on),
				'<a href=\''.base_url().$this->lang->line('url_user_view').$row->id.'\' title="View"><i class="fa fa-eye text-primary text-semibold"></i></a>&nbsp;'
			];
			$i++;
		}
		
      if (isset($grid_item)){
         $this->output->set_output($this->flexigrid->json_build($records['record_count'],$grid_item));
      }
      else{
         $this->output->set_output('{"page":"1","total":"0","rows":[]}');
      }
	}

	/**
     * This method is used check password and change if the old password is correct
     * @access public
     * @return void
     * */
	public function add_user(){
		$this->authendication->authendicate_user();
		$this->form_validation->set_rules('email',$this->lang->line('email'),
										  'trim|valid_email|required',
										  ['required'=>sprintf($this->lang->line('required'),$this->lang->line('email'))]);

		$this->form_validation->set_rules('password',$this->lang->line('password'),
										  'trim|required',
										  ['required'=>sprintf($this->lang->line('required'),$this->lang->line('password'))]);

		$this->form_validation->set_rules('user_type',$this->lang->line('user_type'),
										  'trim|required',
										  ['required'=>sprintf($this->lang->line('required'),$this->lang->line('user_type'))]);

		$this->form_validation->set_rules('status',$this->lang->line('status'),
										  'trim|required',
										  ['required'=>sprintf($this->lang->line('required'),$this->lang->line('status'))]);
		if($this->input->post()){
			if($this->form_validation->run() == TRUE){
				$user_data['email']  		= $this->input->post('email');
				$user_data['password']  	= md5($this->input->post('password'));
				$user_data['user_type']  	= $this->input->post('user_type');
				$user_data['status']  		= $this->input->post('status');
				
				$get_result = $this->login_model->add_user_one($user_data);
				if($get_result){
					$this->session->set_flashdata('success',$this->lang->line('user_added'));
					redirect('login/add_user');
				} else {
					$this->session->set_flashdata('error',$this->lang->line('user_added_failed'));
					redirect('login/add_user');
				}
			}
		}
		$this->template->set_layout('backend-theme');
		$this->template->title($this->lang->line('add_user'));
		$this->template->build('profile_edit/add_user');
	}

	/**
	* This method handles to view port detail
	**/
	public function view_user($id){
		$data 						= [];
		$result 					= $this->login_model->get_user_by_id($id);
		if($result){
			$result 					= $result[0];
			$data['id'] 				= $result->id; 
			$data['first_name'] 		= $result->first_name; 
			$data['last_name'] 			= $result->last_name;
			$data['email'] 				= $result->email;
			$data['user_type'] 			= $result->user_type;
			$data['gender'] 			= $result->gender; 
			$data['dob'] 				= custom_date($result->dob);
			$data['address'] 			= $result->address;
			$data['mobile_no'] 			= $result->mobile_no;
			$data['image'] 				= $result->image; 
			$data['country'] 			= $result->country; 
			$data['state'] 				= $result->state;
			$data['city'] 				= $result->city;
			$data['zip'] 				= $result->zip;
			$data['status'] 			= $result->status;
			$data['login_status'] 		= $result->login_status; 
			$data['ip_address'] 		= $result->ip_address;
			$data['registered_on'] 		= custom_date($result->registered_on);
			$data['last_logged_on'] 	= custom_date($result->last_logged_on);
		}
		$this->template->title($this->lang->line('profile_view'));
		$this->template->set_layout('backend-theme');
		$this->template->build('profile_edit/view', $data);
	}
	
}
