<!-- PAGE CONTENT WRAPPER -->
<div class="page-content-wrap">


    <div class="row">

        <!-- NEWS WIDGET -->
        <div class="col-md-12">

            <div class="panel panel-default">                            
                <div class="panel-body panel-body-image">
                    <?php $path = $this->lang->line('get_profile_path'); ?>
                    <img src="<?php echo $path.$image; ?>" alt="Ocean" height="500"/>
                    <a href="#" class="panel-body-inform">
                        <span class="fa fa-heart-o"></span>
                    </a>
                </div>
                <div class="panel-body" style="box-shadow: 0 0 20px 0 rgba(0, 400, 180, 0.2), 0 5px 5px 0 rgba(0, 400, 180, 0.24); ">
                    <h3><?php echo $dp_status; ?></h3>
                    <div class="col-md-1">
                        <b><?php echo $this->lang->line('name'); ?></b>
                    </div>
                    <div class="col-md-5">
                        <?php echo $first_name.' '.$last_name; ?> 
                    </div>
                    <div class="col-md-1">
                        <b><?php echo $this->lang->line('e_mail'); ?></b>
                    </div>
                    <div class="col-md-5">
                        <?php echo $email; ?> 
                    </div>
                    <div class="col-md-1">
                        <b><?php echo $this->lang->line('gender'); ?></b>
                    </div>
                    <div class="col-md-5">
                        <?php echo $gender; ?> 
                    </div>
                    <div class="col-md-1">
                        <b>Status</b>
                    </div>
                    <div class="col-md-5">
                        <?php echo $login_status; ?> 
                    </div>
                    <div class="col-md-1">
                        <b><?php echo $this->lang->line('dob_s'); ?></b>
                    </div>
                    <div class="col-md-5">
                        <?php echo $dob; ?> 
                    </div>
                    <div class="col-md-1">
                        <b><?php echo $this->lang->line('address'); ?></b>
                    </div>
                    <div class="col-md-5">
                        <?php echo $address.', '.$city[0]->name.', '.$state[0]->name.', '.$country[0]->name.' '.$zip; ?>
                    </div>
                </div>
                <div class="panel-footer text-muted">
                    <span class="fa fa-clock-o"></span> 3d ago &nbsp;&nbsp;&nbsp;
                    <span class="fa fa-comment-o"></span> 36
                </div>
            </div>

        </div>
        <!-- END NEWS WIDGET -->

        
    </div>

</div>
<!-- END PAGE CONTENT WRAPPER -->