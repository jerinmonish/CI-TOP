<div class="content-frame-body content-frame-body-left">
    <?php echo $this->session->flashdata('success'); ?>
    <?php echo $this->session->flashdata('error'); ?>             
    <div class="panel panel-default push-up-12">
        <div class="panel-body panel-body-search">
            <div class="input-group col-md-12">
            <?php echo form_open_multipart('login/change_password/','class="form-horizontal form-padding" id="form_settings_update"');?>


            <div class="form-group"> 
                <?php echo form_label($this->lang->line('curr_pass').$this->lang->line('mantatory_symbol'), 'Mobile Number', ['class'=>'col-md-3 control-label']); ?>
                <div class="col-sm-7 col-md-4"> 
                  <?php echo form_password(['name'=>'curr_pass', 'id'=>'curr_pass', 'maxlength'=> '30','tabindex'=> '1','class'=>'form-control','placeholder'=>sprintf($this->lang->line('curr_pass'),$this->lang->line('curr_pass')), 'value'=>'']); ?> <?php echo form_error('curr_pass', '<small class="help-block text-danger">&nbsp;', '</small>'); ?>
                  <span id="password_error" style="color: red"></span> 
                </div>
            </div>
            
            <div class="form-group"> 
                <?php echo form_label($this->lang->line('new_pass').$this->lang->line('mantatory_symbol'), 'Zip', ['class'=>'col-md-3 control-label']); ?>
                <div class="col-sm-7 col-md-4"> 
                  <?php echo form_password(['name'=>'new_pass', 'id'=>'new_pass', 'maxlength'=> '30','tabindex'=> '2','class'=>'form-control','placeholder'=>sprintf($this->lang->line('new_pass'),$this->lang->line('new_pass')), 'value'=>'']); ?> <?php echo form_error('new_pass', '<small class="help-block text-danger">&nbsp;', '</small>'); ?> 
                </div>
            </div>

            <div class="form-group"> 
                <?php echo form_label($this->lang->line('confirm_pass').$this->lang->line('mantatory_symbol'), 'Zip', ['class'=>'col-md-3 control-label']); ?>
                <div class="col-sm-7 col-md-4"> 
                  <?php echo form_password(['name'=>'confirm_pass', 'id'=>'confirm_pass', 'maxlength'=> '30','tabindex'=> '3','class'=>'form-control','placeholder'=>sprintf($this->lang->line('confirm_pass'),$this->lang->line('confirm_pass')), 'value'=>'']); ?> <?php echo form_error('confirm_pass', '<small class="help-block text-danger">&nbsp;', '</small>'); ?> 
                  <span id="password_mismatch"></span>
                </div>
            </div>

            <div class="form-group">
              <div class="col-sm-offset-5 col-sm-10 col-md-offset-3 col-md-10">
                <button class="btn btn-info check" type="submit" id="submit" name="Update" tabindex="4"><?php echo $this->lang->line('change-pass'); ?></button>
                <button class="btn btn-primary" type="reset" name="reset" tabindex="5" onclick="window.history.back()"><?php echo $this->lang->line('back'); ?></button>
              </div>
            </div>
            <?php echo form_close();?>
            </div>
        </div>
    </div>

<script>
    $(document).ready(function(){
        document.getElementById("new_pass").disabled = true; 
        document.getElementById("confirm_pass").disabled = true; 
        document.getElementById("submit").disabled = true;
        $("#curr_pass").blur(function(){
            var cur_pass = $("#curr_pass").val();
            var user_id = "<?php echo $this->session->userdata('id');?>";
            //alert(user_id);
            if(cur_pass == ""){
                alert("Please enter current password");
                document.getElementById("new_pass").disabled = true; 
                document.getElementById("confirm_pass").disabled = true; 
                document.getElementById("submit").disabled = true;
                document.getElementById("curr_pass").focus;
                return false;
            } else {
                document.getElementById("new_pass").disabled = false; 
                document.getElementById("confirm_pass").disabled = false;
                document.getElementById("submit").disabled = false;
                var formData = {
                                    current_pass : cur_pass,
                                    id : user_id,
                };
                $.ajax({
                    url : "<?php echo site_url("login/check_password/");?>",
                    type: 'POST',
                    data: formData,
                    success : function (data){
                        if(data == 0){
                            document.getElementById("new_pass").disabled = true; 
                            document.getElementById("confirm_pass").disabled = true; 
                            document.getElementById("submit").disabled = true;
                            document.getElementById("curr_pass").focus;
                            document.getElementById("password_error").innerHTML = "Password Incorrect";
                            return false;
                        } else {
                            document.getElementById("new_pass").disabled = false; 
                            document.getElementById("confirm_pass").disabled = false;
                            document.getElementById("submit").disabled = false;
                            document.getElementById("password_error").innerHTML = "";
                        }
                    }
                });
            }
        });
        $("#confirm_pass").change(function(){
        	var pass_one = $("#new_pass").val();
        	var pass_two = $("#confirm_pass").val();
        	if(pass_one == pass_two){
        		document.getElementById("submit").disabled = false;
        		document.getElementById("password_mismatch").innerHTML = "";
        		return true;
        	} else {
        		document.getElementById("submit").disabled = true;
        		document.getElementById("password_mismatch").innerHTML = "<div class='alert alert-danger alert-dismissable' style='margin:10px 0px 5px 0px'>Password Mismatched !</div>";
        		return false;
        	}
        });
    });
</script>
<!-- END CONTENT FRAME BODY -->  