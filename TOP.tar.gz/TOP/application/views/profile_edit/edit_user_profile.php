<div class="content-frame-body content-frame-body-left">
    <?php echo $this->session->flashdata('success'); ?>
    <?php echo $this->session->flashdata('error'); ?>             
    <div class="panel panel-default push-up-12">
        <div class="panel-body panel-body-search">
            <div class="input-group col-md-12">
            <?php echo form_open_multipart('login/update_profile/'.$id,'class="form-horizontal form-padding" id="form_settings_update"');?>

              <div class="form-group"> 
                <?php echo form_label($this->lang->line('first_name').$this->lang->line('mantatory_symbol'), 'First Name', ['class'=>'col-md-3 control-label']); ?>
                <div class="col-sm-7 col-md-4"> 
                  <?php echo form_input(['name'=>'first_name', 'id'=>'first_name', 'maxlength'=> '15','tabindex'=> '1','class'=>'form-control','placeholder'=>sprintf($this->lang->line('first_name'),$this->lang->line('first_name')), 'value'=>$first_name]); ?> <?php echo form_error('first_name', '<small class="help-block text-danger">&nbsp;', '</small>'); ?> 
                </div>
            </div>
            <div class="form-group"> 
                <?php echo form_label($this->lang->line('last_name').$this->lang->line('mantatory_symbol'), 'Last Name', ['class'=>'col-md-3 control-label']); ?>
                <div class="col-sm-7 col-md-4"> 
                  <?php echo form_input(['name'=>'last_name', 'id'=>'last_name', 'maxlength'=> '15','tabindex'=> '2','class'=>'form-control','placeholder'=>sprintf($this->lang->line('last_name'),$this->lang->line('last_name')), 'value'=>$last_name]); ?> <?php echo form_error('last_name', '<small class="help-block text-danger">&nbsp;', '</small>'); ?> 
                </div>
            </div>
            <div class="form-group"> 
                <?php echo form_label($this->lang->line('gender').$this->lang->line('mantatory_symbol'), 'Gender', ['class'=>'col-md-3 control-label']); ?>
                <div class="col-sm-7 col-md-4">
                    <?php $set_gender = isset($gender) ? $gender:'';?>
                    <?php echo form_radio(['name'=>'gender','id'=>'gender','value'=>'male','checked' => ('male' == $gender) ? TRUE : FALSE]); echo $this->lang->line('male');?>
                    <?php echo form_radio(['name'=>'gender','id'=>'gender','value'=>'female', 'checked' => ('female' == $gender) ? TRUE : FALSE]); echo $this->lang->line('female');?> 
                    <?php echo form_error('first_name', '<small class="help-block text-danger">&nbsp;', '</small>'); ?> 
                </div>
            </div>

            <div class="form-group"> 
                <?php echo form_label($this->lang->line('dob').$this->lang->line('mantatory_symbol'), 'Date Of Birth', ['class'=>'col-md-3 control-label']); ?>
                <div class="col-sm-7 col-md-4"> 
                  <?php echo form_input(['name'=>'dob', 'id'=>'dob', 'maxlength'=> '10','tabindex'=> '4','class'=>'form-control datepicker','placeholder'=>sprintf($this->lang->line('dob'),$this->lang->line('dob')), 'value'=>$dob]); ?> <?php echo form_error('dob', '<small class="help-block text-danger">&nbsp;', '</small>'); ?> 
                </div>
            </div>
            <div class="form-group"> 
                <?php echo form_label($this->lang->line('e_mail').$this->lang->line('mantatory_symbol'), 'E-mail', ['class'=>'col-md-3 control-label']); ?>
                <div class="col-sm-7 col-md-4"> 
                  <?php echo form_input(['name'=>'e_mail', 'id'=>'e_mail', 'maxlength'=> '100','tabindex'=> '5','class'=>'form-control','placeholder'=>sprintf($this->lang->line('e_mail'),$this->lang->line('e_mail')), 'value'=>$email,'readonly'=>'true']); ?> <?php echo form_error('e_mail', '<small class="help-block text-danger">&nbsp;', '</small>'); ?> 
                </div>
            </div>
            <div class="form-group"> 
                <?php echo form_label($this->lang->line('address').$this->lang->line('mantatory_symbol'), 'Address', ['class'=>'col-md-3 control-label']); ?>
                <div class="col-sm-7 col-md-4"> 
                  <?php echo form_textarea(['name'=>'address', 'id'=>'address','tabindex'=> '6','class'=>'form-control','placeholder'=>sprintf($this->lang->line('address'),$this->lang->line('address')), 'value'=>$address]); ?> <?php echo form_error('address', '<small class="help-block text-danger">&nbsp;', '</small>'); ?> 
                </div>
            </div>
            <div class="form-group"> 
                <?php echo form_label($this->lang->line('mobile_no').$this->lang->line('mantatory_symbol'), 'Mobile Number', ['class'=>'col-md-3 control-label']); ?>
                <div class="col-sm-7 col-md-4"> 
                  <?php echo form_input(['name'=>'mobile_no', 'id'=>'mobile_no', 'maxlength'=> '10','tabindex'=> '7','class'=>'form-control','placeholder'=>sprintf($this->lang->line('mobile_no'),$this->lang->line('mobile_no')), 'value'=>$mobile_no]); ?> <?php echo form_error('mobile_no', '<small class="help-block text-danger">&nbsp;', '</small>'); ?> 
                </div>
            </div>
            <?php
                $get_country = get_countries();
            ?>
            <div class="form-group"> 
                <?php echo form_label($this->lang->line('country').$this->lang->line('mantatory_symbol'), 'Country', ['class'=>'col-md-3 control-label']); ?>
                <div class="col-sm-7 col-md-4"> 
                  <?php echo form_dropdown('country',$get_country,(isset($country) ? $country : set_value('country')),['name'=>'country', 'id'=>'country','tabindex'=> '8','class'=>'form-control','placeholder'=>sprintf($this->lang->line('country'),$this->lang->line('country'))]); ?> 
                  <?php echo form_error('country', '<small class="help-block text-danger">&nbsp;', '</small>'); 
                  ?> 
                </div>
            </div>
            <?php
                //$get_state = get_states();
            //print_r($country.'/'.$state);
                if($country){
                    $set_state = get_state_on_update($country,$state);
                    //print_r($set_state);
                    $user_state= isset($set_state) ? $set_state[0]->name : '';
                    $set_sta = array($state => $user_state);
                } else {
                    $set_state = '';
                    $user_state = '';
                    $set_sta = '';
                }
            ?>

            <div class="form-group"> 
                <?php echo form_label($this->lang->line('state').$this->lang->line('mantatory_symbol'), 'State', ['class'=>'col-md-3 control-label']); ?>
                <div class="col-sm-7 col-md-4"> 
                <?php echo form_dropdown('state',$set_sta,(isset($state) ? $state : set_value('state')),['name'=>'state', 'id'=>'state','tabindex'=> '8','class'=>'form-control','placeholder'=>sprintf($this->lang->line('state'),$this->lang->line('state'))]); ?> 
                 <?php echo form_error('state', '<small class="help-block text-danger">&nbsp;', '</small>'); ?> 
                </div>
            </div>
            <?php
                if($country){
                    //$get_city = get_cities();
                    $set_city = get_city_on_update($state,$city);
                    $user_city= isset($set_city) ? $set_city[0]->name : ''; 
                    $set_cty = array($city => $user_city);
                } else {
                    $set_city = '';
                    $user_city= ''; 
                    $set_cty = '';
                }
            ?>
            <div class="form-group"> 
                <?php echo form_label($this->lang->line('city').$this->lang->line('mantatory_symbol'), 'City', ['class'=>'col-md-3 control-label']); ?>
                <div class="col-sm-7 col-md-4"> 
                <?php echo form_dropdown('city',$set_cty,(isset($city) ? $city : set_value('city')),['name'=>'city', 'id'=>'city','tabindex'=> '8','class'=>'form-control','placeholder'=>sprintf($this->lang->line('city'),$this->lang->line('city'))]); ?> 
                 <?php echo form_error('city', '<small class="help-block text-danger">&nbsp;', '</small>'); ?> 
                </div>
            </div>
            <div class="form-group"> 
                <?php echo form_label($this->lang->line('zip').$this->lang->line('mantatory_symbol'), 'Zip', ['class'=>'col-md-3 control-label']); ?>
                <div class="col-sm-7 col-md-4"> 
                  <?php echo form_input(['name'=>'zip', 'id'=>'zip', 'maxlength'=> '5','tabindex'=> '10','class'=>'form-control','placeholder'=>sprintf($this->lang->line('zip'),$this->lang->line('zip')), 'value'=>$zip]); ?> <?php echo form_error('zip', '<small class="help-block text-danger">&nbsp;', '</small>'); ?> 
                </div>
            </div>
            <!--div class="form-group"> 
                <?php //echo form_label($this->lang->line('my_dp'), 'My Status', ['class'=>'col-md-3 control-label']); ?>
                <div class="col-sm-7 col-md-4"> 
                  <?php //echo form_input(['name'=>'dp_status', 'id'=>'dp_status', 'maxlength'=> '100','tabindex'=> '11','class'=>'form-control','placeholder'=>sprintf($this->lang->line('dp_status'),$this->lang->line('dp_status')), 'value'=>$dp_status]); ?> <?php //echo form_error('dp_status', '<small class="help-block text-danger">&nbsp;', '</small>'); ?> 
                </div>
            </div-->
            <div class="form-group"> 
                <?php echo form_label($this->lang->line('existing_image').$this->lang->line('mantatory_symbol'), 'Existing Image', ['class'=>'col-md-3 control-label']); ?>
                <div class="col-sm-2">
                    <img src="<?php echo $this->lang->line('set_profile_path').'/'.$image; ?>" width="100" height="80" style="border-radius: 5px;">
                </div>
                <div class="col-sm-7 col-md-4"> 
                  <?php echo form_upload(['name'=>'image', 'id'=>'image','tabindex'=> '12','class'=>'form-control','onChange'=>'validate(this.value)','accept'=>'image/gif, image/jpeg, image/jpg, image/png']); ?> 
                  <?php echo form_error('image', '<small class="help-block text-danger">&nbsp;', '</small>'); ?> 
                </div>
            </div>
            <div class="form-group">
              <div class="col-sm-offset-5 col-sm-10 col-md-offset-3 col-md-10">
                <button class="btn btn-info" type="submit" name="Update" tabindex="13"><?php echo $this->lang->line('update_profile'); ?></button>
                <button class="btn btn-primary" type="reset" name="reset" tabindex="14" onclick="window.history.back()"><?php echo $this->lang->line('back'); ?></button>
              </div>
            </div>
            <?php echo form_close();?>
            </div>
        </div>
    </div>
    <script>
        $(document).ready(function(){
            /*$('.datepicker').datepicker(function(){
                //alert('in');
                endDate:today
            });*/
            $("#country").change(function(){
            	var country_detail = $("#country").val();
                var formData = {
                                country : country_detail,
                           };
            	$.ajax({
                url: "<?php echo site_url('login/get_state_by_id/')?>",
                type: 'POST',
                data: formData,
                success: function (data) {
                        //alert(data);
                        $("#state").html(data);
                }
            });
            	
            });

            $("#state").change(function(){
                var state_detail = $("#state").val();
                var formData = {
                                state : state_detail,
                           };
                $.ajax({
                url: "<?php echo site_url('login/get_city_by_id/')?>",
                type: 'POST',
                data: formData,
                success: function (data) {
                        //alert(data);
                        $("#city").html(data);
                }
            });
                
            });
        });
    function validate(file) {
        var ext = file.split(".");
        ext = ext[ext.length-1].toLowerCase();      
        var arrayExtensions = ["jpg" , "jpeg", "png", "gif"];

        if (arrayExtensions.lastIndexOf(ext) == -1) {
            alert("Invalid image type.");
            $("#image").val("");
        }
    }
    </script>

<!-- END CONTENT FRAME BODY -->  