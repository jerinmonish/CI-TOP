<?php 
	/***
	File Name 		: view.php
	Description 	: This file is to view site configuration
	Author 			: Loganathan N, A.C Jerin Monish <jerinmonish007@gmail.com>
	**/
?>
<div class="col-md-6 table-responsive">
	<table class="table table-striped">
		<tr>
			<td><span class="text-semibold"><?php echo $this->lang->line('first_name'); ?></span></td>
			<td><?php echo $first_name; ?></td>
		</tr>
		<tr>
			<td><span class="text-semibold"><?php echo $this->lang->line('last_name'); ?></span></td>
			<td><?php echo $last_name; ?></td>
		</tr>
		<tr>
			<td><span class="text-semibold"><?php echo $this->lang->line('email'); ?></span></td>
			<td><?php echo $email; ?></td>
		</tr>
		<tr>
			<td><span class="text-semibold"><?php echo $this->lang->line('gender'); ?></span></td>
			<td><?php echo $gender; ?></td>
		</tr>
		<tr>
			<td><span class="text-semibold"><?php echo $this->lang->line('dob'); ?></span></td>
			<td><?php echo $dob; ?></td>
		</tr>
		<tr>
			<td><span class="text-semibold"><?php echo $this->lang->line('address'); ?></span></td>
			<td><?php echo $address; ?></td>
		</tr>
		<tr>
			<td><span class="text-semibold"><?php echo $this->lang->line('mobile_no'); ?></span></td>
			<td><?php echo $mobile_no; ?></td>
		</tr>
		<tr>
			<td><span class="text-semibold"><?php echo $this->lang->line('country'); ?></span></td>
			<td><?php echo $country; ?></td>
		</tr>
		<tr>
			<td><span class="text-semibold"><?php echo $this->lang->line('state'); ?></span></td>
			<td><?php echo $state; ?></td>
		</tr>
		<tr>
			<td><span class="text-semibold"><?php echo $this->lang->line('city'); ?></span></td>
			<td><?php echo $city; ?></td>
		</tr>
		<tr>
			<td><span class="text-semibold"><?php echo $this->lang->line('zip'); ?></span></td>
			<td><?php echo $zip; ?></td>
		</tr>
		<tr>
			<td><span class="text-semibold"><?php echo $this->lang->line('status'); ?></span></td>
			<td><?php echo $status; ?></td>
		</tr>
		<tr>
			<td><span class="text-semibold"><?php echo $this->lang->line('login_status'); ?></span></td>
			<td><?php echo $login_status; ?></td>
		</tr>
		<tr>
			<td><span class="text-semibold"><?php echo $this->lang->line('ip_address'); ?></span></td>
			<td><?php echo $ip_address; ?></td>
		</tr>
		<tr>
			<td><span class="text-semibold"><?php echo $this->lang->line('registered_on'); ?></span></td>
			<td><?php echo $registered_on; ?></td>
		</tr>
		<tr>
			<td><span class="text-semibold"><?php echo $this->lang->line('last_logged_on'); ?></span></td>
			<td><?php echo $last_logged_on; ?></td>
		</tr>
		<tr>
			<td><span class="text-semibold"><?php echo $this->lang->line('image'); ?></span></td>
			<td><img src="<?php echo base_url().'assets/profile_image/'.$image;?>" alt="User Image" class="img-circle" width="50" height="50" title="User Image"></td>
		</tr>
		<tr>
			<td><span class="text-semibold"><?php echo $this->lang->line('user_type'); ?></span></td>
			<td><?php echo $user_type; ?></td>
		</tr>
	</table>
	<div>
	<!--a class="btn btn-info" title="Update" href="<?php //echo base_url().$this->lang->line('url_course_edit').$id; ?>">Update</a-->
		<a class="btn btn-default" title="Back" onclick="window.history.back()">Back</a>
	</div>
</div>