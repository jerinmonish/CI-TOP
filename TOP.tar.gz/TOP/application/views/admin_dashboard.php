<?php
	$first_name = $this->session->userdata('first_name');
	$last_name = $this->session->userdata('last_name');
    $email = $this->session->userdata('email');
    $user_id = $this->session->userdata('id');
	echo '<h1>Hi '.wish_user().' ,'.$first_name.' '.$last_name.'.. Welcome back !</h1>';
?>
<p>
<p>Quotes Of The Week</p>
	<section class="awNotices">
    <?php 
        $quote = get_all_quotes();
        if($quote){
            foreach($quote as $quote_all){
    ?>
    	  <a href="#" notice-color="<?php echo $quote_all->i_color; ?>">
            <i class="<?php echo $quote_all->i_class; ?>"></i>
            <?php echo $quote_all->content; ?>
          </a>
      <?php 
            }
                } else {
      ?>
        <a href="#" notice-color="red"><i class="fa fa-heart"></i>A people without the knowledge of their past history, origin and culture is like a tree without roots.</a>
        <?php } ?>
	</section>
</p>
<!-- START WIDGETS -->
                    <div class="row" style="margin-top:70px;">
                    <?php echo $this->session->flashdata('success');?>
                    <?php echo $this->session->flashdata('error');?>
                        
                        <div class="col-md-3 pull-right">
                            <!-- START WIDGET CLOCK -->
                            <div class="widget widget-info widget-padding-sm">
                                <div class="widget-big-int plugin-clock">00:00</div>                            
                                <div class="widget-subtitle plugin-date">Loading...</div>
                                <div class="widget-controls">                                
                                    <a href="#" class="widget-control-right widget-remove" data-toggle="tooltip" data-placement="left" title="Today"><span class="fa fa-times"></span></a>
                                </div>                            
                                <div class="widget-buttons widget-c3">
                                    <div class="col">
                                        <a href="#"><span class="fa fa-clock-o"></span></a>
                                    </div>
                                    <div class="col">
                                        <a href="#"><span class="fa fa-bell"></span></a>
                                    </div>
                                    <div class="col">
                                        <a href="#"><span class="fa fa-calendar"></span></a>
                                    </div>
                                </div>                            
                            </div>                        
                            <!-- END WIDGET CLOCK -->
                        </div>
                    </div>
                    <!-- END WIDGETS -->   
<p>Tutorialspoint.com is a dedicated website to provide quality online education in the domains of Computer Science, Information Technology, Programming Languages, and other Engineering as well as Management subjects. This website was launched by an AMU alumni, Mr. Mohtashim, with a single tutorial on HTML in year 2006.</p>

<p>At present, this website is developed and maintained by Tutorials Point (I) Pvt. Ltd., which established on 12th June, 2014. (Twelfth day of June Two Thousand Fourteen), under the Companies Act, 2013. The CIN of the company is “U80904AP2014PTC094598”</p>
<p>
    We are located in Hyderabad, the beautiful city of Nizam. Our postal address is −

 Postal Address: Tutorials Point (I) Pvt. Ltd., 3rd Floor, Vamsiram's Jyothi Celestia, Kavuri Hills, Phase-2, Madhapur, Hyderabad, INDIA-500081 INDIA

 Email: contact@tutorialspoint.com

 Website: www.tutorialspoint.com
</p>
<p>
    <p><b>Can we rely on your tutorials and trainings in terms of their quality?</b></p>
To answer this, we would like to say that it’s our business to provide quality tutorials without charging a fee. We are striving hard to maintain the quality of our tutorials as high as possible. Our tutorials and training materials are being used by a lot of freelancer trainers and training companies as well to teach their students.
</p>