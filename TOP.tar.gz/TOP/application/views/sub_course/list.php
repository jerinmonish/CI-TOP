    <?php echo $this->session->flashdata('success'); ?>
    <?php echo $this->session->flashdata('error'); ?>  
<?php echo $js_grid; ?>
<table id="flex1" style="display:none" class=""></table>

<script type="text/javascript">
	var add_url = '<?php echo base_url().$this->lang->line("url_sub_course_add") ?>';
	function grid_action(com,grid){

	if (com=='Add Sub Topic'){ 
		window.location.href = add_url;
    }

    if (com=='Select All'){
		$('.bDiv tbody tr',grid).addClass('trSelected');
    }
    
    if (com=='DeSelect All'){
		$('.bDiv tbody tr',grid).removeClass('trSelected');
    }
    
    if (com=='Delete'){
	   if($('.trSelected',grid).length>0){
		   if(confirm('Delete ' + $('.trSelected',grid).length + ' items?')){
				var items = $('.trSelected',grid);
				var itemlist ='';
				for(i=0;i<items.length;i++){
					itemlist+= items[i].id.substr(3)+",";
				}
				$.ajax({
				   type: "POST",
				   url: "<?php echo site_url("/countries_feed/deletec");?>",
				   data: "items="+itemlist,
				   success: function(data){
					$('#flex1').flexReload();
					alert(data);
				   }
				});
			}
		} else {
			return false;
		} 
	}          
} 
</script>