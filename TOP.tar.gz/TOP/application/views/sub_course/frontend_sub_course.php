    <?php echo $this->session->flashdata('success'); ?>
    <?php echo $this->session->flashdata('error'); ?> 
<div id="jerin">
<?php 
    if($sub_course){
        foreach ($sub_course as $key => $value) {
            //print_r($value);
?>
<div class="col-md-4">
    <img src="<?php echo base_url();?>assets/sub_course/icons/<?php echo $value->topic_img; ?>" width="80" height="60">
    <div>
        <a href="<?php echo base_url();?>assets/sub_course/pdf/<?php echo $value->topic_pdf; ?>">
            <button class="btn btn-info btn-rounded"><?php echo $value->topic_name; ?></button>
        </a>
    </div>
    <div>
        <?php 
            $get_pass_fail = get_user_already_quiz($value->id);
            if($get_pass_fail){
                foreach ($get_pass_fail as $pass_fail) {            
                    if($pass_fail->stu_status == FAIL && $pass_fail->topic_status == INCOMPLETE){
        ?>
                        <a href="<?php echo base_url();?>course/quiz/<?php echo $value->id.'/'.$value->course_id;?>">
                            <button class="btn btn-danger btn-rounded">Attend Test</button>
                        </a>
        <?php } else if($pass_fail->stu_status == PASS && $pass_fail->topic_status == COMPLETED){ ?>
                        <a href="<?php echo base_url();?>course/get_certificate/<?php echo $value->id.'/'.$value->course_id; ?>">
                            <button class="btn btn-danger btn-rounded">Print Certificate</button>
                        </a>
        <?php }
                } 
            } else {
        ?>
            <a href="<?php echo base_url();?>course/quiz/<?php echo $value->id.'/'.$value->course_id;?>">
                <button class="btn btn-danger btn-rounded">Attend Test</button>
            </a>
        <?php } ?>
    </div>
</div>
<?php 
        }
    } else {
?>
    <button class="btn btn-danger" id="pc_remove" onclick="window.history.back()">Back</button>
    <div class = "alert alert-danger alert-dismissable">
        <button type = "button" class = "close" data-dismiss = "alert" aria-hidden = "true">&times;</button>
        No such topics... !
    </div>
<?php } ?>
</div>
<style type="text/css">
    #jerin{
        background-image: url(<?php echo base_url();?>assets/sub_course/sub_bg.jpg);
        @background-color: red;
        @background-repeat: no-repeat;
        @background-size: contain;
        background-position: 85% 15%;
        @left: 150px;
        @top: 100px;
        height: 500px;
        width: 1030px;
        color: red;
        text-align: center;
        font-weight: bolder;
        padding:20px 20px 40px 20px;
    }
</style>