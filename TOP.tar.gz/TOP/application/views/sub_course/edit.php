
    <?php echo $this->session->flashdata('success'); ?>
    <?php echo $this->session->flashdata('error'); ?>             
    <div class="panel panel-default push-up-12">
        <div class="panel-body panel-body-search">
            <div class="input-group col-md-12">
            <?php echo form_open_multipart('course/edit_sub_course/'.$id,'class="form-horizontal form-padding" id="form_course_sub_add"');?>

                <div class="form-group">
                <?php $get_all_course = get_all_course();?>
                    <?php echo form_label($this->lang->line('course_id').$this->lang->line('mantatory_symbol'), 'Course Id', ['class'=>'col-md-3 control-label']); ?>
                    <div class="col-sm-7 col-md-4"> 
                      <?php echo form_dropdown('course_id',$get_all_course,[$course_id]); ?> 
                      <?php echo form_error('course_id', '<small class="help-block text-danger">&nbsp;', '</small>'); 
                      ?> 
                    </div>
                </div>

              <div class="form-group"> 
                <?php echo form_label($this->lang->line('topic_name').$this->lang->line('mantatory_symbol'), 'Topic Name', ['class'=>'col-md-3 control-label']); ?>
                <div class="col-sm-7 col-md-4"> 
                  <?php echo form_input(['name'=>'topic_name','value'=>$topic_name, 'id'=>'topic_name', 'maxlength'=> '50','tabindex'=> '1','class'=>'form-control','placeholder'=>sprintf($this->lang->line('topic_name'),$this->lang->line('topic_name'))]); ?> 
                  <?php echo form_error('topic_name', '<small class="help-block text-danger">&nbsp;', '</small>'); ?> 
                </div>
            </div>
            <div class="form-group"> 
                <?php echo form_label($this->lang->line('topic_short_name').$this->lang->line('mantatory_symbol'), 'Topic Short Name', ['class'=>'col-md-3 control-label']); ?>
                <div class="col-sm-7 col-md-4"> 
                  <?php echo form_input(['name'=>'topic_short_name','value'=>$topic_short_name, 'id'=>'topic_short_name', 'maxlength'=> '10','tabindex'=> '2','class'=>'form-control','placeholder'=>sprintf($this->lang->line('topic_short_name'),$this->lang->line('topic_short_name'))]); ?> 
                  <?php echo form_error('topic_short_name', '<small class="help-block text-danger">&nbsp;', '</small>'); ?> 
                </div>
            </div>

            <div class="form-group">
            <?php echo form_label($this->lang->line('existing_image').$this->lang->line('mantatory_symbol'), 'Existing Image', ['class'=>'col-md-3 control-label']); ?>
                <div class="col-sm-2">
                    <img src="<?php echo $this->lang->line('set_sub_course_imgs').'/'.$topic_img; ?>" width="100" height="80" style="border-radius: 5px;">
                </div>
                <?php echo form_label($this->lang->line('topic_img').$this->lang->line('mantatory_symbol'), 'Topic Image', ['class'=>'col-md-3 control-label']); ?>
                <div class="col-sm-7 col-md-4"> 
                  <?php echo form_upload(['name'=>'topic_img', 'id'=>'topic_img','tabindex'=> '12','class'=>'form-control','onChange'=>'validate(this.value)']); ?>  
                </div>
            </div>

            <div class="form-group">
            <?php echo form_label($this->lang->line('existing_pdf').$this->lang->line('mantatory_symbol'), 'Existing PDF', ['class'=>'col-md-3 control-label']); ?>
                <div class="col-sm-2">
                    <a href="<?php echo base_url().'assets/sub_course/pdf/'.$topic_pdf;?>" alt="Topic Pdf" class="img-circle" width="50" height="50" title="Topic Pdf" target="_blank"><?php echo $topic_pdf; ?></a>
                </div>
                <?php echo form_label($this->lang->line('topic_pdf').$this->lang->line('mantatory_symbol'), 'Topic PDF', ['class'=>'col-md-3 control-label']); ?>
                <div class="col-sm-7 col-md-4"> 
                  <?php echo form_upload(['name'=>'topic_pdf', 'id'=>'topic_pdf','tabindex'=> '12','class'=>'form-control','onChange'=>'validate(this.value)','accept'=>'.pdf']); ?>  
                </div>
            </div>

            <div class="form-group">
            <?php 
                $options = array(''=>'Choose an item','Active' => 'Active', 'Inactive' => 'Inactive');
            ?>
                <?php echo form_label($this->lang->line('status').$this->lang->line('mantatory_symbol'), 'Course Status', ['class'=>'col-md-3 control-label']); ?>
                <div class="col-sm-7 col-md-4"> 
                  <?php echo form_dropdown('status',$options,[$status]); ?> 
                  <?php echo form_error('status', '<small class="help-block text-danger">&nbsp;', '</small>'); 
                  ?> 
                </div>
            </div>
            <div class="form-group">
              <div class="col-sm-offset-5 col-sm-10 col-md-offset-3 col-md-10">
                <button class="btn btn-info" type="submit" name="save" value="save" tabindex="13"><?php echo $this->lang->line('save'); ?></button>
                <button class="btn btn-primary" tabindex="14" onclick="window.history.back()"><?php echo $this->lang->line('back'); ?></button>
              </div>
            </div>
            <?php echo form_close();?>
            </div>
        </div>
    <script>
        $(document).ready(function(){
            function validate(file) {
                var ext = file.split(".");
                ext = ext[ext.length-1].toLowerCase();      
                var arrayExtensions = ["jpg" , "jpeg", "png", "gif", "svg"];

                if (arrayExtensions.lastIndexOf(ext) == -1) {
                    alert("Invalid image type.");
                    $("#topic_img").val("");
                }
            }
        });
    </script>

<!-- END CONTENT FRAME BODY -->  