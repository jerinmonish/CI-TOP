<?php 
    /***
    File Name       : view.php
    Description     : This file is to view site configuration
    Author          : Loganathan N, A.C Jerin Monish <jerinmonish007@gmail.com>
    **/
    if($all_course){
        foreach ($all_course as $key => $value) {
            //print_r($value);
?>
<div class="col-md-4">
            <div class="panel panel-default">
                <div class="panel-body profile">
                    <div class="profile-image">
                    <img src="<?php echo base_url();?>assets/course/course_images/<?php echo $value->course_image; ?>" alt="<?php echo $value->course_name; ?>">
                    </div>
                    <div class="profile-data">
                        <div class="profile-data-name"><?php echo $value->course_name; ?></div>
                        <div class="profile-data-title"><?php echo $value->course_short_name; ?></div>
                    </div>
                    <!--div class="profile-controls">
                        <a href="#" class="profile-control-left"><span class="fa fa-info"></span></a>
                        <a href="#" class="profile-control-right"><span class="fa fa-phone"></span></a>
                    </div-->
                </div>                                
                <div class="panel-body">                                    
                    <div class="contact-info">
                        <p><?php echo substr($value->course_description,0,90).'...'; ?></p>
                        <?php //if(!($users->id == $cur_user_id)){ ?>
                        <center>
                        <a href="<?php echo base_url();?>course/get_sub_course/<?php echo $value->id; ?>">
                                <button class="btn btn-info col-md-5 get_popup"  style="size:10px;"><span class="fa fa-envelope"></span>Open</button>
                        </a>
                        </center>
                            <div class="col-md-2"></div>
                            <!--button class="btn btn-danger col-md-5 send_request" style="size:10px;"><span class="fa fa-share"></span>Send Request</button>
                        <?php //} else { ?>
                            <button class="btn btn-warning col-md-5"><span class="fa fa-user"></span>Its You</button-->
                        <?php //} ?>
                    </div>
                </div>                                
            </div>
         </div>

    <?php 
        }
            } else { ?>
                <div class = "alert alert-danger alert-dismissable">
                    <button type = "button" class = "close" data-dismiss = "alert" aria-hidden = "true">&times;</button>
                    No such topics... !
                </div>
    <?php } ?>