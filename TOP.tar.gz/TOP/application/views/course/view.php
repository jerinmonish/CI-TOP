<?php 
	/***
	File Name 		: view.php
	Description 	: This file is to view site configuration
	Author 			: Loganathan N, A.C Jerin Monish <jerinmonish007@gmail.com>
	**/
?>
<div class="col-md-6 table-responsive">
	<table class="table table-striped">
		<tr>
			<td><span class="text-semibold"><?php echo $this->lang->line('course_name'); ?></span></td>
			<td><?php echo $course_name; ?></td>
		</tr>
		<tr>
			<td><span class="text-semibold"><?php echo $this->lang->line('course_short_name'); ?></span></td>
			<td><?php echo $course_short_name; ?></td>
		</tr>
		<tr>
			<td><span class="text-semibold"><?php echo $this->lang->line('status'); ?></span></td>
			<td><?php echo $status; ?></td>
		</tr>
		<tr>
			<td><span class="text-semibold"><?php echo $this->lang->line('course_image'); ?></span></td>
			<td><img src="<?php echo base_url().'assets/course/course_images/'.$course_image;?>" alt="Course logo" class="img-circle" width="50" height="50" title="Course logo"></td>
		</tr>
		<tr>
			<td><span class="text-semibold"><?php echo $this->lang->line('created_on'); ?></span></td>
			<td><?php echo $created_on; ?></td>
		</tr>
	</table>
	<div>
	<a class="btn btn-info" title="Update" href="<?php echo base_url().$this->lang->line('url_course_edit').$id; ?>">Update</a>
		<a class="btn btn-default" title="Back" href="<?php echo base_url(); ?>course/">Back</a>
	</div>
</div>