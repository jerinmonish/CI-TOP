
    <?php echo $this->session->flashdata('success'); ?>
    <?php echo $this->session->flashdata('error'); ?>             
    <div class="panel panel-default push-up-12">
        <div class="panel-body panel-body-search">
            <div class="input-group col-md-12">
            <?php echo form_open_multipart('course/add/','class="form-horizontal form-padding" id="form_course_add"');?>

              <div class="form-group"> 
                <?php echo form_label($this->lang->line('course_name').$this->lang->line('mantatory_symbol'), 'Course Name', ['class'=>'col-md-3 control-label']); ?>
                <div class="col-sm-7 col-md-4"> 
                  <?php echo form_input(['name'=>'course_name', 'id'=>'course_name', 'maxlength'=> '50','tabindex'=> '1','class'=>'form-control','placeholder'=>sprintf($this->lang->line('course_name'),$this->lang->line('course_name'))]); ?> 
                  <?php echo form_error('course_name', '<small class="help-block text-danger">&nbsp;', '</small>'); ?> 
                </div>
            </div>
            <div class="form-group"> 
                <?php echo form_label($this->lang->line('course_short_name').$this->lang->line('mantatory_symbol'), 'Course Short Name', ['class'=>'col-md-3 control-label']); ?>
                <div class="col-sm-7 col-md-4"> 
                  <?php echo form_input(['name'=>'course_short_name', 'id'=>'course_short_name', 'maxlength'=> '10','tabindex'=> '2','class'=>'form-control','placeholder'=>sprintf($this->lang->line('course_short_name'),$this->lang->line('course_short_name'))]); ?> 
                  <?php echo form_error('course_short_name', '<small class="help-block text-danger">&nbsp;', '</small>'); ?> 
                </div>
            </div>

            <div class="form-group"> 
                <?php echo form_label($this->lang->line('course_description').$this->lang->line('mantatory_symbol'), 'Course Description', ['class'=>'col-md-3 control-label']); ?>
                <div class="col-sm-7 col-md-4"> 
                <?php 
                    $message = array('name'=>'course_description', 'id'=>'course_description', 'maxlength'=> '40','tabindex'=> '2','class'=>'form-control','placeholder'=>sprintf($this->lang->line('course_description'),$this->lang->line('course_description')));
                  echo form_textarea($message);
                  echo form_error('course_description', '<small class="help-block text-danger">&nbsp;', '</small>'); ?> 
                </div>
            </div>

            <div class="form-group"> 
                <?php echo form_label($this->lang->line('course_image').$this->lang->line('mantatory_symbol'), 'Course Image', ['class'=>'col-md-3 control-label']); ?>
                <div class="col-sm-7 col-md-4"> 
                  <?php echo form_upload(['name'=>'course_image', 'id'=>'course_image','tabindex'=> '12','class'=>'form-control','onChange'=>'validate(this.value)','accept'=>'image/gif, image/jpeg, image/jpg, image/png']); ?>  
                </div>
            </div>

            <div class="form-group">
            <?php 
                $options = array(''=>'Choose an item','Active' => 'Active', 'Inactive' => 'Inactive');
            ?>
                <?php echo form_label($this->lang->line('status').$this->lang->line('mantatory_symbol'), 'Course Status', ['class'=>'col-md-3 control-label']); ?>
                <div class="col-sm-7 col-md-4"> 
                  <?php echo form_dropdown('status',$options); ?> 
                  <?php echo form_error('status', '<small class="help-block text-danger">&nbsp;', '</small>'); 
                  ?> 
                </div>
            </div>
            <div class="form-group">
              <div class="col-sm-offset-5 col-sm-10 col-md-offset-3 col-md-10">
                <button class="btn btn-info" type="submit" name="save" value="save" tabindex="13"><?php echo $this->lang->line('save'); ?></button>
                <button class="btn btn-primary" tabindex="14" onclick="window.history.back()"><?php echo $this->lang->line('back'); ?></button>
              </div>
            </div>
            <?php echo form_close();?>
            </div>
        </div>
    <script>
        $(document).ready(function(){
            function validate(file) {
                var ext = file.split(".");
                ext = ext[ext.length-1].toLowerCase();      
                var arrayExtensions = ["jpg" , "jpeg", "png", "gif"];

                if (arrayExtensions.lastIndexOf(ext) == -1) {
                    alert("Invalid image type.");
                    $("#course_image").val("");
                }
            }
        });
    </script>

<!-- END CONTENT FRAME BODY -->  