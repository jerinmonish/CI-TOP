
    <?php echo $this->session->flashdata('success'); ?>
    <?php echo $this->session->flashdata('error'); ?>             
    <div class="panel panel-default push-up-12">
        <div class="panel-body panel-body-search">
            <div class="input-group col-md-12">
            <?php echo form_open_multipart('quiz/edit/'.$id,'class="form-horizontal form-padding" id="form_course_add"');?>

              <div class="form-group"> 
                <?php echo form_label($this->lang->line('question').$this->lang->line('mantatory_symbol'), 'Question', ['class'=>'col-md-3 control-label']); ?>
                <div class="col-sm-7 col-md-4"> 
                  <?php echo form_input(['name'=>'question', 'id'=>'question', 'value'=>$question,'maxlength'=> '50','tabindex'=> '1','class'=>'form-control','placeholder'=>sprintf($this->lang->line('question'),$this->lang->line('question'))]); ?> 
                  <?php echo form_error('question', '<small class="help-block text-danger">&nbsp;', '</small>'); ?> 
                </div>
            </div>

            <div class="form-group"> 
                <?php echo form_label($this->lang->line('answer').$this->lang->line('mantatory_symbol'), 'Answer', ['class'=>'col-md-3 control-label']); ?>
                <div class="col-sm-7 col-md-4"> 
                  <?php echo form_input(['name'=>'answer', 'id'=>'answer', 'value'=>$answer,'maxlength'=> '10','tabindex'=> '2','class'=>'form-control','placeholder'=>sprintf($this->lang->line('answer'),$this->lang->line('answer'))]); ?> 
                  <?php echo form_error('answer', '<small class="help-block text-danger">&nbsp;', '</small>'); ?> 
                </div>
            </div>

            <div class="form-group"> 
                <?php echo form_label($this->lang->line('option1').$this->lang->line('mantatory_symbol'), 'Option A', ['class'=>'col-md-3 control-label']); ?>
                <div class="col-sm-7 col-md-4"> 
                  <?php echo form_input(['name'=>'option1', 'id'=>'option1','value'=>$option1,'maxlength'=> '50','tabindex'=> '1','class'=>'form-control','placeholder'=>sprintf($this->lang->line('option1'),$this->lang->line('option1'))]); ?> 
                  <?php echo form_error('option1', '<small class="help-block text-danger">&nbsp;', '</small>'); ?> 
                </div>
            </div>
            
            <div class="form-group"> 
                <?php echo form_label($this->lang->line('option2').$this->lang->line('mantatory_symbol'), 'Option B', ['class'=>'col-md-3 control-label']); ?>
                <div class="col-sm-7 col-md-4"> 
                  <?php echo form_input(['name'=>'option2', 'id'=>'option2','value'=>$option2, 'maxlength'=> '10','tabindex'=> '2','class'=>'form-control','placeholder'=>sprintf($this->lang->line('option2'),$this->lang->line('option2'))]); ?> 
                  <?php echo form_error('option2', '<small class="help-block text-danger">&nbsp;', '</small>'); ?> 
                </div>
            </div>

            <div class="form-group"> 
                <?php echo form_label($this->lang->line('option3').$this->lang->line('mantatory_symbol'), 'Option C', ['class'=>'col-md-3 control-label']); ?>
                <div class="col-sm-7 col-md-4"> 
                  <?php echo form_input(['name'=>'option3', 'id'=>'option3','value'=>$option3, 'maxlength'=> '50','tabindex'=> '1','class'=>'form-control','placeholder'=>sprintf($this->lang->line('option3'),$this->lang->line('option3'))]); ?> 
                  <?php echo form_error('option3', '<small class="help-block text-danger">&nbsp;', '</small>'); ?> 
                </div>
            </div>
            
            <div class="form-group"> 
                <?php echo form_label($this->lang->line('option4').$this->lang->line('mantatory_symbol'), 'Option D', ['class'=>'col-md-3 control-label']); ?>
                <div class="col-sm-7 col-md-4"> 
                  <?php echo form_input(['name'=>'option4', 'id'=>'option4','value'=>$option4, 'maxlength'=> '10','tabindex'=> '2','class'=>'form-control','placeholder'=>sprintf($this->lang->line('option4'),$this->lang->line('option4'))]); ?> 
                  <?php echo form_error('option4', '<small class="help-block text-danger">&nbsp;', '</small>'); ?> 
                </div>
            </div>

            <div class="form-group">
                <?php 
                    $get_all_course = get_all_course();
                ?>
                <?php echo form_label($this->lang->line('course_id').$this->lang->line('mantatory_symbol'), 'Course Id', ['class'=>'col-md-3 control-label']); ?>
                <div class="col-sm-7 col-md-4"> 
                  <?php echo form_dropdown('course_id',$get_all_course,$course_id,'class="form-control" id="course_id"'); ?> 
                  <?php echo form_error('course_id', '<small class="help-block text-danger">&nbsp;', '</small>'); 
                  ?> 
                </div>
            </div>

            <div class="form-group">
                <?php echo form_label($this->lang->line('topic_id').$this->lang->line('mantatory_symbol'), 'Topic Name', ['class'=>'col-md-3 control-label']); ?>
                <div class="col-sm-7 col-md-4"> 
                  <?php echo form_dropdown('topic_id','','','class="form-control" id="topic_id"'); ?> 
                  <?php echo form_error('topic_id', '<small class="help-block text-danger">&nbsp;', '</small>'); ?> 
                  <input type="hidden" id="temp_topic_id" value="<?php echo $topic_id; ?>">
                </div>
            </div>


            <div class="form-group">
              <div class="col-sm-offset-5 col-sm-10 col-md-offset-3 col-md-10">
                <button class="btn btn-info" type="submit" name="save" value="save" tabindex="13"><?php echo $this->lang->line('save'); ?></button>
                <button class="btn btn-primary" tabindex="14" onclick="window.history.back()"><?php echo $this->lang->line('back'); ?></button>
              </div>
            </div>
            <?php echo form_close();?>
            </div>
        </div>

<script type="text/javascript">
    $(document).ready(function(){

        loadTopic();
        
        
        //$(".topic_id_one").hide();
        $("#course_id").change(function(){
            //console.log($("#course_id").val());
           loadTopic();
          $('#topic_id').prop('selectedIndex',0);
        })



    });
     

    function loadTopic(){
      formData = {
                course_id : $("#course_id").val(),
               };
              $.ajax({
                      url : "<?php echo site_url('course/get_sub_course_quiz/'); ?>",
                      type: "POST",
                      data : formData,
                      success : function (data){
                        $('#topic_id').html('<option value="0" >Choose an item</option>');

                            if(data){
                              //alert(data);
                              var offices = jQuery.parseJSON(data);
                              if(offices){
                                var selectTxt='';
                                $.each(offices,function(key,value){
                                  //console.log(value.office_name);
                                  selectTxt+='<option value="'+value.id+'">'+value.topic_name+'</option>';
                                });

                                //$('#select2-sub_national_office-container').html('');
                                 $('#topic_id').html('<option value="0" >Choose an item</option>');
                                $('#topic_id').append(selectTxt);
                                //$('#select2-sub_national_office-container').append(selectTxt);
                              } else {
                                console.log("no data");
                                $('#topic_id').html('');
                                $('#topic_id').append('<option value="0" >Choose an item</option>');
                              }
                            }  else {
                               alert("Sorry try again later...");
                            }
                            var a = $("#temp_topic_id").val();
                            if(a != undefined || a > 0){
                              $('#topic_id').val(a);
                            }
                    }

              });
             
        
    }

</script>
<!-- END CONTENT FRAME BODY -->  