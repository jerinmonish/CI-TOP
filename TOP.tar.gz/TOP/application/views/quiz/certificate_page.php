<?php 
	/***
	File Name 		: view.php
	Description 	: This file is to view site configuration
	Author 			: Loganathan N, A.C Jerin Monish <jerinmonish007@gmail.com>
	**/
	$get_username 	= get_username($user_id);
	$get_coursename = get_coursename($course_id);
	$get_topicname 	= get_topicname($topic_id);
?>
<script src="<?php echo base_url()?>/assets/js/jQuery.print.js"></script>
    <?php echo $this->session->flashdata('success'); ?>
    <?php echo $this->session->flashdata('error'); ?>
<button class="btn btn-danger btn-rounded pull-right print_page">Print Certificate</button>
<div style="width:800px; height:600px; padding:20px; text-align:center; border: 10px solid #787878; background-image: url(<?php echo base_url()?>/assets/quiz/jerin.jpg)" id="mydivid">
<div style="width:750px; height:550px; padding:20px; text-align:center; border: 5px solid #787878">
       <span style="font-size:50px; font-weight:bold">Certificate of Merit</span>
       <br><br>
       <span style="font-size:25px"><i>This is to certify that</i></span>
       <br><br>
       <span style="font-size:30px"><b><?php echo $get_username[0]->first_name.' '.$get_username[0]->last_name; ?></b></span><br/><br/>
       <span style="font-size:25px"><i>has completed the topic</i></span> <br/><br/>
       <span style="font-size:30px"><?php echo $get_coursename[0]->course_name.' - '.$get_topicname[0]->topic_name; ?></span> <br/><br/>
       <span style="font-size:20px">with score of <b><?php echo $stu_mark." (Out of) ".$sub_mark; ?></b></span> <br/><br/><br/><br/>
       <span style="font-size:25px"><i>dated</i></span><br>
       <span style="font-size:30px"><?php echo date("d-M-Y");?></span>
</div>
</div>

<script type="text/javascript">// <![CDATA[
$(document).ready(function(){
	$(function(){
	    $(".print_page").click(function(){
		    $( "#mydivid" ).print();         
		    return( false );
	    });
	});
});
</script>