<?php 
	/***
	File Name 		: view.php
	Description 	: This file is to view site configuration
	Author 			: Loganathan N, A.C Jerin Monish <jerinmonish007@gmail.com>
	**/
	//echo '<pre>';print_r($quiz);exit;
?>
    <?php echo $this->session->flashdata('success'); ?>
    <?php echo $this->session->flashdata('error');?> 
<div class="panel panel-danger">
	<div class="panel-heading ui-draggable-handle">
		<h3 class="panel-title">Answer the questions each questions carry 1 mark each:-</h3>
	</div>
		<form action="<?php echo base_url(); ?>/course/get_quiz_answer" method="POST">
			<div class="panel-body">
	<?php 
		if($quiz){
			foreach ($quiz as $key => $value) {
	?>
		
			<div>
				<code><?php echo $value->question;?></code>
			</div>
			<div>
				<?php
				 echo "<input type='radio' name='question[".$value->id."]' value='".$value->option1."' required>".$value->option1."&nbsp;&nbsp;&nbsp;&nbsp;";
				 echo "<input type='radio' name='question[".$value->id."]' value='".$value->option2."' required>".$value->option2."&nbsp;&nbsp;&nbsp;&nbsp;";
				 echo "<input type='radio' name='question[".$value->id."]' value='".$value->option3."' required>".$value->option3."&nbsp;&nbsp;&nbsp;&nbsp;";
				 echo "<input type='radio' name='question[".$value->id."]' value='".$value->option4."' required>".$value->option4."&nbsp;&nbsp;&nbsp;&nbsp;";

				/*echo '<input type="radio" name="'.$answer[$value->id].'" value="'.$value->option1.'"><?php echo $value->option1; ?>';
				echo '<input type="radio" name="'.$answer[$value->id].'" value="'.$value->option2.'"><?php echo $value->option2; ?>';
				echo '<input type="radio" name="'.$answer[$value->id].'" value="'.$value->option3.'"><?php echo $value->option3; ?>';
				echo '<input type="radio" name="'.$answer[$value->id].'" value="'.$value->option4.'"><?php echo $value->option4; ?>';*/
				?>
				<input type="hidden" value="<?php echo $value->course_id; ?>" name="course_id">
				<input type="hidden" value="<?php echo $value->topic_id; ?>" name="topic_id">
			</div>
	<?php } ?>
		<input type="submit" class="btn btn-info" name="submit" value="submit">
	</form>
	</div>
	<?php 
		} else {
	?>
			<div class = "alert alert-danger alert-dismissable">
				<button type = "button" class = "close" data-dismiss = "alert" aria-hidden = "true">&times;</button>
				No any questions... !
			</div>
			<div class="panel-footer">                                
			<button class="btn btn-info" id="pc_remove" onclick="window.history.back()">Back</button>
			</div>
	<?php } ?>
</div>