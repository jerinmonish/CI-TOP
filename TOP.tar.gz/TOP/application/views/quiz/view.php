<?php 
	/***
	File Name 		: view.php
	Description 	: This file is to view site configuration
	Author 			: Loganathan N, A.C Jerin Monish <jerinmonish007@gmail.com>
	**/
?>
<div class="col-md-6 table-responsive">
	<table class="table table-striped">
		<tr>
			<td><span class="text-semibold"><?php echo $this->lang->line('course_name'); ?></span></td>
			<td>
				<?php 
					$course = get_coursename($course_id); 
					echo $course[0]->course_name;
				?>
			</td>
		</tr>
		<tr>
			<td><span class="text-semibold"><?php echo $this->lang->line('topic_name'); ?></span></td>
			<td>
				<?php 
					$course = get_topicname($topic_id); 
					echo $course[0]->topic_name;
				?>
			</td>
		</tr>
		<tr>
			<td><span class="text-semibold"><?php echo $this->lang->line('question'); ?></span></td>
			<td><?php echo $question; ?></td>
		</tr>
		<tr>
			<td><span class="text-semibold"><?php echo $this->lang->line('answer'); ?></span></td>
			<td><?php echo $answer; ?></td>
		</tr>
		<tr>
			<td><span class="text-semibold"><?php echo $this->lang->line('option1'); ?></span></td>
			<td><?php echo $option1; ?></td>
		</tr>
		<tr>
			<td><span class="text-semibold"><?php echo $this->lang->line('option2'); ?></span></td>
			<td><?php echo $option2; ?></td>
		</tr>
		<tr>
			<td><span class="text-semibold"><?php echo $this->lang->line('option3'); ?></span></td>
			<td><?php echo $option3; ?></td>
		</tr>
		<tr>
			<td><span class="text-semibold"><?php echo $this->lang->line('option4'); ?></span></td>
			<td><?php echo $option4; ?></td>
		</tr>
		<tr>
			<td><span class="text-semibold"><?php echo $this->lang->line('created_on'); ?></span></td>
			<td><?php echo $created_on; ?></td>
		</tr>
	</table>
	<div>
	<a class="btn btn-info" title="Update" href="<?php echo base_url().$this->lang->line('url_quiz_edit').$id; ?>">Update</a>
		<a class="btn btn-default" title="Back" href="<?php echo base_url(); ?>quiz/">Back</a>
	</div>
</div>