<?php 
	/***
	File Name 		: view.php
	Description 	: This file is to view site configuration
	Author 			: Loganathan N, A.C Jerin Monish <jerinmonish007@gmail.com>
	**/
?>
<div class="col-md-6 table-responsive">
	<table class="table table-striped">
		<tr>
			<td><span class="text-semibold"><?php echo $this->lang->line('content'); ?></span></td>
			<td><?php echo $content; ?></td>
		</tr>
		<tr>
			<td><span class="text-semibold"><?php echo $this->lang->line('i_color'); ?></span></td>
			<td><?php echo $i_color; ?></td>
		</tr>
		<tr>
			<td><span class="text-semibold"><?php echo $this->lang->line('i_class'); ?></span></td>
			<td><?php echo $i_class; ?></td>
		</tr>
		<tr>
			<td><span class="text-semibold"><?php echo $this->lang->line('created_on'); ?></span></td>
			<td><?php echo $created_on; ?></td>
		</tr>
	</table>
	<div>
	<a class="btn btn-info" title="Update" href="<?php echo base_url().$this->lang->line('url_quote_edit').$id; ?>">Update</a>
		<a class="btn btn-default" title="Back" href="<?php echo base_url(); ?>quiz/quote">Back</a>
	</div>
</div>