
    <?php echo $this->session->flashdata('success'); ?>
    <?php echo $this->session->flashdata('error'); ?>             
    <div class="panel panel-default push-up-12">
        <div class="panel-body panel-body-search">
            <div class="input-group col-md-12">
            <?php echo form_open_multipart('quiz/edit_quotes/'.$id,'class="form-horizontal form-padding" id="form_course_add"');?>

              <div class="form-group"> 
                <?php echo form_label($this->lang->line('content').$this->lang->line('mantatory_symbol'), 'Content', ['class'=>'col-md-3 control-label']); ?>
                <div class="col-sm-7 col-md-4"> 
                  <?php echo form_input(['name'=>'content', 'value'=> $content,'id'=>'content', 'maxlength'=> '150','tabindex'=> '1','class'=>'form-control','placeholder'=>sprintf($this->lang->line('content'),$this->lang->line('content'))]); ?> 
                  <?php echo form_error('content', '<small class="help-block text-danger">&nbsp;', '</small>'); ?> 
                </div>
            </div>


            <div class="form-group">
            <?php 
                $options = array(''=>'Choose an item','fa fa-bell' => 'Bell', 'fa fa-heart' => 'Heart', 'fa fa-desktop' => 'Desktop', 'fa fa-leaf' => 'Leaf', 'fa fa-comments' => 'Comments');
            ?>
                <?php echo form_label($this->lang->line('i_class').$this->lang->line('mantatory_symbol'), 'Class', ['class'=>'col-md-3 control-label']); ?>
                <div class="col-sm-7 col-md-4"> 
                  <?php echo form_dropdown('i_class',$options,$i_class); ?> 
                  <?php echo form_error('i_class', '<small class="help-block text-danger">&nbsp;', '</small>'); 
                  ?> 
                </div>
            </div>

            <div class="form-group">
            <?php 
                $options = array(''=>'Choose an item','orange' => 'Orange', 'green' => 'Green', 'red' => 'Red', 'blue' => 'Blue', 'dark' => 'Dark');
            ?>
                <?php echo form_label($this->lang->line('i_color').$this->lang->line('mantatory_symbol'), 'Color', ['class'=>'col-md-3 control-label']); ?>
                <div class="col-sm-7 col-md-4"> 
                  <?php echo form_dropdown('i_color',$options,$i_color); ?> 
                  <?php echo form_error('i_color', '<small class="help-block text-danger">&nbsp;', '</small>'); 
                  ?> 
                </div>
            </div>
            <div class="form-group">
              <div class="col-sm-offset-5 col-sm-10 col-md-offset-3 col-md-10">
                <button class="btn btn-info" type="submit" name="save" value="save" tabindex="13"><?php echo $this->lang->line('save'); ?></button>
                <button class="btn btn-primary" tabindex="14" onclick="window.history.back()"><?php echo $this->lang->line('back'); ?></button>
              </div>
            </div>
            <?php echo form_close();?>
            </div>
        </div>

<!-- END CONTENT FRAME BODY -->  