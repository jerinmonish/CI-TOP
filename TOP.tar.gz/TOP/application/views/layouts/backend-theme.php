<!DOCTYPE html>
<html lang="en">
    <head>        
        <!-- META SECTION -->
        <title><?php echo $template['title'].' - '.$this->config->item('site_name'); ?></title>            
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        
        <link rel="icon" href="favicon.ico" type="image/x-icon" />
        <!-- END META SECTION -->
        
        <!-- CSS INCLUDE -->        
        <link rel="stylesheet" type="text/css" id="theme" href="<?php echo base_url();?>assets/css/theme-default.css"/>
        <!-- EOF CSS INCLUDE -->   
        <!-- START PRELOADS -->
        <!--audio id="audio-alert" src="audio/alert.mp3" preload="auto"></audio>
        <audio id="audio-fail" src="audio/fail.mp3" preload="auto"></audio-->
        <!-- END PRELOADS -->                 
        
    <!-- START SCRIPTS -->
        <!-- START PLUGINS -->
        <script type="text/javascript" src="<?php echo base_url();?>assets/js/jquery.min.js"></script>
        <script type="text/javascript" src="<?php echo base_url();?>assets/js/jquery-ui.min.js"></script>
        <script type="text/javascript" src="<?php echo base_url();?>assets/js/bootstrap.min.js"></script>
        <!--script type="text/javascript" src="<?php //echo base_url();?>assets/js/jAlert.js"></script>
        <script type="text/javascript" src="<?php //echo base_url();?>assets/js/jAlert-functions.js"></script-->
        <!-- added on 08-09-2016--> 
        <script type='text/javascript' src="<?php echo base_url();?>assets/js/plugins/icheck/icheck.min.js"></script>
        <script type="text/javascript" src="<?php echo base_url();?>assets/js/plugins/rickshaw/d3.v3.js"></script>
        <script type="text/javascript" src="<?php echo base_url();?>assets/js/plugins/rickshaw/rickshaw.min.js"></script>
        <script type="text/javascript" src="<?php echo base_url();?>assets/js/plugins/owl/owl.carousel.min.js"></script>                 
        <script type="text/javascript" src="<?php echo base_url();?>assets/js/plugins/moment.min.js"></script>     
        <script type="text/javascript" src="<?php echo base_url();?>assets/js/plugins/bootsrap/bootstrap-datepicker.js"></script>  

        <link href="<?php echo base_url()?>assets/flexigrid/css/jquery-ui.min.css" rel="stylesheet" type="text/css"/>

        <link href="<?php echo base_url()?>assets/flexigrid/css/flexigrid.css" rel="stylesheet" type="text/css" />

        <script type="text/javascript" src="<?php echo base_url()?>assets/flexigrid/js/jquery-migrate-1.2.1.min.js"></script>

        <script type="text/javascript" src="<?php echo base_url()?>assets/flexigrid/js/jquery-ui.min.js"></script>

        <script type="text/javascript" src="<?php echo base_url()?>assets/flexigrid/js/flexigrid.js"></script>

        <!-- 08-09-2016 ended ?>
        <!-- END PLUGINS -->

        <!-- THIS PAGE PLUGINS -->
        <script type="text/javascript" src="<?php echo base_url();?>assets/js/jquery.mCustomScrollbar.min.js"></script>
        <!-- END PAGE PLUGINS --> 

        <!-- THIS PAGE PLUGINS FOR TINY MCE -->
        <script type="text/javascript" src="<?php echo base_url();?>assets/tinymce_4.4.3/js/tinymce/tinymce.min.js"></script>
        <!-- END PAGE PLUGINS FOR TINY MCE --> 

        <!-- START TEMPLATE -->
        <script type="text/javascript" src="<?php echo base_url();?>assets/js/plugins.js"></script>        
        <script type="text/javascript" src="<?php echo base_url();?>assets/js/actions.js"></script>        
        <!-- END TEMPLATE -->
    <!-- END SCRIPTS -->
    <!-- News Slider -->
    <link rel="stylesheet" href="<?php echo base_url();?>assets/css/news.css">
    <script src="<?php echo base_url();?>assets/js/news.js"></script>
    <!-- News Slider ends -->   
    <!--Circle effect starts-->
        <link rel="stylesheet" type="text/css" href="<?php echo base_url();?>assets/c-effect/css/demo.css" />
        <link rel="stylesheet" type="text/css" href="<?php echo base_url();?>assets/c-effect/css/common.css" />
        <link rel="stylesheet" type="text/css" href="<?php echo base_url();?>assets/c-effect/css/style5.css" />
        <!--link href='http://fonts.googleapis.com/css?family=Open+Sans:300,700' rel='stylesheet' type='text/css' /-->
        <script type="text/javascript" src="<?php echo base_url();?>assets/c-effect/js/modernizr.custom.79639.js"></script> 
        <!--link rel="stylesheet" type="text/css" href="<?php //echo base_url();?>assets/css/jAlert.css" /-->
    <!--Circle effect ends-->                                
    </head>
    <body>
    <body>
        <!-- START PAGE CONTAINER -->
        <div class="page-container">
            
            <!-- START PAGE SIDEBAR -->
            <div class="page-sidebar">
                <!-- START X-NAVIGATION -->
                <ul class="x-navigation">
                    <li class="xn-logo">
                        <a href="index.html"><?php echo $this->config->item('site_name'); ?></a>
                        <a href="#" class="x-navigation-control"></a>
                    </li>
                    <li class="xn-profile">
                        <a href="#" class="profile-mini">
                            <img src="<?php echo base_url();?>assets/profile_image/<?php echo $this->session->userdata('image'); ?>" alt="profile-image"/>
                        </a>
                        <div class="profile">
                            <div class="profile-image">
                                <img src="<?php echo base_url();?>assets/profile_image/<?php echo $this->session->userdata('image'); ?>" alt="John Doe"/>
                            </div>
                            <div class="profile-data">
                                <div class="profile-data-name"><?php echo $this->session->userdata('first_name');?></div>
                                <div class="profile-data-title"><?php echo $this->session->userdata('email'); ?></div>
                            </div>
                            <div class="profile-controls">
                                <a href="<?php echo base_url();?>login/view_user/<?php echo $this->session->userdata('id'); ?>" class="profile-control-left" title="View Profile"><span class="fa fa-info"></span></a>
                                <!--a href="pages-messages.html" class="profile-control-right"><span class="fa fa-envelope"></span></a-->
                            </div>
                        </div>                                                                        
                    </li>
                    <li class="xn-title">Navigation</li>
                    <li <?php echo ($this->uri->segment(2) == 'dashboard') ? 'class="active"' : ''; ?>>
                        <a href="<?php echo base_url();?>login/dashboard" title="Dashboard">
                            <span class="fa fa-desktop"></span> <span class="xn-text">Dashboard</span>
                        </a>                        
                    </li>                    
                    
                    <li class="xn-openable">
                        <a href="#" title="Course"><span class="fa fa-folder-open"></span> <span class="xn-text">Course</span></a>
                        <ul>
                            <?php if($this->session->userdata('user_type') == ADMINISTRATOR){?>
                                <li><a href="<?php echo base_url();?>course/" title="Course Details"><span class="fa fa-book"></span>Course</a></li>
                                <li><a href="<?php echo base_url();?>course/sub_course" title="Sub Topic Details"><span class="fa fa-file-text-o"></span>Sub Topic</a></li>
                            <?php } else {?>
                                <li <?php echo ($this->uri->segment(2) == 'view_course_frontend') ? 'class="active"' : ''; ?>>
                                    <a href="<?php echo base_url();?>course/view_course_frontend" title="Course Details" >Course</a>
                                </li>
                            <?php } ?>
                        </ul>
                    </li>
                    <?php if($this->session->userdata('user_type') == ADMINISTRATOR){?>
                        <li>
                            <a href="<?php echo base_url();?>quiz/quote/" title="Quotes"><span class="fa fa-smile-o"></span><span class="xn-text">Quotes</span></a>                        
                        </li>
                        <li>
                            <a href="<?php echo base_url();?>quiz/" title="Quiz"><span class="fa fa-comments-o"></span> <span class="xn-text">Quiz</span></a>                        
                        </li>
                        <li>
                            <a href="<?php echo base_url();?>login/user/" title="List User"><span class="fa fa-adn"></span><span class="xn-text">Users</span></a>                        
                        </li>
                    <?php }?>

                    <li class="xn-openable">
                        <a href="#" title="Profile"><span class="fa fa-cogs"></span></span> <span class="xn-text">Profile</span></a>
                        <ul>
                                <li>
                                    <a href="<?php echo base_url();?>login/update_profile/<?php echo $this->session->userdata('id')?>" title="Course Details">
                                        <span class="fa fa-user"></span></span>Update profile
                                    </a>
                                </li>
                                <li><a href="<?php echo base_url();?>login/change_password" title="Change Password"><span class="fa fa-key"></span>Change password</a></li>
                        </ul>
                    </li>
                    
                    
                    
                </ul>
                <!-- END X-NAVIGATION -->
            </div>
            <!-- END PAGE SIDEBAR -->
            
            <!-- PAGE CONTENT -->
            <div class="page-content">
                
                <!-- START X-NAVIGATION VERTICAL -->
                <ul class="x-navigation x-navigation-horizontal x-navigation-panel">
                    <!-- TOGGLE NAVIGATION -->
                    <li class="xn-icon-button">
                        <a href="#" class="x-navigation-minimize"><span class="fa fa-dedent"></span></a>
                    </li>
                    <!-- END TOGGLE NAVIGATION -->
                    <!-- SEARCH -->
                    <!--li class="xn-search">
                        <form role="form" action="<?php //echo base_url();?>course/search_course">
                            <input type="text" name="search" placeholder="Search..."/>
                        </form>
                    </li-->   
                    <!-- END SEARCH -->
                    <!-- SIGN OUT -->
                    <li class="xn-icon-button pull-right">
                        <a href="#" class="mb-control" data-box="#mb-signout"><span class="fa fa-sign-out"></span></a>                        
                    </li> 
                    <!-- END SIGN OUT -->
                    <!-- MESSAGES -->
                    <!--li class="xn-icon-button pull-right">
                        <a href="#"><span class="fa fa-comments"></span></a>
                        <div class="informer informer-danger">4</div>
                        <div class="panel panel-primary animated zoomIn xn-drop-left xn-panel-dragging">
                            <div class="panel-heading">
                                <h3 class="panel-title"><span class="fa fa-comments"></span> Messages</h3>                                
                                <div class="pull-right">
                                    <span class="label label-danger">4 new</span>
                                </div>
                            </div>
                            <div class="panel-body list-group list-group-contacts scroll" style="height: 200px;">
                                <a href="#" class="list-group-item">
                                    <div class="list-group-status status-online"></div>
                                    <img src="assets/images/users/user2.jpg" class="pull-left" alt="John Doe"/>
                                    <span class="contacts-title">John Doe</span>
                                    <p>Praesent placerat tellus id augue condimentum</p>
                                </a>
                                <a href="#" class="list-group-item">
                                    <div class="list-group-status status-away"></div>
                                    <img src="assets/images/users/user.jpg" class="pull-left" alt="Dmitry Ivaniuk"/>
                                    <span class="contacts-title">Dmitry Ivaniuk</span>
                                    <p>Donec risus sapien, sagittis et magna quis</p>
                                </a>
                                <a href="#" class="list-group-item">
                                    <div class="list-group-status status-away"></div>
                                    <img src="assets/images/users/user3.jpg" class="pull-left" alt="Nadia Ali"/>
                                    <span class="contacts-title">Nadia Ali</span>
                                    <p>Mauris vel eros ut nunc rhoncus cursus sed</p>
                                </a>
                                <a href="#" class="list-group-item">
                                    <div class="list-group-status status-offline"></div>
                                    <img src="assets/images/users/user6.jpg" class="pull-left" alt="Darth Vader"/>
                                    <span class="contacts-title">Darth Vader</span>
                                    <p>I want my money back!</p>
                                </a>
                            </div>     
                            <div class="panel-footer text-center">
                                <a href="pages-messages.html">Show all messages</a>
                            </div>                            
                        </div>                        
                    </li--->
                    <!-- END MESSAGES -->
                    <!-- TASKS -->
                    <!---li class="xn-icon-button pull-right">
                        <a href="#"><span class="fa fa-tasks"></span></a>
                        <div class="informer informer-warning">3</div>
                        <div class="panel panel-primary animated zoomIn xn-drop-left xn-panel-dragging">
                            <div class="panel-heading">
                                <h3 class="panel-title"><span class="fa fa-tasks"></span> Tasks</h3>                                
                                <div class="pull-right">
                                    <span class="label label-warning">3 active</span>
                                </div>
                            </div>
                            <div class="panel-body list-group scroll" style="height: 200px;">                                
                                <a class="list-group-item" href="#">
                                    <strong>Phasellus augue arcu, elementum</strong>
                                    <div class="progress progress-small progress-striped active">
                                        <div class="progress-bar progress-bar-danger" role="progressbar" aria-valuenow="50" aria-valuemin="0" aria-valuemax="100" style="width: 50%;">50%</div>
                                    </div>
                                    <small class="text-muted">John Doe, 25 Sep 2014 / 50%</small>
                                </a>
                                <a class="list-group-item" href="#">
                                    <strong>Aenean ac cursus</strong>
                                    <div class="progress progress-small progress-striped active">
                                        <div class="progress-bar progress-bar-warning" role="progressbar" aria-valuenow="80" aria-valuemin="0" aria-valuemax="100" style="width: 80%;">80%</div>
                                    </div>
                                    <small class="text-muted">Dmitry Ivaniuk, 24 Sep 2014 / 80%</small>
                                </a>
                                <a class="list-group-item" href="#">
                                    <strong>Lorem ipsum dolor</strong>
                                    <div class="progress progress-small progress-striped active">
                                        <div class="progress-bar progress-bar-success" role="progressbar" aria-valuenow="95" aria-valuemin="0" aria-valuemax="100" style="width: 95%;">95%</div>
                                    </div>
                                    <small class="text-muted">John Doe, 23 Sep 2014 / 95%</small>
                                </a>
                                <a class="list-group-item" href="#">
                                    <strong>Cras suscipit ac quam at tincidunt.</strong>
                                    <div class="progress progress-small">
                                        <div class="progress-bar" role="progressbar" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100" style="width: 100%;">100%</div>
                                    </div>
                                    <small class="text-muted">John Doe, 21 Sep 2014 /</small><small class="text-success"> Done</small>
                                </a>                                
                            </div>     
                            <div class="panel-footer text-center">
                                <a href="pages-tasks.html">Show all tasks</a>
                            </div>                            
                        </div>                        
                    </li--->
                    <!-- END TASKS -->
                </ul>
                <!-- END X-NAVIGATION VERTICAL -->                     

                <!-- START BREADCRUMB -->
                <ul class="breadcrumb">
                    <li><a href="#">Home</a></li>                    
                    <li class="active">Dashboard</li>
                </ul>
                <!-- END BREADCRUMB -->                       
                
                <div class="page-title">                    
                    <h2><a href="#" onclick="window.history.back()"><span class="fa fa-arrow-circle-o-left"></span></a> <?php echo $template['title'].' - '.$this->config->item('site_name'); ?></h2>
                </div>                   
                
                <!-- PAGE CONTENT WRAPPER -->
                <div class="page-content-wrap">
                
                    <div class="row">
                        <div class="col-md-12">

                            <div class="panel panel-default">
                                <div class="panel-heading">
                                    <!--h3 class="panel-title">test</h3-->
                                </div>
                                <div class="panel-body">
                                    <?php echo $template['body']; ?>
                                </div>
                            </div>

                        </div>
                    </div>
                
                </div>
                <!-- END PAGE CONTENT WRAPPER -->                                
            </div>            
            <!-- END PAGE CONTENT -->
        </div>
        <!-- END PAGE CONTAINER -->

        <!-- MESSAGE BOX-->
        <div class="message-box animated fadeIn" data-sound="alert" id="mb-signout">
            <div class="mb-container">
                <div class="mb-middle">
                    <div class="mb-title"><span class="fa fa-sign-out"></span> Log <strong>Out</strong> ?</div>
                    <div class="mb-content">
                        <p>Are you sure you want to log out?</p>                    
                        <p>Press No if youwant to continue work. Press Yes to logout current user.</p>
                    </div>
                    <div class="mb-footer">
                        <div class="pull-right">
                            <a href="<?php echo base_url();?>login/logout" class="btn btn-success btn-lg">Yes</a>
                            <button class="btn btn-default btn-lg mb-control-close">No</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- END MESSAGE BOX-->
    </body>
</html>






