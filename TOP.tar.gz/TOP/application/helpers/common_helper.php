<?php defined('BASEPATH') OR exit('No direct script access allowed');

	//To get current date and time to store in db
	function mysql_date_time($date=FALSE){
	    return ($date) ? date('Y-m-d H:i:s', strtotime($date)) : date('Y-m-d H:i:s');
	}

	/**function for displaying datetime in US format**/
	function custom_date($date){
		if ($date) {
			return date('d-m-Y h:i:s A', strtotime($date));
		}else{
			return '';
		}
	}

	/**function for displaying datetime in US format**/
	function mysql_custom_date($date){
		if ($date) {
			return date('Y-m-d', strtotime($date));
		}else{
			return '';
		}
	}

	//To wish the user
	function wish_user(){
			$hour = date('H', time());
			if( $hour > 6 && $hour <= 11) {
			  $mor  = "Good Morning";
			  return $mor;
			}
			else if($hour > 11 && $hour <= 12) {
			  $after = "Good Afternoon";
			  return $after;
			}
			else if($hour > 16 && $hour <= 23) {
			  $eve = "Good Evening";
			  return $eve;
			}	
			else {
			  $default = "Hi, Welcome";
			  return $default;
			}
		}

		//To get unread message counts
	function get_all_course(){
	    $CI = & get_instance();
	    $CI->load->model('course_model');
	    $data = $CI->course_model->get_all_course();
	    $get_con = ($data) ? $data: '';
	    $cont_data['']	=	'Select Course';
	    	if($get_con){
	    		foreach ($get_con as $key => $value) {
	    			$cont_data[$value->id] = $value->course_name;
	    		}
	    	}
	    	$cont_data = $cont_data;
	    	return $cont_data;

	}
	
	function get_user_already_quiz($topic_id){
		$CI = & get_instance();
	    $CI->load->model('course_model');
	    $data = $CI->course_model->get_quiz_attended_not($topic_id);
	    $get_con = ($data) ? $data: '';
	    return $get_con;
	}

	function get_username($user_id){
		$CI = & get_instance();
	    $CI->load->model('course_model');
	    $data = $CI->course_model->get_username($user_id);
	    $get_con = ($data) ? $data: '';
	    return $get_con;
	}

	function get_coursename($course_id){
		$CI = & get_instance();
	    $CI->load->model('course_model');
	    $data = $CI->course_model->get_course_name($course_id);
	    $get_con = ($data) ? $data: '';
	    return $get_con;
	}

	function get_topicname($topic_id){
		$CI = & get_instance();
	    $CI->load->model('course_model');
	    $data = $CI->course_model->get_topic_name($topic_id);
	    $get_con = ($data) ? $data: '';
	    return $get_con;
	}

	/**
	 * Handles to delete the file
	 * @param type string file_name
	 * @param type string path
	 * @return boolean true file deleted success
	 */
	function delete_file($path, $file_name) {
	    // Specifies the file name path
	    $path = $path . $file_name;
	    // File exists
	    if ($file_name) {
	        if (file_exists($path)) {
	            if (@unlink($path)) {
	                return true;
	            } else {
	                return false;
	            }
	        } else {
	            return false;
	        }
	    } else {
	        return false;
	    }
	}

	// To get state name using state id and country id
	function get_state_by_id($id,$s_id){
		$CI = & get_instance();
	    $CI->load->model('login_model');
	    $data = $CI->login_model->get_state_name($id,$s_id);
	    $get_res = ($data) ? $data: 'No';
	    return $get_res;
	}
	// To get city name using state id and city id
	function get_city_by_id($id,$c_id){
		$CI = & get_instance();
	    $CI->load->model('login_model');
	    $data = $CI->login_model->get_city_name($id,$c_id);
	    $get_res = ($data) ? $data: 'No';
	    return $get_res;
	}
	// To get country name using country id
	function get_country_by_id($id){
		$CI = & get_instance();
	    $CI->load->model('login_model');
	    $data = $CI->login_model->get_country_name($id);
	    $get_res = ($data) ? $data: 'No';
	    return $get_res;
	}

	// To get all country
	function get_countries(){
		$CI = & get_instance();
	    $CI->load->model('login_model');
	    $data = $CI->login_model->get_all_country();
	    $get_con = ($data) ? $data: '';
	    $cont_data['null']	=	'Select Country';
	    	if($get_con){
	    		foreach ($get_con as $key => $value) {
	    			$cont_data[$value->id] = $value->name;
	    		}
	    	}
	    	$cont_data = $cont_data;
	    	return $cont_data;
	}

	// To get all state
	function get_states(){
		$CI = & get_instance();
	    $CI->load->model('login_model');
	    $data = $CI->login_model->get_all_state();
	    $get_con = ($data) ? $login_model: '';
	    $cont_data['null']	=	'Select State';
	    	if($get_con){
	    		foreach ($get_con as $key => $value) {
	    			$cont_data[$value->id] = $value->name;
	    		}
	    	}
	    	$cont_data = $cont_data;
	    	return $cont_data;
	}

	// To get all state
	function get_cities(){		
		$CI = & get_instance();
	    $CI->load->model('login_model');
	    $data = $CI->login_model->get_all_city();
	    $get_con = ($data) ? $data: '';
	    $cont_data['null']	=	'Select City';
	    	if($get_con){
	    		foreach ($get_con as $key => $value) {
	    			$cont_data[$value->id] = $value->name;
	    		}
	    	}
	    	$cont_data = $cont_data;
	    	return $cont_data;
	}

	// To get state while update
	function get_state_on_update($country,$state){
		$CI = & get_instance();
	    $CI->load->model('login_model');
	    $data = $CI->login_model->get_user_state_on_update($country,$state);
	    $get_res = ($data) ? $data: 'No';
	    return $get_res;
	}

	// To get city while update
	function get_city_on_update($state,$city){
		$CI = & get_instance();
	    $CI->load->model('login_model');
	    $data = $CI->login_model->get_user_city_on_update($state,$city);
	    $get_res = ($data) ? $data: 'No';
	    return $get_res;
	}

	// To get city while update
	function get_all_quotes(){
		$CI = & get_instance();
	    $CI->load->model('quiz_model');
	    $data = $CI->quiz_model->get_all_quote();
	    $get_res = ($data) ? $data: 'No';
	    return $get_res;
	}
	
// end of file
?>