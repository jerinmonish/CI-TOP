<?php
/***
    File Name       : User_model.php
    Description     : This Model is to Provide the DB Details of User Manager and its operation
    Author          : A.C Jerin Monish <jerinmonish007@gmail.com>
    **/
defined('BASEPATH') OR exit('No direct script access allowed');
class Course_model  extends CI_Model  {

    public $CI;
    public $course          = 'course';
    public $sub_course      = 'sub_course';
    public $quiz            = 'quiz';
    public $set_completion  = 'completion_details';
    public $registration    = 'registration';
    public $quote           = 'quotes';

    /**
     * Constructor
     * To load library,language,model,ETC files
     * */
	function __construct()
    {
        parent::__construct();
        $this->CI =& get_instance();
    }

    /**
     * This method is used to add course
     * @access public
     * @param fieldname $data (array data)
     * @return type array data
     */
    public function insert_course($data)
    {
        $query = $this->db->insert($this->course,$data);
        if($query){
            return true;
        } else {
            return false;
        }
    }

    /**
    * This method handles to get all port
    **/
    public function get_all(){
        $this->db->select('*');
        $this->db->from($this->course);
        $this->db->order_by("id","DESC");
        $this->CI->flexigrid->build_query();
        $return['records'] = $this->db->get();
         
        $this->db->select('count(id) as record_count')->from($this->course);
        $this->CI->flexigrid->build_query(FALSE);
        $record_count = $this->db->get();       
        $row = $record_count->row();
        $return['record_count'] = $row->record_count;  

        return $return;       
    }

    /**
    * This method handles to get all port
    **/
    public function get_all_topic(){
        $this->db->select('*');
        $this->db->from($this->sub_course);
        $this->db->order_by("id","DESC");
        $this->CI->flexigrid->build_query();
        $return['records'] = $this->db->get();
         
        $this->db->select('count(id) as record_count')->from($this->sub_course);
        $this->CI->flexigrid->build_query(FALSE);
        $record_count = $this->db->get();       
        $row = $record_count->row();
        $return['record_count'] = $row->record_count;  

        return $return;       
    }

    

    /**
    * This method handles to retrieve a Port detail by collection Id
    **/
    public function get_course_by_id($id){
        $return     = [];

        $result     = $this->db->get_where($this->course, array('id' =>(int) $id));
        if(!empty($result)){
            $return = $result->result();
        }

        return $return;
    }

    /**
    * This method handles to update port manager data by id
    **/
    function update_course_by_id($course_id, $data){
      //print_r($data);exit;
        $query = $this->db->where('id', $course_id)
                          ->update($this->course, $data);
        if($query){
            return true;
        } else {
            return false;
        }
    }

    /**
    * This method handles to delete port manager data by id
    **/
    function delete_course_id($id){
        $this->db->where('id', $id);
        $result =$this->db->delete($this->course);
        if($result){
            return true;
        }else{
            return false;
        }
    }

    public function get_all_course(){
        $query = $this->db->select('*')
                          ->from($this->course)
                          ->where('status',ACTIVE)
                          ->order_by('id','DESC');
        $res = $query->get();
        if($res){
            $result = $res->result();
            //$result = $res->num_rows();
            //echo '<pre>';print_r($result);exit;
            return $result;
        } else {
            return false;
        }
    }

    /**
     * This method is used to add course
     * @access public
     * @param fieldname $data (array data)
     * @return type array data
     */
    public function insert_sub_course($data)
    {
        $query = $this->db->insert($this->sub_course,$data);
        if($query){
            return true;
        } else {
            return false;
        }
    }

    /**
    * This method handles to delete port manager data by id
    **/
    function delete_sub_course_id($id){
        $this->db->where('id', $id);
        $result =$this->db->delete($this->sub_course);
        if($result){
            return true;
        }else{
            return false;
        }
    }


    /**
     * This method is used to add course
     * @access public
     * @param fieldname $data (array data)
     * @return type array data
     */
    public function get_sub_course_id($id)
    {
        $query = $this->db->select('*')
                          ->from($this->sub_course)
                          ->where('course_id',$id);
                          //->limit(1);
        $res = $query->get();
        if($res){
            $result = $res->result();
            //$result = $res->num_rows();
            //echo '<pre>';print_r($result);exit;
            return $result;
        } else {
            return false;
        }
    }

    /**
    * This method handles to update port manager data by id
    **/
    function update_sub_course_by_id($topic_id, $data){
      //print_r($data);exit;
        $query = $this->db->where('id', $topic_id)
                          ->update($this->sub_course, $data);
        if($query){
            return true;
        } else {
            return false;
        }
    }

    /**
     * This method is used to add course
     * @access public
     * @param fieldname $data (array data)
     * @return type array data
     */
    public function get_topic_course_id($id)
    {
        $query = $this->db->select('*')
                          ->from($this->sub_course)
                          ->where('id',$id);
                          //->limit(1);
        $res = $query->get();
        if($res){
            $result = $res->result();
            //$result = $res->num_rows();
            //echo '<pre>';print_r($result);exit;
            return $result;
        } else {
            return false;
        }
    }

    /**
     * This method is used to add course
     * @access public
     * @param fieldname $data (array data)
     * @return type array data
     */
    public function get_quiz_topic_course($topic_id,$course_id)
    {
        $query = $this->db->select('*')
                          ->from($this->quiz)
                          ->where('course_id',$course_id)
                          ->where('topic_id',$topic_id);
                          //->limit(1);
        $res = $query->get();
        if($res){
            $result = $res->result();
            //$result = $res->num_rows();
            //echo '<pre>';print_r($result);exit;
            return $result;
        } else {
            return false;
        }
    }

    public function check_answers($quiz,$key,$course_id,$topic_id){
      $query = $this->db->select('*')
                          ->from($this->quiz)
                          ->where('course_id',$course_id)
                          ->where('topic_id',$topic_id)
                          ->where('answer',$quiz)
                          ->where('id',$key);
      $res = $query->get()->num_rows();
        if($res){
            //$result = $res->result();
            //$result = $res->num_rows();
            //echo '<pre>';print_r($result);exit;
          //print_r($res);exit;
            return $res;
        } else {
            return false;
        }
    }

    public function set_course_topic_details($data){
      $course_id = $data['course_id'];
      $topic_id = $data['topic_id'];
      $get_first_present_not = $this->db->select('*')
                                        ->from($this->set_completion)
                                        ->where('course_id',$course_id)
                                        ->where('topic_id',$topic_id)
                                        ->where('stu_status','Fail');
      $res = $get_first_present_not->get();
        if($res){
          $result = $res->result();
            if($result){
              $status = $this->db->where('id', $result[0]->id)
                                 ->update($this->set_completion, $data);
                if($status){
                  return true;
                } else {
                  return false;
                }
            } else {
              $query = $this->db->insert($this->set_completion,$data);
              if($query){
                return true;
              } else {
                return false;
              }
            }
        } else {
            die("Try after some time...exiting !");
        }
    }

    public function get_quiz_attended_not($topic_id){
      $user_id = $this->session->userdata('id');
      $query = $this->db->select('*')
                        ->from($this->set_completion)
                        ->where('topic_id',$topic_id)
                        ->where('user_id',$user_id);
      $res = $query->get();
      if($res){
        $result = $res->result();
        return $result;
      } else {
        return false;
      }
    }

    public function get_certificate_details($topic_id,$course_id){
      $user_id = $this->session->userdata('id');
      $query = $this->db->select('*')
                        ->from($this->set_completion)
                        ->where('topic_id',$topic_id)
                        ->where('course_id',$course_id)
                        ->where('user_id',$user_id);
      $res = $query->get();
      if($res){
        $result = $res->result();
        return $result;
      } else {
        return false;
      }
    }

    public function get_username($user_id){
      $query = $this->db->select('*')
                        ->from($this->registration)
                        ->where('id',$user_id);
      $res = $query->get();
      if($res){
        $result = $res->result();
        return $result;
      } else {
        return false;
      }
    }

    public function get_course_name($course_id){
      $query = $this->db->select('*')
                        ->from($this->course)
                        ->where('id',$course_id);
      $res = $query->get();
      if($res){
        $result = $res->result();
        return $result;
      } else {
        return false;
      }
    } 

    public function get_topic_name($topic_id){
      $query = $this->db->select('*')
                        ->from($this->sub_course)
                        ->where('id',$topic_id);
      $res = $query->get();
      if($res){
        $result = $res->result();
        return $result;
      } else {
        return false;
      }
    }

    public function get_course_search($text){
      $query = $this->db->select('*')
                        ->from($this->course)
                        ->like('course_name');
      
    }
    
}
