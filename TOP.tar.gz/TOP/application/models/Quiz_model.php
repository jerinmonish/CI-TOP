<?php
/***
    File Name       : User_model.php
    Description     : This Model is to Provide the DB Details of User Manager and its operation
    Author          : A.C Jerin Monish <jerinmonish007@gmail.com>
    **/
defined('BASEPATH') OR exit('No direct script access allowed');
class Quiz_model  extends CI_Model  {

    public $CI;
    public $course          = 'course';
    public $sub_course      = 'sub_course';
    public $quiz            = 'quiz';
    public $set_completion  = 'completion_details';
    public $registration    = 'registration';
    public $quote           = 'quotes';

    /**
     * Constructor
     * To load library,language,model,ETC files
     * */
	function __construct()
    {
        parent::__construct();
        $this->CI =& get_instance();
    }

    /**
    * This method handles to get all port
    **/
    public function get_all_quiz(){
        $this->db->select('*');
        $this->db->from($this->quiz);
        $this->db->order_by("id","DESC");
        $this->CI->flexigrid->build_query();
        $return['records'] = $this->db->get();
         
        $this->db->select('count(id) as record_count')->from($this->quiz);
        $this->CI->flexigrid->build_query(FALSE);
        $record_count = $this->db->get();       
        $row = $record_count->row();
        $return['record_count'] = $row->record_count;  

        return $return;       
    }

    /**
     * This method is used to add quiz
     * @access public
     * @param fieldname $data (array data)
     * @return type array data
     */
    public function insert_quiz($data)
    {
        $query = $this->db->insert($this->quiz,$data);
        if($query){
            return true;
        } else {
            return false;
        }
    }

    /**
    * This method handles to retrieve a Port detail by collection Id
    **/
    public function get_quiz_by_id($id){
        $return     = [];

        $result     = $this->db->get_where($this->quiz, array('id' =>(int) $id));
        if(!empty($result)){
            $return = $result->result();
        }

        return $return;
    }

    /**
    * This method handles to delete port manager data by id
    **/
    function delete_quiz_id($id){
        $this->db->where('id', $id);
        $result =$this->db->delete($this->quiz);
        if($result){
            return true;
        }else{
            return false;
        }
    }

    /**
    * This method handles to update port manager data by id
    **/
    function update_quiz_by_id($id, $data){
      //print_r($data);exit;
        $query = $this->db->where('id', $id)
                          ->update($this->quiz, $data);
        if($query){
            return true;
        } else {
            return false;
        }
    }

    /**
     * This method is used to add course
     * @access public
     * @param fieldname $data (array data)
     * @return type array data
     */
    public function insert_quotes($data)
    {
        $query = $this->db->insert($this->quote,$data);
        if($query){
            return true;
        } else {
            return false;
        }
    }


    public function get_all_quote(){
        $query = $this->db->select('*')
                          ->from($this->quote);
        $res = $query->get();
        if($res){
            $result = $res->result();
            //$result = $res->num_rows();
            //echo '<pre>';print_r($result);exit;
            return $result;
        } else {
            return false;
        }
    }

    /**
    * This method handles to get all port
    **/
    public function get_all_quote_flex(){
        $this->db->select('*');
        $this->db->from($this->quote);
        $this->db->order_by("id","DESC");
        $this->CI->flexigrid->build_query();
        $return['records'] = $this->db->get();
         
        $this->db->select('count(id) as record_count')->from($this->quote);
        $this->CI->flexigrid->build_query(FALSE);
        $record_count = $this->db->get();       
        $row = $record_count->row();
        $return['record_count'] = $row->record_count;  

        return $return;       
    } 

    /**
    * This method handles to delete port manager data by id
    **/
    function delete_quote_id($id){
        $this->db->where('id', $id);
        $result =$this->db->delete($this->quote);
        if($result){
            return true;
        }else{
            return false;
        }
    }

    /**
    * This method handles to retrieve a Port detail by collection Id
    **/
    public function get_quote_by_id($id){
        $return     = [];

        $result     = $this->db->get_where($this->quote, array('id' =>(int) $id));
        if(!empty($result)){
            $return = $result->result();
        }

        return $return;
    }

    /**
    * This method handles to update port manager data by id
    **/
    function update_quote_by_id($id, $data){
      //print_r($data);exit;
        $query = $this->db->where('id', $id)
                          ->update($this->quote, $data);
        if($query){
            return true;
        } else {
            return false;
        }
    }
    
}
