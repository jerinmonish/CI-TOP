<?php
/***
    File Name       : User_model.php
    Description     : This Model is to Provide the DB Details of User Manager and its operation
    Author          : A.C Jerin Monish <jerinmonish007@gmail.com>
    **/
defined('BASEPATH') OR exit('No direct script access allowed');
class Login_model  extends CI_Model  {

    public $CI;
    public $registration = 'registration';
    public $state_tbl = 'state';
    public $country_tbl = 'country';
    public $city_tbl = 'city';

    /**
     * Constructor
     * To load library,language,model,ETC files
     * */
	function __construct()
    {
        parent::__construct();
        $this->CI =& get_instance();
    }

    /**
     * This method is used to check user logins
     * @access public
     * @param fieldname $user (array data)
     * @return type array data
     */
    public function check_user_login($user)
    {
        $table_1 = $this->registration;
        $check = $this->db->select('*')
                 ->from($table_1)
                 ->where('email=',$user['email'])
                 ->where('password=',$user['password']);
        $data = $this->db->get()->result();
        if($data){
            $status = array('login_status' => 'active', 'last_logged_on' => mysql_date_time(),'ip_address'=>$user['ip']);
            $query  = $this->db->where('email', $user['email'])
                                ->update($table_1, $status);

            if($query){
                //$res = $query->get()->result();
                return $data;
            } else {
                return false;
            }
        }
    }

    /**
     * This method is used to make status as inactive
     * @access public
     * @param fieldname $user_id (int)
     * @return type boolean
     */
    public function update_inactive_status($user_id){
        $active_status = array('login_status' => 'inactive');
            $status = $this->db->where('id', $user_id)
                    ->update('registration', $active_status);
            if($status){
                return true;
            } else {
                return false;
            }
    }

    /**
     * This method is used to check password correct or not
     * @access public
     * @param fieldname $currpass (str)
     * @return type array data
     */
    public function get_password($currpass){
        $regis = $this->registration;
        $query = $this->db->select('*')
                          ->from($regis)
                          ->where('id=',$currpass['id'])
                          ->where('password=',$currpass['password']);
        $data = $query->get();
        if($data){
            $pass = $data->result();
            return $pass;
        } else {
            return false;
        }
    }

    /**
     * This method is used check password and change if the old password is correct
     * @access public
     * @param fieldname $id (int),$old_pass (str),$currpass (str)
     * @return type boolean
     */
    public function change_user_password($id,$old_pass,$new_pass){
        $new_password = array('password' => $new_pass); 
        $regis = $this->registration;
        $query = $this->db->select('*')
                          ->from($regis)
                          ->where('id=',$id)
                          ->where('password=',$old_pass);
        $data = $query->get()->result();
        if($data){
            $sql = $this->db->where('id', $id)
                            ->update('registration', $new_password);
            if($sql){
                return true;
            } else {
                return false;
            }
        } else {
            return false;
        }
    }

    /**
     * This method is used to update user profile
     * @access public
     * @param fieldname $user_id ($int)
     * @return type array data
     */
    public function update_user_profile($user_id){
        $query = $this->db->select('*')
                          ->from($this->registration)
                          ->where('id',$user_id);
        $res = $query->get();
        if($res){
            $data = $res->result();
            return $data;
        } else {
            return false;
        }
    }

    /**
     * This method is used to update a user
     * @access public
     * @param fieldname $user_id (int)
     * @return type array data
     */
    public function update_user_by_id($user_id,$user){
        //print_r($user);exit;
        $query = $this->db->where('id', $user_id)
                          ->update($this->registration, $user);
        //$res = $query->get();
        if($query){
            //print_r($res);exit;
            //$data = $res->result();
            //return $data;
            return true;
        } else {
            return false;
        }
    }

    /**
     * This method is used to get state name using country id and state id
     * @access public
      * @param fieldname $id (int)
     * @return type array data
     */
    public function get_state_name($id,$s_id){
        $query = $this->db->select('name')
                          ->from($this->state_tbl)
                          ->where('country_id',$id)
                          ->where('id',$s_id);
        $get_res = $query->get();
        if($get_res){
            $res = $get_res->result();
            return $res;
        }else {
            return false;
        }
    }

    /**
     * This method is used to get city name using state id and country id
     * @access public
      * @param fieldname $id (int)
     * @return type array data
     */
    public function get_city_name($id,$c_id){
        $query = $this->db->select('name')
                          ->from($this->city_tbl)
                          ->where('id',$c_id)
                          ->where('state_id',$id)
                          ->limit('1');
        $get_res = $query->get();
        if($get_res){
            $res = $get_res->result();
            return $res;
        }else {
            return false;
        }
    }

    /**
     * This method is used to get country name using id
     * @access public
     * @param fieldname $id (int)
     * @return type array data
     */
    public function get_country_name($id){
        $query = $this->db->select('name')
                          ->from($this->country_tbl)
                          ->where('id',$id);
        $get_res = $query->get();
        if($get_res){
            $res = $get_res->result();
            return $res;
        }else {
            return false;
        }
    }

    /**
     * This method is used to get all countries
     * @access public
     * @param fieldname none
     * @return type array data
     */
    public function get_all_country(){
        $query = $this->db->select('*')
                          ->from($this->country_tbl);
        $res = $query->get();
        if($res){
            $data = $res->result();
            return $data;
        } else {
            return false;
        }
    }

    /**
     * This method is used to get all states
     * @access public
     * @param fieldname none
     * @return type array data
     */
    public function get_all_state(){
        $query = $this->db->select('*')
                          ->from($this->state_tbl);
        $res = $query->get();
        if($res){
            $data = $res->result();
            //print_r($data);exit('in');
            return $data;
        } else {
            return false;
        }
    }

    /**
     * This method is used to get all cities
     * @access public
     * @param fieldname none
     * @return type array data
     */
    public function get_all_city(){
        $queri = $this->db->select('*')
                          ->from($this->city_tbl);
        $get_data = $queri->get();
        if($get_data){
            $dat = $get_data->result();
            return $dat;
        } else {
            return false;
        }
    }

    /**
     * This method is used to get state while update
     * @access public
     * @param fieldname $state (int),$country (int)
     * @return type array data
     */
    public function get_user_state_on_update($country,$state){
        $query = $this->db->select('*')
                          ->from($this->state_tbl)
                          ->where('country_id',$country)
                          ->where('id',$state);
        $res = $query->get();
        if($res){
            $data = $res->result();
            return $data;
        } else {
            return false;
        }
    }

    /**
     * This method is used to get city while update
     * @access public
     * @param fieldname $state (int),$city (int)
     * @return type array data
     */
    public function get_user_city_on_update($state,$city){
        $query = $this->db->select('*')
                          ->from($this->city_tbl)
                          ->where('id',$city)
                          ->where('state_id',$state);
        $res = $query->get();
        if($res){
            $data = $res->result();
            return $data;
        } else {
            return false;
        }
    }

    /**
     * This method is used to get state by country
     * @access public
     * @param fieldname none
     * @return type array data
     */
    public function get_state_based_country($get_id){
        $query = $this->db->select('*')
                          ->from($this->state_tbl)
                          ->where('country_id',$get_id);
        $res = $query->get();
        if($res){
            $data = $res->result();
            return $data;
        } else {
            return false;
        }
    }

    /**
     * This method is used to get city by state
     * @access public
     * @param fieldname none
     * @return type array data
     */
    public function get_city_based_state($get_id){
        $query = $this->db->select('*')
                          ->from($this->city_tbl)
                          ->where('state_id',$get_id);
        $res = $query->get();
        if($res){
            $data = $res->result();
            return $data;
        } else {
            return false;
        }
    }

    /**
     * This method is used to add user
     * @access public
     * @param fieldname $data (array data)
     * @return type array data
     */
    public function add_user_one($data)
    {
        $query = $this->db->insert($this->registration,$data);
        if($query){
            return true;
        } else {
            return false;
        }
    }

    /**
    * This method handles to get all port
    **/
    public function get_all_users(){
        $this->db->select('*');
        $this->db->from($this->registration);
        $this->db->order_by("id","DESC");
        $this->CI->flexigrid->build_query();
        $return['records'] = $this->db->get();
         
        $this->db->select('count(id) as record_count')->from($this->registration);
        $this->CI->flexigrid->build_query(FALSE);
        $record_count = $this->db->get();       
        $row = $record_count->row();
        $return['record_count'] = $row->record_count;  

        return $return;       
    }


    /**
    * This method handles to retrieve a Port detail by collection Id
    **/
    public function get_user_by_id($id){
        $return     = [];

        $result     = $this->db->get_where($this->registration, array('id' =>(int) $id));
        if(!empty($result)){
            $return = $result->result();
        }

        return $return;
    }
}
