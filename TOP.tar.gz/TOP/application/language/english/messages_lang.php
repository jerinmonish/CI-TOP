	<?php
/**
* This lang contains page titles
**/

//Page Titles
$lang['login']			=	'Login';
$lang['site_name']		=	'Smart Online Education System';
$lang['searched-value']	=	'Searched Users';
$lang['friends_list']	=	'Your Friends';

//Course Labels
$lang['course_name']		=	'Course Name';
$lang['course_short_name']	=	'Course Short Name';
$lang['course_image']		=	'Course Image';
$lang['status']				=	'Status';
$lang['save']			    =	'Save';
$lang['created_on']			= 	'Submitted On';
$lang['action']				=	'Actions';
$lang['course_id']			=	'Course Id';
$lang['topic_name']			=	'Topic Name';
$lang['topic_short_name']	=	'Topic Short Name';
$lang['add_course']			=	'Add Course';
$lang['course_view']		=	'View Course';
$lang['add_sub_course']		=	'Add Topic';
$lang['all_course']			=	'Courses';
$lang['topics']				=	'Topics';
$lang['topic_id']			=	'Topics';
$lang['edit_course']		=	'Edit Course';
$lang['existing_image']		=	'Existing Image';
$lang['topic_view']			=	'Topic View';
$lang['topic_img']			=	'Topic Image';
$lang['topic_pdf']			=	'Topic PDF';
$lang['edit_topic']			=	'Edit Topic';
$lang['quiz']				=	'Quiz';
$lang['quiz_view']			=	'Quiz View';
$lang['question']			=	'Question';
$lang['add_quiz']			=	'Add Quiz';
$lang['answer']				=	'Answer';
$lang['option1']			=	'Option A';
$lang['option2']			=	'Option B';
$lang['option3']			=	'Option C';
$lang['option4']			=	'Option D';
$lang['add_user']			=	'Add User';
$lang['email']				=	'Email';
$lang['ip_address']			=	'Last used IP';
$lang['last_logged_on']		=	'Last Logged On';
$lang['registered_on']		=	'Registered On';
$lang['profile_view']		=	'View Profile';
$lang['quotes_add']			=	'Add Quote';
$lang['quotes_view']		=	'View Quote';
$lang['quotes_edit']		=	'Edit Quote';
$lang['quotes']				=	'Quote';
$lang['content']			=	'Quote';
$lang['i_class']			=	'Class Text';
$lang['i_color']			=	'Color';
//Course Urls

$lang['url_course_add'] 		=   'course/add/';
$lang['url_course_edit'] 		=   'course/edit/';
$lang['url_course_delete']		=   'course/delete/';
$lang['url_course_view']		=   'course/view/';

//Sub Course Urls

$lang['url_sub_course_add'] 	=   'course/add_sub_course/';
$lang['url_sub_course_edit'] 	=   'course/edit_sub_course/';
$lang['url_sub_course_delete']	=   'course/delete_sub_course/';
$lang['url_sub_course_view']	=   'course/view_sub_course/';

//Quiz Urls

$lang['url_quiz_add'] 		=   'quiz/add/';
$lang['url_quiz_edit'] 		=   'quiz/edit/';
$lang['url_quiz_delete']	=   'quiz/delete/';
$lang['url_quiz_view']		=   'quiz/view/'; 

//User Urls

$lang['url_user_add'] 		=   'login/add_user/';
$lang['url_user_edit'] 		=   'login/edit_user/';
$lang['url_user_delete']	=   'login/delete_user/';
$lang['url_user_view']		=   'login/view_user/';

//Quote Urls

$lang['url_quote_add'] 		=   'quiz/add_quotes/';
$lang['url_quote_edit'] 	=   'quiz/edit_quotes/';
$lang['url_quote_delete']	=   'quiz/delete_quotes/';
$lang['url_quote_view']		=   'quiz/view_quotes/';

//Image Paths
$lang['set_course_img'] 		= 	FCPATH.'/assets/course/course_images/';
$lang['set_course_imgs'] 		= 	base_url().'assets/course/course_images/';
$lang['set_sub_course_imgs'] 	= 	base_url().'assets/sub_course/icons';
$lang['set_sub_course_pdfs'] 	= 	base_url().'assets/sub_course/pdf/';
$lang['set_profile_path'] 		= 	base_url().'assets/profile_image/';
$lang['set_post_image']	  		=	'assets/post/';
$lang['get_post_image']   		= 	base_url().'assets/post/';

//Labels
$lang['log']			=	'Log';
$lang['in']				=	' In';
$lang['to_account']		=	'to your account';
$lang['e_mail']			=	'Email';
$lang['password']		=	'Password';
$lang['forgot_pass']	=	'Forgot your password?';
$lang['dont_hv']		=	'Don\'t have an account yet?';
$lang['create_account']	=	'Create an account';
$lang['copy_rights']	=	'&copy;';
$lang['curr_yr']		=	date('Y');
$lang['dashboard']		=	'Dashboard';
$lang['search']			=	'Search';
$lang['new']			=	'new';
$lang['all_msg']		=	'All messages';
$lang['messages']		=	'Message';
$lang['online_users']	=	'Online Users';
$lang['update_profile']	=	'Profile Update';
$lang['back']			=	'Back';
$lang['calendar']		=	'Calendar';
$lang['mantatory_symbol'] = '<span style="color:red;">*</span>';
$lang['my_dp']			=	'My Status';

//Registration and profile update
$lang['first_name']		=	'First Name';
$lang['last_name']		=	'Last Name';
$lang['gender']			=	'Gender';
$lang['male']			=	'Male';
$lang['female']			=	'Female';
$lang['dob']			=	'Date Of Birth';
$lang['address']		=	'Address';
$lang['mobile_no']		=	'Mobile Number';
$lang['country']		=	'Country';
$lang['city']			=	'City';
$lang['state']			=	'State';
$lang['zip']			=	'Zip';
$lang['image']			=	'Profile Pic';
$lang['existing_image'] =	'Existing Image';
$lang['change-pass']	=	'Change Password';
$lang['curr_pass']		=	'Current Password';
$lang['new_pass']		=	'New Password';
$lang['confirm_pass']	=	'Confirm Password';
$lang['blog']			=	'Blog';
$lang['add_blog']		=	'Add Blog';
$lang['content']		=	'Content';
$lang['save']			=	'Save';
$lang['post_photo']		=	'Post Image';
$lang['post_content']	=	'Post Content';
$lang['p_comment']		=	'Post Comment';
$lang['comment']		=	'Comment';
$lang['name']			=	'Name';
$lang['login_status']	=	'Login Status';
$lang['dob_s']			=	'D.O.B';
$lang['attend_quiz']	=	'Quiz';
$lang['get_certificate']	=	'Certification of Merit';
$lang['course_description']	=	'Course Description';
$lang['user_type']		=	'User Account';

//Messages
$lang['required']   	= 	'%s cannot be blank';
$lang['login_invalid']	=	'<div class="error" style="color:red;">Email Or Password Is Incorrect</div>';
$lang['course_added']		=	'<div class = "alert alert-info alert-dismissable">
								<button type = "button" class = "close" data-dismiss = "alert" aria-hidden = "true">&times;</button>
								Course has been added... !
							</div>';
$lang['course_unable_to_add']		=	'<div class = "alert alert-danger alert-dismissable">
											<button type = "button" class = "close" data-dismiss = "alert" aria-hidden = "true">&times;</button>
											Failed to add course... !
										</div>';

$lang['certificate_generated']	=	'<div class = "alert alert-info alert-dismissable">
										<button type = "button" class = "close" data-dismiss = "alert" aria-hidden = "true">&times;</button>
										Certificate Has been Generated... !
									</div>';

$lang['certificate_failed']	=		'<div class = "alert alert-danger alert-dismissable">
										<button type = "button" class = "close" data-dismiss = "alert" aria-hidden = "true">&times;</button>
										Failed to generate Certificate... !
									</div>';
$lang['quiz_present']	=	'<div class = "alert alert-info alert-dismissable">
								<button type = "button" class = "close" data-dismiss = "alert" aria-hidden = "true">&times;</button>
								Welcome to Quiz Area... !
							</div>';

$lang['quiz_not_present']	=	'<div class = "alert alert-danger alert-dismissable">
									<button type = "button" class = "close" data-dismiss = "alert" aria-hidden = "true">&times;</button>
									No any Quiz Items... !
								</div>';

$lang['course_update']	=	'<div class = "alert alert-info alert-dismissable">
								<button type = "button" class = "close" data-dismiss = "alert" aria-hidden = "true">&times;</button>
								Course has been updated... !
							</div>';

$lang['course_update_failed']	=	'<div class = "alert alert-danger alert-dismissable">
										<button type = "button" class = "close" data-dismiss = "alert" aria-hidden = "true">&times;</button>
										Failed to update course details... !
									</div>';

$lang['sub_course_update']		=	'<div class = "alert alert-info alert-dismissable">
										<button type = "button" class = "close" data-dismiss = "alert" aria-hidden = "true">&times;</button>
										Topic has been updated... !
									</div>';

$lang['sub_course_update_failed']	=	'<div class = "alert alert-danger alert-dismissable">
											<button type = "button" class = "close" data-dismiss = "alert" aria-hidden = "true">&times;</button>
											Failed to update Topic details... !
										</div>';

$lang['delete_success']		=	'<div class = "alert alert-info alert-dismissable">
										<button type = "button" class = "close" data-dismiss = "alert" aria-hidden = "true">&times;</button>
										Topic has been deleted... !
									</div>';

$lang['delete_fail']	=	'<div class = "alert alert-danger alert-dismissable">
											<button type = "button" class = "close" data-dismiss = "alert" aria-hidden = "true">&times;</button>
											Failed to delete Topic details... !
										</div>';

$lang['delete_success_course']		=	'<div class = "alert alert-info alert-dismissable">
											<button type = "button" class = "close" data-dismiss = "alert" aria-hidden = "true">&times;</button>
											Course has been deleted... !
										</div>';

$lang['delete_fail_course']	=	'<div class = "alert alert-danger alert-dismissable">
											<button type = "button" class = "close" data-dismiss = "alert" aria-hidden = "true">&times;</button>
											Failed to delete Course details... !
										</div>';

$lang['quiz_success_add']		=	'<div class = "alert alert-info alert-dismissable">
											<button type = "button" class = "close" data-dismiss = "alert" aria-hidden = "true">&times;</button>
											Quiz Question details has been deleted... !
										</div>';

$lang['quiz_fail_add']	=	'<div class = "alert alert-danger alert-dismissable">
								<button type = "button" class = "close" data-dismiss = "alert" aria-hidden = "true">&times;</button>
								Failed to add quiz details... !
							</div>';

$lang['delete_success_quiz']		=	'<div class = "alert alert-info alert-dismissable">
											<button type = "button" class = "close" data-dismiss = "alert" aria-hidden = "true">&times;</button>
											Question has been deleted... !
										</div>';

$lang['delete_fail_quiz']	=	'<div class = "alert alert-danger alert-dismissable">
											<button type = "button" class = "close" data-dismiss = "alert" aria-hidden = "true">&times;</button>
											Failed to question details... !
										</div>';

$lang['quiz_update_success']		=	'<div class = "alert alert-info alert-dismissable">
											<button type = "button" class = "close" data-dismiss = "alert" aria-hidden = "true">&times;</button>
											Quiz details has been updated... !
										</div>';

$lang['quiz_update_failed']	=	'<div class = "alert alert-danger alert-dismissable">
											<button type = "button" class = "close" data-dismiss = "alert" aria-hidden = "true">&times;</button>
											Failed to quiz details... !
										</div>';

$lang['user_added']	=	'<div class = "alert alert-info alert-dismissable">
								<button type = "button" class = "close" data-dismiss = "alert" aria-hidden = "true">&times;</button>
								User has been added successfully.. !
							</div>';

$lang['user_added_failed']=	'<div class = "alert alert-info alert-dismissable">
								<button type = "button" class = "close" data-dismiss = "alert" aria-hidden = "true">&times;</button>
								Failed to add user.. !
							</div>';

$lang['quote_add_success']	=	'<div class = "alert alert-info alert-dismissable">
								<button type = "button" class = "close" data-dismiss = "alert" aria-hidden = "true">&times;</button>
								Quote has been added..!
							</div>';

$lang['quote_add_failed']	=	'<div class = "alert alert-danger alert-dismissable">
								<button type = "button" class = "close" data-dismiss = "alert" aria-hidden = "true">&times;</button>
								Failed to add Quote..!
							</div>';

$lang['quote_delete_success']		=	'<div class = "alert alert-info alert-dismissable">
											<button type = "button" class = "close" data-dismiss = "alert" aria-hidden = "true">&times;</button>
											Quote has been deleted Successfully.. !
										</div>';

$lang['quote_delete_failed']		=	'<div class = "alert alert-danger alert-dismissable">
											<button type = "button" class = "close" data-dismiss = "alert" aria-hidden = "true">&times;</button>
											Failed to delete Quote.. !
										</div>';

$lang['quote_update_success']	=	'<div class = "alert alert-info alert-dismissable">
										<button type = "button" class = "close" data-dismiss = "alert" aria-hidden = "true">&times;</button>
										Quote has been updated successfully.. !
									</div>';

$lang['quote_update_failed']	=	'<div class = "alert alert-danger alert-dismissable">
										<button type = "button" class = "close" data-dismiss = "alert" aria-hidden = "true">&times;</button>
										Failed to update Quote.. !
									</div>';

$lang['r_subject_greet']		=	'Hi, I am ';
$lang['r_subject_full']			=	' I would like to be your friend ';
$lang['r_success_sub']		=	'I have added you';
$lang['r_success_msg_greet']		=	'Hi,';
$lang['r_success_msg']		=	' I have added you in my friend\'s list';

$lang['logout_success']	=	'<div class = "alert alert-info alert-dismissable">
								<button type = "button" class = "close" data-dismiss = "alert" aria-hidden = "true">&times;</button>
								Successfully logged out.. !
							</div>';
$lang['profile_updated']	=	'<div class = "alert alert-info alert-dismissable">
								<button type = "button" class = "close" data-dismiss = "alert" aria-hidden = "true">&times;</button>
								Profile has been updated successfully.. !
							</div>';
$lang['profile_notupdated']	=	'<div class = "alert alert-info alert-dismissable">
								<button type = "button" class = "close" data-dismiss = "alert" aria-hidden = "true">&times;</button>
								Failed to update profile.. !
							</div>';
$lang['password_changed']	=	'<div class = "alert alert-info alert-dismissable">
								<button type = "button" class = "close" data-dismiss = "alert" aria-hidden = "true">&times;</button>
								Password has been changed successfully.. !
							</div>';
$lang['password_notchanged']=	'<div class = "alert alert-info alert-dismissable">
								<button type = "button" class = "close" data-dismiss = "alert" aria-hidden = "true">&times;</button>
								Failed to change password.. !
							</div>';

