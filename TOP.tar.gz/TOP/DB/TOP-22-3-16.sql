-- phpMyAdmin SQL Dump
-- version 4.5.2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Mar 20, 2017 at 12:33 PM
-- Server version: 10.1.16-MariaDB
-- PHP Version: 5.6.24

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `TOP`
--

-- --------------------------------------------------------

--
-- Table structure for table `top_completion_details`
--

CREATE TABLE `top_completion_details` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `course_id` int(11) NOT NULL,
  `topic_id` int(11) NOT NULL,
  `stu_mark` varchar(10) DEFAULT '0',
  `pass_mark` varchar(10) DEFAULT '60',
  `sub_mark` varchar(10) DEFAULT NULL,
  `stu_status` enum('Pass','Fail') NOT NULL,
  `got_certificate` enum('received','notyet') NOT NULL DEFAULT 'notyet',
  `created_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `top_course`
--

CREATE TABLE `top_course` (
  `id` int(11) NOT NULL,
  `course_name` varchar(50) NOT NULL,
  `course_short_name` varchar(10) NOT NULL,
  `course_description` varchar(1000) NOT NULL,
  `course_image` varchar(150) DEFAULT NULL,
  `status` enum('Active','Inactive') NOT NULL,
  `created_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `top_course`
--

INSERT INTO `top_course` (`id`, `course_name`, `course_short_name`, `course_description`, `course_image`, `status`, `created_on`) VALUES
(1, 'Java', 'JV', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry''s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.', '954824-bigthumbnail.jpg', 'Active', '2017-03-16 12:32:56'),
(2, 'PHP', 'PHP', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry''s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.', 'ducklings-599030.jpg', 'Active', '2017-03-16 15:47:07'),
(3, 'DotNet', 'DN', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry''s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.', 'cma-programs8.jpg', 'Active', '2017-03-17 16:50:00');

-- --------------------------------------------------------

--
-- Table structure for table `top_quiz`
--

CREATE TABLE `top_quiz` (
  `id` int(11) NOT NULL,
  `question` varchar(1000) NOT NULL,
  `answer` varchar(1000) NOT NULL,
  `option1` varchar(1000) NOT NULL,
  `option2` varchar(1000) NOT NULL,
  `option3` varchar(1000) NOT NULL,
  `option4` varchar(1000) NOT NULL,
  `course_id` int(11) NOT NULL,
  `topic_id` int(11) NOT NULL,
  `created_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `top_quiz`
--

INSERT INTO `top_quiz` (`id`, `question`, `answer`, `option1`, `option2`, `option3`, `option4`, `course_id`, `topic_id`, `created_on`) VALUES
(1, 'Who is father of our nation ?', 'gandhi', 'jerin', 'mani', 'nishanth', 'gandhi', 1, 1, '2017-03-18 04:17:11'),
(2, 'what is national animal of india', 'tiger', 'lion', 'monkey', 'rabbit', 'tiger', 1, 1, '2017-03-18 04:17:53'),
(3, 'what is national bird of india', 'peocock', 'peocock', 'eagle', 'sparrow', 'pigeon', 1, 1, '2017-03-18 04:23:09'),
(4, 'what is national flower of india', 'lotus', 'rose', 'lotus', 'mogra', 'jasmine', 1, 1, '2017-03-18 04:23:09'),
(5, 'who wrote national anthem of india', 'rabidranath tagore', 'rose', 'lotus', 'rabidranath tagore', 'jasmine', 1, 1, '2017-03-18 04:23:09'),
(6, 'molecular formula for water', 'h2o', 'phc', 'h2o', '45loc', 'm4d', 1, 1, '2017-03-18 04:23:09'),
(7, 'molecular formula for oxygen', 'o2', 'o2', 'h2o', '45loc', 'm4d', 1, 1, '2017-03-18 04:23:09'),
(8, 'molecular formula for hydrogen', 'h', 'o2', 'h', '45loc', 'm4d', 1, 1, '2017-03-18 04:23:10'),
(9, 'molecular formula for methane', 'ch4', 'o2', 'ch4', '45loc', 'm4d', 1, 1, '2017-03-18 04:23:10'),
(10, 'molecular formula for ethane', 'c3h4', 'o2', 'c3h4', '45loc', 'm4d', 1, 1, '2017-03-18 04:23:10'),
(11, 'what is national bird of india', 'peocock', 'peocock', 'eagle', 'sparrow', 'pigeon', 1, 2, '2017-03-18 04:25:57'),
(12, 'what is national flower of india', 'lotus', 'rose', 'lotus', 'mogra', 'jasmine', 1, 2, '2017-03-18 04:25:57'),
(13, 'who wrote national anthem of india', 'rabidranath tagore', 'rose', 'lotus', 'rabidranath tagore', 'jasmine', 1, 2, '2017-03-18 04:25:57'),
(14, 'molecular formula for water', 'h2o', 'phc', 'h2o', '45loc', 'm4d', 1, 2, '2017-03-18 04:25:57'),
(15, 'molecular formula for oxygen', 'o2', 'o2', 'h2o', '45loc', 'm4d', 1, 2, '2017-03-18 04:25:57'),
(16, 'molecular formula for hydrogen', 'h', 'o2', 'h', '45loc', 'm4d', 1, 2, '2017-03-18 04:25:57'),
(17, 'molecular formula for methane', 'ch4', 'o2', 'ch4', '45loc', 'm4d', 1, 2, '2017-03-18 04:25:57'),
(18, 'molecular formula for ethane', 'c3h4', 'o2', 'c3h4', '45loc', 'm4d', 1, 2, '2017-03-18 04:25:57'),
(19, 'who is father of our nation', 'gandhi', 'jerin', 'mani', 'nishanth', 'gandhi', 1, 2, '2017-03-18 04:25:57'),
(20, 'what is national animal of india', 'tiger', 'lion', 'tiger', 'monkey', 'rabbit', 1, 2, '2017-03-18 04:25:57'),
(21, 'what is expansion for php', 'hypertext preprocessor', 'preprocessor', 'hypertext preprocessor', 'hypertext', 'pigeon', 2, 3, '2017-03-18 04:34:03'),
(22, 'what is $', 'variable declaration', 'variable declaration', 'hypertext preprocessor', 'hypertext', 'pigeon', 2, 3, '2017-03-18 04:34:03'),
(23, 'what is $a', 'variable', 'declaration', 'hypertext preprocessor', 'variable', 'pigeon', 2, 3, '2017-03-18 04:34:03'),
(24, 'what is <?php ?>', 'php tag', '.net tag', 'java tag', 'php tag', 'erlang tag', 2, 3, '2017-03-18 04:34:03'),
(25, 'what is array', 'homogeneus collection', 'heterogeneus collection', 'homogeneus collection', 'miss collection', 'figured collection', 2, 3, '2017-03-18 04:34:03'),
(26, 'what is .', 'concatenate', 'concatenate', 'attach', 'mingle', 'error debugger', 2, 3, '2017-03-18 04:34:03'),
(27, 'what is @', 'error avoid', 'error avoid', 'manage error', 'error avoid debug', 'list error', 2, 3, '2017-03-18 04:34:03'),
(28, 'what is + in javacript', 'concatenate', 'concatenate', 'attach', 'mingle', 'error debugger', 2, 3, '2017-03-18 04:34:03'),
(29, 'what is php', 'web language', 'software', 'program', 'web language', 'script', 2, 3, '2017-03-18 04:34:03'),
(30, 'what is input', 'requirement', 'variable declaration', 'hypertext preprocessor', 'hypertext', 'requirement', 2, 3, '2017-03-18 04:34:04');

-- --------------------------------------------------------

--
-- Table structure for table `top_registration`
--

CREATE TABLE `top_registration` (
  `id` int(11) NOT NULL,
  `first_name` varchar(30) NOT NULL,
  `last_name` varchar(20) DEFAULT NULL,
  `email` varchar(40) NOT NULL,
  `user_type` enum('admin','user') NOT NULL DEFAULT 'user',
  `password` varchar(40) NOT NULL,
  `gender` enum('male','female') NOT NULL,
  `status` enum('active','inactive') NOT NULL,
  `dob` date NOT NULL,
  `address` varchar(500) NOT NULL,
  `mobile_no` varchar(10) NOT NULL,
  `image` varchar(200) NOT NULL DEFAULT 'no-image.png',
  `registered_on` datetime NOT NULL,
  `country` varchar(20) NOT NULL,
  `state` varchar(20) NOT NULL,
  `city` varchar(20) NOT NULL,
  `zip` varchar(10) NOT NULL,
  `login_status` enum('active','inactive') DEFAULT 'inactive',
  `ip_address` varchar(250) DEFAULT NULL,
  `last_logged_on` datetime DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `top_registration`
--

INSERT INTO `top_registration` (`id`, `first_name`, `last_name`, `email`, `user_type`, `password`, `gender`, `status`, `dob`, `address`, `mobile_no`, `image`, `registered_on`, `country`, `state`, `city`, `zip`, `login_status`, `ip_address`, `last_logged_on`) VALUES
(1, 'Jerin', 'Monish', 'jerinmonish007@gmail.com', 'admin', '31ef15e664a4dceadcd4243bc6aeeca5', 'male', 'active', '1994-10-07', 'No,11 Jayaraj Nagar,''B'' Street(vivek nagar post)', '9880256443', 'transfors.jpg', '2016-03-24 08:14:29', 'India', 'Karnataka', 'Bangalore', '560047', 'inactive', '::1', '2017-03-18 16:56:31'),
(2, 'Mahan', 'nan', 'mahan@gmail.com', 'user', 'ad4927e425621f4010fbb6264e34f700', 'male', 'active', '1993-03-11', 'No. 233, church street, shivaji nagar, ', '9887654366', 'avatar.jpg', '2016-04-01 06:45:28', 'India', 'Karnataka', 'Bangalore', '560045', 'inactive', '::1', '2016-09-09 13:49:33'),
(3, 'Pradeep', 'antony', 'pradbics@gmail.com', 'user', 'febc8f8ac083f5fc27e032c81e7b536a', 'male', 'active', '1992-09-23', 'Thiruvannamalai, Polur', '987654321', 'user4.jpg', '2016-04-01 06:45:28', 'India', 'Tamil Nadu', 'Tiruvannamalai', '635345', 'active', '::1', '2017-03-18 21:40:32'),
(4, 'manigandan', 'saravanaa', 'mani@gmail.com', 'user', '07cd55c7b42715ec44c133a6a165e8d2', 'male', 'active', '1994-07-14', 'Nilavur, Yellagiri hills', '123456789', 'user5.jpg', '2016-04-01 06:45:28', 'India', 'Tamil Nadu', 'Tirupattur', '635853', 'inactive', '::1', '2016-10-20 09:15:14'),
(5, 'Mahesh', NULL, 'mahesh@gmail.com', 'user', '49bb197bec17b7d20b2df6b1f3c3434a', 'male', 'active', '1994-07-14', 'Kilpauk, Chennai', '123456789', 'user7.jpg', '2016-04-01 06:45:28', 'India', 'Tamil Nadu', 'chennai', '600023', 'inactive', '127.0.0.1', '2016-09-27 16:05:31'),
(6, 'Maria', NULL, 'maria@gmail.com', 'user', '263bce650e68ab4e23f28263760b9fa5', 'female', 'active', '1994-10-07', 'No,13 Narayan nagar,''B'' Street(sathyam theater post)', '9880256443', 'user6.jpg', '2016-03-24 08:14:29', 'India', 'Tamil Nadu', 'Chennai', '60089', 'inactive', '127.0.0.1', '2016-09-16 17:55:30'),
(7, 'samantha', NULL, 'samantha@gmail.com', 'user', 'f01e0d7992a3b7748538d02291b0beae', 'female', 'active', '1994-10-07', 'No,13 pallavarma chennai', '9880256443', '4.jpg', '2016-03-24 08:14:29', 'India', 'Tamil Nadu', 'Chennai', '60045', 'active', '127.0.0.1', '2016-10-15 15:15:05');

-- --------------------------------------------------------

--
-- Table structure for table `top_sub_course`
--

CREATE TABLE `top_sub_course` (
  `id` int(11) NOT NULL,
  `course_id` int(11) NOT NULL,
  `topic_name` varchar(50) NOT NULL,
  `topic_short_name` varchar(10) NOT NULL,
  `topic_img` varchar(150) DEFAULT NULL,
  `status` enum('Active','Inactive') NOT NULL,
  `pdf_file` varchar(150) NOT NULL,
  `created_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `top_sub_course`
--

INSERT INTO `top_sub_course` (`id`, `course_id`, `topic_name`, `topic_short_name`, `topic_img`, `status`, `pdf_file`, `created_on`) VALUES
(1, 1, 'Class & Objects', 'JCO', 'm1.svg', 'Active', 'demoform1.pdf', '2017-03-16 07:08:56'),
(2, 1, 'Java Functions', 'JF', 'm2.svg', 'Active', 'demoform1.pdf', '2017-03-16 07:08:56'),
(3, 2, 'Basics', 'DOTB', 'm3.svg', 'Active', 'demoform1.pdf', '2017-03-16 07:10:32'),
(4, 2, 'Class & Objects', 'DOTCO', 'm4.svg', 'Active', 'demoform1.pdf', '2017-03-16 07:10:32'),
(5, 1, 'test', 'test', 'm5.svg', 'Active', 'demoform1.pdf', '2017-03-16 05:44:33'),
(6, 2, 'test', 'test', 'almaz.svg', 'Active', 'demoform1.pdf', '2017-03-16 05:46:14'),
(7, 1, 'Applet', 'JPP', 'test-lab-tubes.svg', 'Active', 'demoform1.pdf', '2017-03-16 05:46:14'),
(8, 1, 'Abstract Windowing Toolkit', 'AWT', 'satellite.svg', 'Active', 'demoform1.pdf', '2017-03-16 05:46:14'),
(9, 1, 'Thread', 'JTH', 'lab-flask-leaf.svg', 'Active', 'demoform1.pdf', '2017-03-16 05:46:14');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `top_completion_details`
--
ALTER TABLE `top_completion_details`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `top_course`
--
ALTER TABLE `top_course`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `top_quiz`
--
ALTER TABLE `top_quiz`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `top_registration`
--
ALTER TABLE `top_registration`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `top_sub_course`
--
ALTER TABLE `top_sub_course`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `top_completion_details`
--
ALTER TABLE `top_completion_details`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `top_course`
--
ALTER TABLE `top_course`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `top_quiz`
--
ALTER TABLE `top_quiz`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;
--
-- AUTO_INCREMENT for table `top_registration`
--
ALTER TABLE `top_registration`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `top_sub_course`
--
ALTER TABLE `top_sub_course`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
